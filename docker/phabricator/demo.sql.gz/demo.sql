-- MySQL dump 10.16  Distrib 10.1.22-MariaDB, for Linux (x86_64)
--
-- Host: phabdb    Database: phabricator_audit
-- ------------------------------------------------------
-- Server version	5.5.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `phabricator_audit`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_audit` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_audit`;

--
-- Table structure for table `audit_transaction`
--

DROP TABLE IF EXISTS `audit_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_transaction`
--

LOCK TABLES `audit_transaction` WRITE;
/*!40000 ALTER TABLE `audit_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_transaction_comment`
--

DROP TABLE IF EXISTS `audit_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `commitPHID` varbinary(64) DEFAULT NULL,
  `pathID` int(10) unsigned DEFAULT NULL,
  `isNewFile` tinyint(1) NOT NULL,
  `lineNumber` int(10) unsigned NOT NULL,
  `lineLength` int(10) unsigned NOT NULL,
  `fixedState` varchar(12) COLLATE utf8mb4_bin DEFAULT NULL,
  `hasReplies` tinyint(1) NOT NULL,
  `replyToCommentPHID` varbinary(64) DEFAULT NULL,
  `legacyCommentID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`),
  KEY `key_path` (`pathID`),
  KEY `key_draft` (`authorPHID`,`transactionPHID`),
  KEY `key_commit` (`commitPHID`),
  KEY `key_legacy` (`legacyCommentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_transaction_comment`
--

LOCK TABLES `audit_transaction_comment` WRITE;
/*!40000 ALTER TABLE `audit_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_calendar`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_calendar` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_calendar`;

--
-- Table structure for table `calendar_event`
--

DROP TABLE IF EXISTS `calendar_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `hostPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `isCancelled` tinyint(1) NOT NULL,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `isAllDay` tinyint(1) NOT NULL,
  `icon` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `isRecurring` tinyint(1) NOT NULL,
  `instanceOfEventPHID` varbinary(64) DEFAULT NULL,
  `sequenceIndex` int(10) unsigned DEFAULT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `isStub` tinyint(1) NOT NULL,
  `utcInitialEpoch` int(10) unsigned NOT NULL,
  `utcUntilEpoch` int(10) unsigned DEFAULT NULL,
  `utcInstanceEpoch` int(10) unsigned DEFAULT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `importAuthorPHID` varbinary(64) DEFAULT NULL,
  `importSourcePHID` varbinary(64) DEFAULT NULL,
  `importUIDIndex` binary(12) DEFAULT NULL,
  `importUID` longtext COLLATE utf8mb4_bin,
  `seriesParentPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_instance` (`instanceOfEventPHID`,`sequenceIndex`),
  UNIQUE KEY `key_rdate` (`instanceOfEventPHID`,`utcInstanceEpoch`),
  KEY `key_space` (`spacePHID`),
  KEY `key_epoch` (`utcInitialEpoch`,`utcUntilEpoch`),
  KEY `key_series` (`seriesParentPHID`,`utcInitialEpoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_event`
--

LOCK TABLES `calendar_event` WRITE;
/*!40000 ALTER TABLE `calendar_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_eventinvitee`
--

DROP TABLE IF EXISTS `calendar_eventinvitee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_eventinvitee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `eventPHID` varbinary(64) NOT NULL,
  `inviteePHID` varbinary(64) NOT NULL,
  `inviterPHID` varbinary(64) NOT NULL,
  `status` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `availability` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_event` (`eventPHID`,`inviteePHID`),
  KEY `key_invitee` (`inviteePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_eventinvitee`
--

LOCK TABLES `calendar_eventinvitee` WRITE;
/*!40000 ALTER TABLE `calendar_eventinvitee` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_eventinvitee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_eventtransaction`
--

DROP TABLE IF EXISTS `calendar_eventtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_eventtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_eventtransaction`
--

LOCK TABLES `calendar_eventtransaction` WRITE;
/*!40000 ALTER TABLE `calendar_eventtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_eventtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_eventtransaction_comment`
--

DROP TABLE IF EXISTS `calendar_eventtransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_eventtransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_eventtransaction_comment`
--

LOCK TABLES `calendar_eventtransaction_comment` WRITE;
/*!40000 ALTER TABLE `calendar_eventtransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_eventtransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_export`
--

DROP TABLE IF EXISTS `calendar_export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_export` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `policyMode` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `queryKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `secretKey` binary(20) NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_secret` (`secretKey`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_author` (`authorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_export`
--

LOCK TABLES `calendar_export` WRITE;
/*!40000 ALTER TABLE `calendar_export` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_exporttransaction`
--

DROP TABLE IF EXISTS `calendar_exporttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_exporttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_exporttransaction`
--

LOCK TABLES `calendar_exporttransaction` WRITE;
/*!40000 ALTER TABLE `calendar_exporttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_exporttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_externalinvitee`
--

DROP TABLE IF EXISTS `calendar_externalinvitee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_externalinvitee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `nameIndex` binary(12) NOT NULL,
  `uri` longtext COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `sourcePHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`nameIndex`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_externalinvitee`
--

LOCK TABLES `calendar_externalinvitee` WRITE;
/*!40000 ALTER TABLE `calendar_externalinvitee` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_externalinvitee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_import`
--

DROP TABLE IF EXISTS `calendar_import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_import` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `engineType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `triggerPHID` varbinary(64) DEFAULT NULL,
  `triggerFrequency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_author` (`authorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_import`
--

LOCK TABLES `calendar_import` WRITE;
/*!40000 ALTER TABLE `calendar_import` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_importlog`
--

DROP TABLE IF EXISTS `calendar_importlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_importlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `importPHID` varbinary(64) NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_import` (`importPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_importlog`
--

LOCK TABLES `calendar_importlog` WRITE;
/*!40000 ALTER TABLE `calendar_importlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_importlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_importtransaction`
--

DROP TABLE IF EXISTS `calendar_importtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_importtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_importtransaction`
--

LOCK TABLES `calendar_importtransaction` WRITE;
/*!40000 ALTER TABLE `calendar_importtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_importtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_notification`
--

DROP TABLE IF EXISTS `calendar_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_notification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `eventPHID` varbinary(64) NOT NULL,
  `utcInitialEpoch` int(10) unsigned NOT NULL,
  `targetPHID` varbinary(64) NOT NULL,
  `didNotifyEpoch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_notify` (`eventPHID`,`utcInitialEpoch`,`targetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_notification`
--

LOCK TABLES `calendar_notification` WRITE;
/*!40000 ALTER TABLE `calendar_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_chatlog`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_chatlog` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_chatlog`;

--
-- Table structure for table `chatlog_channel`
--

DROP TABLE IF EXISTS `chatlog_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatlog_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `serviceName` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `serviceType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `channelName` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_channel` (`channelName`,`serviceType`,`serviceName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatlog_channel`
--

LOCK TABLES `chatlog_channel` WRITE;
/*!40000 ALTER TABLE `chatlog_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `chatlog_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chatlog_event`
--

DROP TABLE IF EXISTS `chatlog_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatlog_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `epoch` int(10) unsigned NOT NULL,
  `author` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `message` longtext COLLATE utf8mb4_bin NOT NULL,
  `loggedByPHID` varbinary(64) NOT NULL,
  `channelID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatlog_event`
--

LOCK TABLES `chatlog_event` WRITE;
/*!40000 ALTER TABLE `chatlog_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `chatlog_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_conduit`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_conduit` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_conduit`;

--
-- Table structure for table `conduit_certificatetoken`
--

DROP TABLE IF EXISTS `conduit_certificatetoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conduit_certificatetoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userPHID` (`userPHID`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conduit_certificatetoken`
--

LOCK TABLES `conduit_certificatetoken` WRITE;
/*!40000 ALTER TABLE `conduit_certificatetoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `conduit_certificatetoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conduit_methodcalllog`
--

DROP TABLE IF EXISTS `conduit_methodcalllog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conduit_methodcalllog` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connectionID` bigint(20) unsigned DEFAULT NULL,
  `method` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `error` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `duration` bigint(20) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `callerPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `key_method` (`method`),
  KEY `key_callermethod` (`callerPHID`,`method`),
  KEY `key_date` (`dateCreated`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conduit_methodcalllog`
--

LOCK TABLES `conduit_methodcalllog` WRITE;
/*!40000 ALTER TABLE `conduit_methodcalllog` DISABLE KEYS */;
INSERT INTO `conduit_methodcalllog` VALUES (1,NULL,'conduit.ping','',116579,1494436233,1494436233,NULL),(2,NULL,'conduit.getcapabilities','',8403,1494436233,1494436233,NULL),(3,NULL,'user.whoami','',36330,1494436286,1494436286,0x504849442D555345522D7778366372787078777767666A336E7A63376E77),(4,NULL,'user.whoami','',15900,1494436499,1494436499,0x504849442D555345522D7778366372787078777767666A336E7A63376E77);
/*!40000 ALTER TABLE `conduit_methodcalllog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conduit_token`
--

DROP TABLE IF EXISTS `conduit_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conduit_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `tokenType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `expires` int(10) unsigned DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_token` (`token`),
  KEY `key_object` (`objectPHID`,`tokenType`),
  KEY `key_expires` (`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conduit_token`
--

LOCK TABLES `conduit_token` WRITE;
/*!40000 ALTER TABLE `conduit_token` DISABLE KEYS */;
INSERT INTO `conduit_token` VALUES (1,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'cli','cli-wnxaaftwm34jjfheiokqevsshlg7',NULL,1494436259,1494436286);
/*!40000 ALTER TABLE `conduit_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_countdown`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_countdown` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_countdown`;

--
-- Table structure for table `countdown`
--

DROP TABLE IF EXISTS `countdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countdown` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_epoch` (`epoch`),
  KEY `key_author` (`authorPHID`,`epoch`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countdown`
--

LOCK TABLES `countdown` WRITE;
/*!40000 ALTER TABLE `countdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `countdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countdown_transaction`
--

DROP TABLE IF EXISTS `countdown_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countdown_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countdown_transaction`
--

LOCK TABLES `countdown_transaction` WRITE;
/*!40000 ALTER TABLE `countdown_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `countdown_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countdown_transaction_comment`
--

DROP TABLE IF EXISTS `countdown_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countdown_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countdown_transaction_comment`
--

LOCK TABLES `countdown_transaction_comment` WRITE;
/*!40000 ALTER TABLE `countdown_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `countdown_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_daemon`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_daemon` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_daemon`;

--
-- Table structure for table `daemon_log`
--

DROP TABLE IF EXISTS `daemon_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daemon_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daemon` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `host` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `pid` int(10) unsigned NOT NULL,
  `argv` longtext COLLATE utf8mb4_bin NOT NULL,
  `explicitArgv` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `status` varchar(8) COLLATE utf8mb4_bin NOT NULL,
  `runningAsUser` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `daemonID` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_daemonID` (`daemonID`),
  KEY `status` (`status`),
  KEY `dateCreated` (`dateCreated`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daemon_log`
--

LOCK TABLES `daemon_log` WRITE;
/*!40000 ALTER TABLE `daemon_log` DISABLE KEYS */;
INSERT INTO `daemon_log` VALUES (1,'PhabricatorRepositoryPullLocalDaemon','c01da50e8e24',26,'[]','[]',1494270733,1494285166,'wait','app','26:5z7npsbeb'),(2,'PhabricatorTriggerDaemon','c01da50e8e24',26,'[]','[]',1494270733,1494285166,'wait','app','26:zbaai2jkt'),(3,'PhabricatorTaskmasterDaemon','c01da50e8e24',26,'[]','[]',1494270733,1494285056,'wait','app','26:4bfulwxqo'),(4,'PhabricatorRepositoryPullLocalDaemon','1a3b5a669289',26,'[]','[]',1494292739,1494292740,'wait','app','26:kohbwothn'),(5,'PhabricatorTriggerDaemon','1a3b5a669289',26,'[]','[]',1494292739,1494292740,'wait','app','26:jimsazxhu'),(6,'PhabricatorTaskmasterDaemon','1a3b5a669289',26,'[]','[]',1494292739,1494292756,'wait','app','26:gj4h3dorc'),(7,'PhabricatorRepositoryPullLocalDaemon','f84f5e4b7b8e',27,'[]','[]',1494366398,1494436614,'wait','app','27:g2b3zeg53'),(8,'PhabricatorTriggerDaemon','f84f5e4b7b8e',27,'[]','[]',1494366398,1494436614,'wait','app','27:txozq43ik'),(9,'PhabricatorTaskmasterDaemon','f84f5e4b7b8e',27,'[]','[]',1494366398,1494436715,'wait','app','27:imrhx5gjk');
/*!40000 ALTER TABLE `daemon_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daemon_logevent`
--

DROP TABLE IF EXISTS `daemon_logevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daemon_logevent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logID` int(10) unsigned NOT NULL,
  `logType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `message` longtext COLLATE utf8mb4_bin NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logID` (`logID`,`epoch`)
) ENGINE=InnoDB AUTO_INCREMENT=3529 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daemon_logevent`
--

LOCK TABLES `daemon_logevent` WRITE;
/*!40000 ALTER TABLE `daemon_logevent` DISABLE KEYS */;
INSERT INTO `daemon_logevent` VALUES (1,1,'INIT','Starting process.',1494270734),(2,2,'INIT','Starting process.',1494270735),(3,3,'INIT','Starting process.',1494270735),(4,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270735),(5,1,'DONE','Process exited normally.',1494270735),(6,1,'WAIT','Waiting 180 second(s) to restart process.',1494270735),(7,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270735),(8,2,'DONE','Process exited normally.',1494270735),(9,2,'WAIT','Waiting 180 second(s) to restart process.',1494270735),(10,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270751),(11,3,'DONE','Process exited normally.',1494270751),(12,3,'WAIT','Waiting 180 second(s) to restart process.',1494270751),(13,3,'WAKE','Process is being awakened from hibernation.',1494270894),(14,3,'INIT','Starting process.',1494270894),(15,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270911),(16,3,'DONE','Process exited normally.',1494270911),(17,3,'WAIT','Waiting 180 second(s) to restart process.',1494270911),(18,1,'INIT','Starting process.',1494270915),(19,2,'INIT','Starting process.',1494270915),(20,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270915),(21,1,'DONE','Process exited normally.',1494270915),(22,1,'WAIT','Waiting 180 second(s) to restart process.',1494270915),(23,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494270915),(24,2,'DONE','Process exited normally.',1494270915),(25,2,'WAIT','Waiting 180 second(s) to restart process.',1494270915),(26,3,'INIT','Starting process.',1494271091),(27,1,'INIT','Starting process.',1494271095),(28,2,'INIT','Starting process.',1494271095),(29,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271095),(30,1,'DONE','Process exited normally.',1494271095),(31,1,'WAIT','Waiting 180 second(s) to restart process.',1494271095),(32,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271095),(33,2,'DONE','Process exited normally.',1494271095),(34,2,'WAIT','Waiting 180 second(s) to restart process.',1494271095),(35,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271107),(36,3,'DONE','Process exited normally.',1494271107),(37,3,'WAIT','Waiting 180 second(s) to restart process.',1494271107),(38,1,'INIT','Starting process.',1494271275),(39,2,'INIT','Starting process.',1494271275),(40,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271275),(41,1,'DONE','Process exited normally.',1494271275),(42,1,'WAIT','Waiting 180 second(s) to restart process.',1494271275),(43,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494271276),(44,2,'DONE','Process exited normally.',1494271276),(45,2,'WAIT','Waiting 179 second(s) to restart process.',1494271276),(46,3,'INIT','Starting process.',1494271287),(47,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271303),(48,3,'DONE','Process exited normally.',1494271303),(49,3,'WAIT','Waiting 180 second(s) to restart process.',1494271303),(50,1,'INIT','Starting process.',1494271455),(51,2,'INIT','Starting process.',1494271455),(52,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271456),(53,1,'DONE','Process exited normally.',1494271456),(54,1,'WAIT','Waiting 180 second(s) to restart process.',1494271456),(55,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271456),(56,2,'DONE','Process exited normally.',1494271456),(57,2,'WAIT','Waiting 180 second(s) to restart process.',1494271456),(58,3,'INIT','Starting process.',1494271483),(59,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271499),(60,3,'DONE','Process exited normally.',1494271499),(61,3,'WAIT','Waiting 180 second(s) to restart process.',1494271499),(62,1,'INIT','Starting process.',1494271636),(63,2,'INIT','Starting process.',1494271636),(64,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271637),(65,1,'DONE','Process exited normally.',1494271637),(66,1,'WAIT','Waiting 180 second(s) to restart process.',1494271637),(67,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271637),(68,2,'DONE','Process exited normally.',1494271637),(69,2,'WAIT','Waiting 180 second(s) to restart process.',1494271637),(70,3,'INIT','Starting process.',1494271679),(71,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271695),(72,3,'DONE','Process exited normally.',1494271695),(73,3,'WAIT','Waiting 180 second(s) to restart process.',1494271695),(74,3,'WAKE','Process is being awakened from hibernation.',1494271765),(75,3,'INIT','Starting process.',1494271765),(76,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271782),(77,3,'DONE','Process exited normally.',1494271782),(78,3,'WAIT','Waiting 180 second(s) to restart process.',1494271782),(79,1,'INIT','Starting process.',1494271817),(80,2,'INIT','Starting process.',1494271817),(81,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271818),(82,1,'DONE','Process exited normally.',1494271818),(83,1,'WAIT','Waiting 180 second(s) to restart process.',1494271818),(84,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271818),(85,2,'DONE','Process exited normally.',1494271818),(86,2,'WAIT','Waiting 180 second(s) to restart process.',1494271818),(87,3,'INIT','Starting process.',1494271962),(88,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271978),(89,3,'DONE','Process exited normally.',1494271978),(90,3,'WAIT','Waiting 180 second(s) to restart process.',1494271978),(91,1,'INIT','Starting process.',1494271998),(92,2,'INIT','Starting process.',1494271998),(93,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271999),(94,1,'DONE','Process exited normally.',1494271999),(95,1,'WAIT','Waiting 180 second(s) to restart process.',1494271999),(96,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494271999),(97,2,'DONE','Process exited normally.',1494271999),(98,2,'WAIT','Waiting 180 second(s) to restart process.',1494271999),(99,3,'INIT','Starting process.',1494272158),(100,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272174),(101,3,'DONE','Process exited normally.',1494272174),(102,3,'WAIT','Waiting 180 second(s) to restart process.',1494272174),(103,1,'INIT','Starting process.',1494272179),(104,2,'INIT','Starting process.',1494272179),(105,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272179),(106,1,'DONE','Process exited normally.',1494272179),(107,1,'WAIT','Waiting 180 second(s) to restart process.',1494272179),(108,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272179),(109,2,'DONE','Process exited normally.',1494272179),(110,2,'WAIT','Waiting 180 second(s) to restart process.',1494272179),(111,3,'WAKE','Process is being awakened from hibernation.',1494272240),(112,3,'INIT','Starting process.',1494272240),(113,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272256),(114,3,'DONE','Process exited normally.',1494272256),(115,3,'WAIT','Waiting 180 second(s) to restart process.',1494272256),(116,1,'INIT','Starting process.',1494272359),(117,2,'INIT','Starting process.',1494272359),(118,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272359),(119,1,'DONE','Process exited normally.',1494272359),(120,1,'WAIT','Waiting 180 second(s) to restart process.',1494272359),(121,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272359),(122,2,'DONE','Process exited normally.',1494272359),(123,2,'WAIT','Waiting 180 second(s) to restart process.',1494272359),(124,3,'INIT','Starting process.',1494272436),(125,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272453),(126,3,'DONE','Process exited normally.',1494272453),(127,3,'WAIT','Waiting 180 second(s) to restart process.',1494272453),(128,1,'INIT','Starting process.',1494272539),(129,2,'INIT','Starting process.',1494272539),(130,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272539),(131,1,'DONE','Process exited normally.',1494272539),(132,1,'WAIT','Waiting 180 second(s) to restart process.',1494272539),(133,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272539),(134,2,'DONE','Process exited normally.',1494272539),(135,2,'WAIT','Waiting 180 second(s) to restart process.',1494272539),(136,3,'INIT','Starting process.',1494272633),(137,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272650),(138,3,'DONE','Process exited normally.',1494272650),(139,3,'WAIT','Waiting 180 second(s) to restart process.',1494272650),(140,1,'INIT','Starting process.',1494272719),(141,2,'INIT','Starting process.',1494272719),(142,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272719),(143,1,'DONE','Process exited normally.',1494272719),(144,1,'WAIT','Waiting 180 second(s) to restart process.',1494272719),(145,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272719),(146,2,'DONE','Process exited normally.',1494272719),(147,2,'WAIT','Waiting 180 second(s) to restart process.',1494272719),(148,3,'INIT','Starting process.',1494272830),(149,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272847),(150,3,'DONE','Process exited normally.',1494272847),(151,3,'WAIT','Waiting 180 second(s) to restart process.',1494272847),(152,1,'INIT','Starting process.',1494272899),(153,2,'INIT','Starting process.',1494272899),(154,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272899),(155,1,'DONE','Process exited normally.',1494272899),(156,1,'WAIT','Waiting 180 second(s) to restart process.',1494272899),(157,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494272899),(158,2,'DONE','Process exited normally.',1494272899),(159,2,'WAIT','Waiting 180 second(s) to restart process.',1494272899),(160,3,'INIT','Starting process.',1494273027),(161,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273043),(162,3,'DONE','Process exited normally.',1494273043),(163,3,'WAIT','Waiting 180 second(s) to restart process.',1494273043),(164,1,'INIT','Starting process.',1494273079),(165,2,'INIT','Starting process.',1494273079),(166,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273079),(167,1,'DONE','Process exited normally.',1494273079),(168,1,'WAIT','Waiting 180 second(s) to restart process.',1494273079),(169,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273079),(170,2,'DONE','Process exited normally.',1494273079),(171,2,'WAIT','Waiting 180 second(s) to restart process.',1494273079),(172,3,'INIT','Starting process.',1494273223),(173,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273239),(174,3,'DONE','Process exited normally.',1494273239),(175,3,'WAIT','Waiting 180 second(s) to restart process.',1494273239),(176,1,'INIT','Starting process.',1494273259),(177,2,'INIT','Starting process.',1494273259),(178,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273259),(179,1,'DONE','Process exited normally.',1494273259),(180,1,'WAIT','Waiting 180 second(s) to restart process.',1494273259),(181,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273259),(182,2,'DONE','Process exited normally.',1494273259),(183,2,'WAIT','Waiting 180 second(s) to restart process.',1494273259),(184,3,'INIT','Starting process.',1494273419),(185,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273435),(186,3,'DONE','Process exited normally.',1494273435),(187,3,'WAIT','Waiting 180 second(s) to restart process.',1494273435),(188,1,'INIT','Starting process.',1494273439),(189,2,'INIT','Starting process.',1494273439),(190,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273439),(191,1,'DONE','Process exited normally.',1494273439),(192,1,'WAIT','Waiting 180 second(s) to restart process.',1494273439),(193,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273439),(194,2,'DONE','Process exited normally.',1494273439),(195,2,'WAIT','Waiting 180 second(s) to restart process.',1494273439),(196,3,'WAKE','Process is being awakened from hibernation.',1494273464),(197,3,'INIT','Starting process.',1494273464),(198,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273481),(199,3,'DONE','Process exited normally.',1494273481),(200,3,'WAIT','Waiting 180 second(s) to restart process.',1494273481),(201,1,'INIT','Starting process.',1494273619),(202,2,'INIT','Starting process.',1494273619),(203,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273619),(204,1,'DONE','Process exited normally.',1494273619),(205,1,'WAIT','Waiting 180 second(s) to restart process.',1494273619),(206,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494273620),(207,2,'DONE','Process exited normally.',1494273620),(208,2,'WAIT','Waiting 179 second(s) to restart process.',1494273620),(209,3,'INIT','Starting process.',1494273661),(210,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273677),(211,3,'DONE','Process exited normally.',1494273677),(212,3,'WAIT','Waiting 180 second(s) to restart process.',1494273677),(213,1,'INIT','Starting process.',1494273799),(214,2,'INIT','Starting process.',1494273799),(215,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273799),(216,1,'DONE','Process exited normally.',1494273799),(217,1,'WAIT','Waiting 180 second(s) to restart process.',1494273799),(218,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494273800),(219,2,'DONE','Process exited normally.',1494273800),(220,2,'WAIT','Waiting 179 second(s) to restart process.',1494273800),(221,3,'INIT','Starting process.',1494273857),(222,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273873),(223,3,'DONE','Process exited normally.',1494273873),(224,3,'WAIT','Waiting 180 second(s) to restart process.',1494273873),(225,1,'INIT','Starting process.',1494273979),(226,2,'INIT','Starting process.',1494273979),(227,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273980),(228,1,'DONE','Process exited normally.',1494273980),(229,1,'WAIT','Waiting 180 second(s) to restart process.',1494273980),(230,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494273980),(231,2,'DONE','Process exited normally.',1494273980),(232,2,'WAIT','Waiting 180 second(s) to restart process.',1494273980),(233,3,'INIT','Starting process.',1494274053),(234,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274069),(235,3,'DONE','Process exited normally.',1494274069),(236,3,'WAIT','Waiting 180 second(s) to restart process.',1494274069),(237,1,'INIT','Starting process.',1494274160),(238,2,'INIT','Starting process.',1494274160),(239,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274161),(240,1,'DONE','Process exited normally.',1494274161),(241,1,'WAIT','Waiting 180 second(s) to restart process.',1494274161),(242,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274161),(243,2,'DONE','Process exited normally.',1494274161),(244,2,'WAIT','Waiting 180 second(s) to restart process.',1494274161),(245,3,'INIT','Starting process.',1494274249),(246,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274265),(247,3,'DONE','Process exited normally.',1494274265),(248,3,'WAIT','Waiting 180 second(s) to restart process.',1494274265),(249,1,'INIT','Starting process.',1494274341),(250,2,'INIT','Starting process.',1494274341),(251,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274342),(252,1,'DONE','Process exited normally.',1494274342),(253,1,'WAIT','Waiting 180 second(s) to restart process.',1494274342),(254,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274342),(255,2,'DONE','Process exited normally.',1494274342),(256,2,'WAIT','Waiting 180 second(s) to restart process.',1494274342),(257,3,'INIT','Starting process.',1494274445),(258,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274461),(259,3,'DONE','Process exited normally.',1494274461),(260,3,'WAIT','Waiting 180 second(s) to restart process.',1494274461),(261,1,'INIT','Starting process.',1494274522),(262,2,'INIT','Starting process.',1494274522),(263,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274523),(264,1,'DONE','Process exited normally.',1494274523),(265,1,'WAIT','Waiting 180 second(s) to restart process.',1494274523),(266,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274523),(267,2,'DONE','Process exited normally.',1494274523),(268,2,'WAIT','Waiting 180 second(s) to restart process.',1494274523),(269,3,'INIT','Starting process.',1494274641),(270,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274657),(271,3,'DONE','Process exited normally.',1494274657),(272,3,'WAIT','Waiting 180 second(s) to restart process.',1494274657),(273,1,'INIT','Starting process.',1494274703),(274,2,'INIT','Starting process.',1494274703),(275,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274703),(276,1,'DONE','Process exited normally.',1494274703),(277,1,'WAIT','Waiting 180 second(s) to restart process.',1494274703),(278,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274703),(279,2,'DONE','Process exited normally.',1494274703),(280,2,'WAIT','Waiting 180 second(s) to restart process.',1494274703),(281,3,'INIT','Starting process.',1494274837),(282,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274853),(283,3,'DONE','Process exited normally.',1494274853),(284,3,'WAIT','Waiting 179 second(s) to restart process.',1494274854),(285,1,'INIT','Starting process.',1494274883),(286,2,'INIT','Starting process.',1494274883),(287,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274883),(288,1,'DONE','Process exited normally.',1494274883),(289,1,'WAIT','Waiting 180 second(s) to restart process.',1494274883),(290,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494274883),(291,2,'DONE','Process exited normally.',1494274883),(292,2,'WAIT','Waiting 180 second(s) to restart process.',1494274883),(293,3,'INIT','Starting process.',1494275033),(294,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275050),(295,3,'DONE','Process exited normally.',1494275050),(296,3,'WAIT','Waiting 180 second(s) to restart process.',1494275050),(297,1,'INIT','Starting process.',1494275063),(298,2,'INIT','Starting process.',1494275063),(299,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275063),(300,1,'DONE','Process exited normally.',1494275063),(301,1,'WAIT','Waiting 180 second(s) to restart process.',1494275063),(302,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275063),(303,2,'DONE','Process exited normally.',1494275063),(304,2,'WAIT','Waiting 180 second(s) to restart process.',1494275063),(305,3,'INIT','Starting process.',1494275230),(306,1,'INIT','Starting process.',1494275243),(307,2,'INIT','Starting process.',1494275243),(308,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275244),(309,1,'DONE','Process exited normally.',1494275244),(310,1,'WAIT','Waiting 180 second(s) to restart process.',1494275244),(311,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275244),(312,2,'DONE','Process exited normally.',1494275244),(313,2,'WAIT','Waiting 180 second(s) to restart process.',1494275244),(314,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275247),(315,3,'DONE','Process exited normally.',1494275247),(316,3,'WAIT','Waiting 180 second(s) to restart process.',1494275247),(317,1,'INIT','Starting process.',1494275424),(318,2,'INIT','Starting process.',1494275424),(319,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275424),(320,1,'DONE','Process exited normally.',1494275424),(321,1,'WAIT','Waiting 180 second(s) to restart process.',1494275424),(322,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275424),(323,2,'DONE','Process exited normally.',1494275424),(324,2,'WAIT','Waiting 180 second(s) to restart process.',1494275424),(325,3,'INIT','Starting process.',1494275427),(326,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275444),(327,3,'DONE','Process exited normally.',1494275444),(328,3,'WAIT','Waiting 180 second(s) to restart process.',1494275444),(329,1,'INIT','Starting process.',1494275604),(330,2,'INIT','Starting process.',1494275604),(331,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275604),(332,1,'DONE','Process exited normally.',1494275604),(333,1,'WAIT','Waiting 180 second(s) to restart process.',1494275604),(334,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275604),(335,2,'DONE','Process exited normally.',1494275604),(336,2,'WAIT','Waiting 180 second(s) to restart process.',1494275604),(337,3,'INIT','Starting process.',1494275624),(338,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275640),(339,3,'DONE','Process exited normally.',1494275640),(340,3,'WAIT','Waiting 180 second(s) to restart process.',1494275640),(341,1,'INIT','Starting process.',1494275784),(342,2,'INIT','Starting process.',1494275784),(343,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275784),(344,1,'DONE','Process exited normally.',1494275784),(345,1,'WAIT','Waiting 180 second(s) to restart process.',1494275784),(346,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275784),(347,2,'DONE','Process exited normally.',1494275784),(348,2,'WAIT','Waiting 179 second(s) to restart process.',1494275785),(349,3,'INIT','Starting process.',1494275820),(350,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275836),(351,3,'DONE','Process exited normally.',1494275836),(352,3,'WAIT','Waiting 180 second(s) to restart process.',1494275836),(353,1,'INIT','Starting process.',1494275964),(354,2,'INIT','Starting process.',1494275964),(355,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494275964),(356,1,'DONE','Process exited normally.',1494275964),(357,1,'WAIT','Waiting 180 second(s) to restart process.',1494275964),(358,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494275965),(359,2,'DONE','Process exited normally.',1494275965),(360,2,'WAIT','Waiting 179 second(s) to restart process.',1494275965),(361,3,'INIT','Starting process.',1494276016),(362,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276032),(363,3,'DONE','Process exited normally.',1494276032),(364,3,'WAIT','Waiting 180 second(s) to restart process.',1494276032),(365,1,'INIT','Starting process.',1494276144),(366,2,'INIT','Starting process.',1494276144),(367,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276145),(368,1,'DONE','Process exited normally.',1494276145),(369,1,'WAIT','Waiting 180 second(s) to restart process.',1494276145),(370,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276145),(371,2,'DONE','Process exited normally.',1494276145),(372,2,'WAIT','Waiting 180 second(s) to restart process.',1494276145),(373,3,'INIT','Starting process.',1494276212),(374,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276228),(375,3,'DONE','Process exited normally.',1494276228),(376,3,'WAIT','Waiting 180 second(s) to restart process.',1494276228),(377,1,'INIT','Starting process.',1494276325),(378,2,'INIT','Starting process.',1494276325),(379,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276326),(380,1,'DONE','Process exited normally.',1494276326),(381,1,'WAIT','Waiting 180 second(s) to restart process.',1494276326),(382,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276326),(383,2,'DONE','Process exited normally.',1494276326),(384,2,'WAIT','Waiting 180 second(s) to restart process.',1494276326),(385,3,'INIT','Starting process.',1494276408),(386,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276424),(387,3,'DONE','Process exited normally.',1494276424),(388,3,'WAIT','Waiting 180 second(s) to restart process.',1494276424),(389,1,'INIT','Starting process.',1494276506),(390,2,'INIT','Starting process.',1494276506),(391,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276507),(392,1,'DONE','Process exited normally.',1494276507),(393,1,'WAIT','Waiting 180 second(s) to restart process.',1494276507),(394,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276507),(395,2,'DONE','Process exited normally.',1494276507),(396,2,'WAIT','Waiting 180 second(s) to restart process.',1494276507),(397,3,'INIT','Starting process.',1494276604),(398,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276620),(399,3,'DONE','Process exited normally.',1494276620),(400,3,'WAIT','Waiting 180 second(s) to restart process.',1494276620),(401,1,'INIT','Starting process.',1494276687),(402,2,'INIT','Starting process.',1494276687),(403,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276688),(404,1,'DONE','Process exited normally.',1494276688),(405,1,'WAIT','Waiting 180 second(s) to restart process.',1494276688),(406,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276688),(407,2,'DONE','Process exited normally.',1494276688),(408,2,'WAIT','Waiting 180 second(s) to restart process.',1494276688),(409,3,'INIT','Starting process.',1494276800),(410,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276816),(411,3,'DONE','Process exited normally.',1494276816),(412,3,'WAIT','Waiting 180 second(s) to restart process.',1494276816),(413,1,'INIT','Starting process.',1494276868),(414,2,'INIT','Starting process.',1494276868),(415,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276868),(416,1,'DONE','Process exited normally.',1494276868),(417,1,'WAIT','Waiting 180 second(s) to restart process.',1494276868),(418,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494276868),(419,2,'DONE','Process exited normally.',1494276868),(420,2,'WAIT','Waiting 180 second(s) to restart process.',1494276868),(421,3,'INIT','Starting process.',1494276996),(422,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277012),(423,3,'DONE','Process exited normally.',1494277012),(424,3,'WAIT','Waiting 180 second(s) to restart process.',1494277012),(425,1,'INIT','Starting process.',1494277048),(426,2,'INIT','Starting process.',1494277048),(427,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277048),(428,1,'DONE','Process exited normally.',1494277048),(429,1,'WAIT','Waiting 180 second(s) to restart process.',1494277048),(430,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277048),(431,2,'DONE','Process exited normally.',1494277048),(432,2,'WAIT','Waiting 180 second(s) to restart process.',1494277048),(433,3,'INIT','Starting process.',1494277192),(434,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277208),(435,3,'DONE','Process exited normally.',1494277208),(436,3,'WAIT','Waiting 180 second(s) to restart process.',1494277208),(437,1,'INIT','Starting process.',1494277228),(438,2,'INIT','Starting process.',1494277228),(439,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277228),(440,1,'DONE','Process exited normally.',1494277228),(441,1,'WAIT','Waiting 180 second(s) to restart process.',1494277228),(442,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277228),(443,2,'DONE','Process exited normally.',1494277228),(444,2,'WAIT','Waiting 180 second(s) to restart process.',1494277228),(445,3,'INIT','Starting process.',1494277388),(446,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277405),(447,3,'DONE','Process exited normally.',1494277405),(448,3,'WAIT','Waiting 180 second(s) to restart process.',1494277405),(449,1,'INIT','Starting process.',1494277408),(450,2,'INIT','Starting process.',1494277408),(451,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277408),(452,1,'DONE','Process exited normally.',1494277408),(453,1,'WAIT','Waiting 180 second(s) to restart process.',1494277408),(454,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277408),(455,2,'DONE','Process exited normally.',1494277408),(456,2,'WAIT','Waiting 180 second(s) to restart process.',1494277408),(457,3,'INIT','Starting process.',1494277585),(458,1,'INIT','Starting process.',1494277588),(459,2,'INIT','Starting process.',1494277588),(460,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277589),(461,1,'DONE','Process exited normally.',1494277589),(462,1,'WAIT','Waiting 180 second(s) to restart process.',1494277589),(463,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277589),(464,2,'DONE','Process exited normally.',1494277589),(465,2,'WAIT','Waiting 180 second(s) to restart process.',1494277589),(466,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277602),(467,3,'DONE','Process exited normally.',1494277602),(468,3,'WAIT','Waiting 180 second(s) to restart process.',1494277602),(469,1,'INIT','Starting process.',1494277769),(470,2,'INIT','Starting process.',1494277769),(471,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277769),(472,1,'DONE','Process exited normally.',1494277769),(473,1,'WAIT','Waiting 180 second(s) to restart process.',1494277769),(474,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277769),(475,2,'DONE','Process exited normally.',1494277769),(476,2,'WAIT','Waiting 180 second(s) to restart process.',1494277769),(477,3,'INIT','Starting process.',1494277782),(478,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277798),(479,3,'DONE','Process exited normally.',1494277798),(480,3,'WAIT','Waiting 180 second(s) to restart process.',1494277798),(481,1,'INIT','Starting process.',1494277949),(482,2,'INIT','Starting process.',1494277949),(483,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277949),(484,1,'DONE','Process exited normally.',1494277949),(485,1,'WAIT','Waiting 180 second(s) to restart process.',1494277949),(486,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277949),(487,2,'DONE','Process exited normally.',1494277949),(488,2,'WAIT','Waiting 180 second(s) to restart process.',1494277949),(489,3,'INIT','Starting process.',1494277978),(490,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494277994),(491,3,'DONE','Process exited normally.',1494277994),(492,3,'WAIT','Waiting 180 second(s) to restart process.',1494277994),(493,1,'INIT','Starting process.',1494278129),(494,2,'INIT','Starting process.',1494278129),(495,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278129),(496,1,'DONE','Process exited normally.',1494278129),(497,1,'WAIT','Waiting 180 second(s) to restart process.',1494278129),(498,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494278130),(499,2,'DONE','Process exited normally.',1494278130),(500,2,'WAIT','Waiting 179 second(s) to restart process.',1494278130),(501,3,'INIT','Starting process.',1494278174),(502,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278190),(503,3,'DONE','Process exited normally.',1494278190),(504,3,'WAIT','Waiting 180 second(s) to restart process.',1494278190),(505,1,'INIT','Starting process.',1494278309),(506,2,'INIT','Starting process.',1494278309),(507,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278309),(508,1,'DONE','Process exited normally.',1494278310),(509,1,'WAIT','Waiting 179 second(s) to restart process.',1494278310),(510,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494278310),(511,2,'DONE','Process exited normally.',1494278310),(512,2,'WAIT','Waiting 179 second(s) to restart process.',1494278310),(513,3,'INIT','Starting process.',1494278370),(514,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278386),(515,3,'DONE','Process exited normally.',1494278386),(516,3,'WAIT','Waiting 180 second(s) to restart process.',1494278386),(517,1,'INIT','Starting process.',1494278489),(518,2,'INIT','Starting process.',1494278489),(519,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278490),(520,1,'DONE','Process exited normally.',1494278490),(521,1,'WAIT','Waiting 180 second(s) to restart process.',1494278490),(522,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278490),(523,2,'DONE','Process exited normally.',1494278490),(524,2,'WAIT','Waiting 180 second(s) to restart process.',1494278490),(525,3,'INIT','Starting process.',1494278566),(526,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278582),(527,3,'DONE','Process exited normally.',1494278582),(528,3,'WAIT','Waiting 180 second(s) to restart process.',1494278582),(529,1,'INIT','Starting process.',1494278670),(530,2,'INIT','Starting process.',1494278670),(531,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278671),(532,1,'DONE','Process exited normally.',1494278671),(533,1,'WAIT','Waiting 180 second(s) to restart process.',1494278671),(534,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278671),(535,2,'DONE','Process exited normally.',1494278671),(536,2,'WAIT','Waiting 180 second(s) to restart process.',1494278671),(537,3,'INIT','Starting process.',1494278762),(538,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278778),(539,3,'DONE','Process exited normally.',1494278778),(540,3,'WAIT','Waiting 180 second(s) to restart process.',1494278778),(541,1,'INIT','Starting process.',1494278851),(542,2,'INIT','Starting process.',1494278851),(543,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278852),(544,1,'DONE','Process exited normally.',1494278852),(545,1,'WAIT','Waiting 180 second(s) to restart process.',1494278852),(546,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278852),(547,2,'DONE','Process exited normally.',1494278852),(548,2,'WAIT','Waiting 180 second(s) to restart process.',1494278852),(549,3,'INIT','Starting process.',1494278958),(550,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494278974),(551,3,'DONE','Process exited normally.',1494278974),(552,3,'WAIT','Waiting 180 second(s) to restart process.',1494278974),(553,1,'INIT','Starting process.',1494279032),(554,2,'INIT','Starting process.',1494279032),(555,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279033),(556,1,'DONE','Process exited normally.',1494279033),(557,1,'WAIT','Waiting 180 second(s) to restart process.',1494279033),(558,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279033),(559,2,'DONE','Process exited normally.',1494279033),(560,2,'WAIT','Waiting 180 second(s) to restart process.',1494279033),(561,3,'INIT','Starting process.',1494279154),(562,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279170),(563,3,'DONE','Process exited normally.',1494279170),(564,3,'WAIT','Waiting 180 second(s) to restart process.',1494279170),(565,1,'INIT','Starting process.',1494279213),(566,2,'INIT','Starting process.',1494279213),(567,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279214),(568,1,'DONE','Process exited normally.',1494279214),(569,1,'WAIT','Waiting 180 second(s) to restart process.',1494279214),(570,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279214),(571,2,'DONE','Process exited normally.',1494279214),(572,2,'WAIT','Waiting 180 second(s) to restart process.',1494279214),(573,3,'INIT','Starting process.',1494279350),(574,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279366),(575,3,'DONE','Process exited normally.',1494279366),(576,3,'WAIT','Waiting 180 second(s) to restart process.',1494279366),(577,1,'INIT','Starting process.',1494279394),(578,2,'INIT','Starting process.',1494279394),(579,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279395),(580,1,'DONE','Process exited normally.',1494279395),(581,1,'WAIT','Waiting 180 second(s) to restart process.',1494279395),(582,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279395),(583,2,'DONE','Process exited normally.',1494279395),(584,2,'WAIT','Waiting 180 second(s) to restart process.',1494279395),(585,3,'INIT','Starting process.',1494279546),(586,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279562),(587,3,'DONE','Process exited normally.',1494279562),(588,3,'WAIT','Waiting 180 second(s) to restart process.',1494279562),(589,1,'INIT','Starting process.',1494279575),(590,2,'INIT','Starting process.',1494279575),(591,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279575),(592,1,'DONE','Process exited normally.',1494279575),(593,1,'WAIT','Waiting 180 second(s) to restart process.',1494279575),(594,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279575),(595,2,'DONE','Process exited normally.',1494279575),(596,2,'WAIT','Waiting 180 second(s) to restart process.',1494279575),(597,3,'INIT','Starting process.',1494279742),(598,1,'INIT','Starting process.',1494279755),(599,2,'INIT','Starting process.',1494279755),(600,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279756),(601,1,'DONE','Process exited normally.',1494279756),(602,1,'WAIT','Waiting 180 second(s) to restart process.',1494279756),(603,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279756),(604,2,'DONE','Process exited normally.',1494279756),(605,2,'WAIT','Waiting 180 second(s) to restart process.',1494279756),(606,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279758),(607,3,'DONE','Process exited normally.',1494279758),(608,3,'WAIT','Waiting 180 second(s) to restart process.',1494279758),(609,1,'INIT','Starting process.',1494279936),(610,2,'INIT','Starting process.',1494279936),(611,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279936),(612,1,'DONE','Process exited normally.',1494279936),(613,1,'WAIT','Waiting 180 second(s) to restart process.',1494279936),(614,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279936),(615,2,'DONE','Process exited normally.',1494279936),(616,2,'WAIT','Waiting 180 second(s) to restart process.',1494279936),(617,3,'INIT','Starting process.',1494279938),(618,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494279955),(619,3,'DONE','Process exited normally.',1494279955),(620,3,'WAIT','Waiting 180 second(s) to restart process.',1494279955),(621,1,'INIT','Starting process.',1494280116),(622,2,'INIT','Starting process.',1494280116),(623,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280116),(624,1,'DONE','Process exited normally.',1494280116),(625,1,'WAIT','Waiting 180 second(s) to restart process.',1494280116),(626,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280116),(627,2,'DONE','Process exited normally.',1494280116),(628,2,'WAIT','Waiting 180 second(s) to restart process.',1494280116),(629,3,'INIT','Starting process.',1494280135),(630,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280152),(631,3,'DONE','Process exited normally.',1494280152),(632,3,'WAIT','Waiting 180 second(s) to restart process.',1494280152),(633,1,'INIT','Starting process.',1494280296),(634,2,'INIT','Starting process.',1494280296),(635,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280296),(636,1,'DONE','Process exited normally.',1494280296),(637,1,'WAIT','Waiting 180 second(s) to restart process.',1494280296),(638,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280296),(639,2,'DONE','Process exited normally.',1494280296),(640,2,'WAIT','Waiting 180 second(s) to restart process.',1494280296),(641,3,'INIT','Starting process.',1494280332),(642,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280349),(643,3,'DONE','Process exited normally.',1494280349),(644,3,'WAIT','Waiting 180 second(s) to restart process.',1494280349),(645,1,'INIT','Starting process.',1494280476),(646,2,'INIT','Starting process.',1494280476),(647,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280476),(648,1,'DONE','Process exited normally.',1494280476),(649,1,'WAIT','Waiting 180 second(s) to restart process.',1494280476),(650,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280476),(651,2,'DONE','Process exited normally.',1494280476),(652,2,'WAIT','Waiting 180 second(s) to restart process.',1494280476),(653,3,'INIT','Starting process.',1494280529),(654,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280545),(655,3,'DONE','Process exited normally.',1494280545),(656,3,'WAIT','Waiting 180 second(s) to restart process.',1494280545),(657,1,'INIT','Starting process.',1494280656),(658,2,'INIT','Starting process.',1494280656),(659,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280656),(660,1,'DONE','Process exited normally.',1494280656),(661,1,'WAIT','Waiting 180 second(s) to restart process.',1494280656),(662,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280656),(663,2,'DONE','Process exited normally.',1494280656),(664,2,'WAIT','Waiting 180 second(s) to restart process.',1494280656),(665,3,'INIT','Starting process.',1494280725),(666,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280741),(667,3,'DONE','Process exited normally.',1494280741),(668,3,'WAIT','Waiting 180 second(s) to restart process.',1494280741),(669,1,'INIT','Starting process.',1494280836),(670,2,'INIT','Starting process.',1494280836),(671,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280836),(672,1,'DONE','Process exited normally.',1494280836),(673,1,'WAIT','Waiting 180 second(s) to restart process.',1494280836),(674,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280836),(675,2,'DONE','Process exited normally.',1494280836),(676,2,'WAIT','Waiting 179 second(s) to restart process.',1494280837),(677,3,'INIT','Starting process.',1494280921),(678,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494280937),(679,3,'DONE','Process exited normally.',1494280937),(680,3,'WAIT','Waiting 180 second(s) to restart process.',1494280937),(681,1,'INIT','Starting process.',1494281016),(682,2,'INIT','Starting process.',1494281016),(683,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281016),(684,1,'DONE','Process exited normally.',1494281016),(685,1,'WAIT','Waiting 180 second(s) to restart process.',1494281016),(686,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494281017),(687,2,'DONE','Process exited normally.',1494281017),(688,2,'WAIT','Waiting 179 second(s) to restart process.',1494281017),(689,3,'INIT','Starting process.',1494281117),(690,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281133),(691,3,'DONE','Process exited normally.',1494281133),(692,3,'WAIT','Waiting 180 second(s) to restart process.',1494281133),(693,1,'INIT','Starting process.',1494281196),(694,2,'INIT','Starting process.',1494281196),(695,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281197),(696,1,'DONE','Process exited normally.',1494281197),(697,1,'WAIT','Waiting 180 second(s) to restart process.',1494281197),(698,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281197),(699,2,'DONE','Process exited normally.',1494281197),(700,2,'WAIT','Waiting 180 second(s) to restart process.',1494281197),(701,3,'INIT','Starting process.',1494281313),(702,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281329),(703,3,'DONE','Process exited normally.',1494281329),(704,3,'WAIT','Waiting 180 second(s) to restart process.',1494281329),(705,1,'INIT','Starting process.',1494281377),(706,2,'INIT','Starting process.',1494281377),(707,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281378),(708,1,'DONE','Process exited normally.',1494281378),(709,1,'WAIT','Waiting 180 second(s) to restart process.',1494281378),(710,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281378),(711,2,'DONE','Process exited normally.',1494281378),(712,2,'WAIT','Waiting 180 second(s) to restart process.',1494281378),(713,3,'INIT','Starting process.',1494281509),(714,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281525),(715,3,'DONE','Process exited normally.',1494281525),(716,3,'WAIT','Waiting 180 second(s) to restart process.',1494281525),(717,1,'INIT','Starting process.',1494281558),(718,2,'INIT','Starting process.',1494281558),(719,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281559),(720,1,'DONE','Process exited normally.',1494281559),(721,1,'WAIT','Waiting 180 second(s) to restart process.',1494281559),(722,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281559),(723,2,'DONE','Process exited normally.',1494281559),(724,2,'WAIT','Waiting 180 second(s) to restart process.',1494281559),(725,3,'INIT','Starting process.',1494281705),(726,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281721),(727,3,'DONE','Process exited normally.',1494281721),(728,3,'WAIT','Waiting 180 second(s) to restart process.',1494281721),(729,1,'INIT','Starting process.',1494281739),(730,2,'INIT','Starting process.',1494281739),(731,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281740),(732,1,'DONE','Process exited normally.',1494281740),(733,1,'WAIT','Waiting 180 second(s) to restart process.',1494281740),(734,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281740),(735,2,'DONE','Process exited normally.',1494281740),(736,2,'WAIT','Waiting 180 second(s) to restart process.',1494281740),(737,3,'INIT','Starting process.',1494281901),(738,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281917),(739,3,'DONE','Process exited normally.',1494281917),(740,3,'WAIT','Waiting 180 second(s) to restart process.',1494281917),(741,1,'INIT','Starting process.',1494281920),(742,2,'INIT','Starting process.',1494281920),(743,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281921),(744,1,'DONE','Process exited normally.',1494281921),(745,1,'WAIT','Waiting 180 second(s) to restart process.',1494281921),(746,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494281921),(747,2,'DONE','Process exited normally.',1494281921),(748,2,'WAIT','Waiting 180 second(s) to restart process.',1494281921),(749,3,'INIT','Starting process.',1494282097),(750,1,'INIT','Starting process.',1494282101),(751,2,'INIT','Starting process.',1494282101),(752,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282102),(753,1,'DONE','Process exited normally.',1494282102),(754,1,'WAIT','Waiting 180 second(s) to restart process.',1494282102),(755,2,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494282102),(756,2,'DONE','Process exited normally.',1494282102),(757,2,'WAIT','Waiting 179 second(s) to restart process.',1494282102),(758,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282113),(759,3,'DONE','Process exited normally.',1494282113),(760,3,'WAIT','Waiting 180 second(s) to restart process.',1494282113),(761,2,'INIT','Starting process.',1494282281),(762,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282281),(763,2,'DONE','Process exited normally.',1494282281),(764,2,'WAIT','Waiting 180 second(s) to restart process.',1494282281),(765,1,'INIT','Starting process.',1494282282),(766,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282283),(767,1,'DONE','Process exited normally.',1494282283),(768,1,'WAIT','Waiting 180 second(s) to restart process.',1494282283),(769,3,'INIT','Starting process.',1494282293),(770,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282309),(771,3,'DONE','Process exited normally.',1494282309),(772,3,'WAIT','Waiting 180 second(s) to restart process.',1494282309),(773,2,'INIT','Starting process.',1494282461),(774,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282462),(775,2,'DONE','Process exited normally.',1494282462),(776,2,'WAIT','Waiting 180 second(s) to restart process.',1494282462),(777,1,'INIT','Starting process.',1494282463),(778,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282463),(779,1,'DONE','Process exited normally.',1494282463),(780,1,'WAIT','Waiting 180 second(s) to restart process.',1494282463),(781,3,'INIT','Starting process.',1494282489),(782,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282505),(783,3,'DONE','Process exited normally.',1494282505),(784,3,'WAIT','Waiting 180 second(s) to restart process.',1494282505),(785,2,'INIT','Starting process.',1494282642),(786,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282642),(787,2,'DONE','Process exited normally.',1494282642),(788,2,'WAIT','Waiting 180 second(s) to restart process.',1494282642),(789,1,'INIT','Starting process.',1494282643),(790,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282643),(791,1,'DONE','Process exited normally.',1494282643),(792,1,'WAIT','Waiting 180 second(s) to restart process.',1494282643),(793,3,'INIT','Starting process.',1494282685),(794,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282702),(795,3,'DONE','Process exited normally.',1494282702),(796,3,'WAIT','Waiting 180 second(s) to restart process.',1494282702),(797,2,'INIT','Starting process.',1494282822),(798,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282822),(799,2,'DONE','Process exited normally.',1494282822),(800,2,'WAIT','Waiting 180 second(s) to restart process.',1494282822),(801,1,'INIT','Starting process.',1494282823),(802,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282824),(803,1,'DONE','Process exited normally.',1494282824),(804,1,'WAIT','Waiting 180 second(s) to restart process.',1494282824),(805,3,'INIT','Starting process.',1494282882),(806,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494282898),(807,3,'DONE','Process exited normally.',1494282898),(808,3,'WAIT','Waiting 180 second(s) to restart process.',1494282898),(809,2,'INIT','Starting process.',1494283002),(810,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283003),(811,2,'DONE','Process exited normally.',1494283003),(812,2,'WAIT','Waiting 180 second(s) to restart process.',1494283003),(813,1,'INIT','Starting process.',1494283004),(814,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283004),(815,1,'DONE','Process exited normally.',1494283004),(816,1,'WAIT','Waiting 180 second(s) to restart process.',1494283004),(817,3,'INIT','Starting process.',1494283078),(818,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283094),(819,3,'DONE','Process exited normally.',1494283094),(820,3,'WAIT','Waiting 180 second(s) to restart process.',1494283094),(821,2,'INIT','Starting process.',1494283183),(822,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283183),(823,2,'DONE','Process exited normally.',1494283183),(824,2,'WAIT','Waiting 180 second(s) to restart process.',1494283183),(825,1,'INIT','Starting process.',1494283184),(826,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283184),(827,1,'DONE','Process exited normally.',1494283184),(828,1,'WAIT','Waiting 180 second(s) to restart process.',1494283184),(829,3,'INIT','Starting process.',1494283274),(830,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283290),(831,3,'DONE','Process exited normally.',1494283290),(832,3,'WAIT','Waiting 180 second(s) to restart process.',1494283290),(833,2,'INIT','Starting process.',1494283363),(834,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283363),(835,2,'DONE','Process exited normally.',1494283363),(836,2,'WAIT','Waiting 180 second(s) to restart process.',1494283363),(837,1,'INIT','Starting process.',1494283364),(838,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283365),(839,1,'DONE','Process exited normally.',1494283365),(840,1,'WAIT','Waiting 180 second(s) to restart process.',1494283365),(841,3,'INIT','Starting process.',1494283470),(842,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283486),(843,3,'DONE','Process exited normally.',1494283486),(844,3,'WAIT','Waiting 180 second(s) to restart process.',1494283486),(845,2,'INIT','Starting process.',1494283543),(846,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283544),(847,2,'DONE','Process exited normally.',1494283544),(848,2,'WAIT','Waiting 180 second(s) to restart process.',1494283544),(849,1,'INIT','Starting process.',1494283545),(850,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283545),(851,1,'DONE','Process exited normally.',1494283545),(852,1,'WAIT','Waiting 180 second(s) to restart process.',1494283545),(853,3,'INIT','Starting process.',1494283666),(854,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283683),(855,3,'DONE','Process exited normally.',1494283683),(856,3,'WAIT','Waiting 180 second(s) to restart process.',1494283683),(857,2,'INIT','Starting process.',1494283724),(858,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283724),(859,2,'DONE','Process exited normally.',1494283724),(860,2,'WAIT','Waiting 180 second(s) to restart process.',1494283724),(861,1,'INIT','Starting process.',1494283725),(862,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283725),(863,1,'DONE','Process exited normally.',1494283725),(864,1,'WAIT','Waiting 180 second(s) to restart process.',1494283725),(865,3,'INIT','Starting process.',1494283863),(866,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283879),(867,3,'DONE','Process exited normally.',1494283879),(868,3,'WAIT','Waiting 180 second(s) to restart process.',1494283879),(869,2,'INIT','Starting process.',1494283904),(870,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283904),(871,2,'DONE','Process exited normally.',1494283904),(872,2,'WAIT','Waiting 180 second(s) to restart process.',1494283904),(873,1,'INIT','Starting process.',1494283906),(874,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494283906),(875,1,'DONE','Process exited normally.',1494283906),(876,1,'WAIT','Waiting 180 second(s) to restart process.',1494283906),(877,3,'INIT','Starting process.',1494284059),(878,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284075),(879,3,'DONE','Process exited normally.',1494284075),(880,3,'WAIT','Waiting 180 second(s) to restart process.',1494284075),(881,2,'INIT','Starting process.',1494284084),(882,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284085),(883,2,'DONE','Process exited normally.',1494284085),(884,2,'WAIT','Waiting 180 second(s) to restart process.',1494284085),(885,1,'INIT','Starting process.',1494284086),(886,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284086),(887,1,'DONE','Process exited normally.',1494284086),(888,1,'WAIT','Waiting 180 second(s) to restart process.',1494284086),(889,3,'INIT','Starting process.',1494284255),(890,2,'INIT','Starting process.',1494284265),(891,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284265),(892,2,'DONE','Process exited normally.',1494284265),(893,2,'WAIT','Waiting 180 second(s) to restart process.',1494284265),(894,1,'INIT','Starting process.',1494284266),(895,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284266),(896,1,'DONE','Process exited normally.',1494284266),(897,1,'WAIT','Waiting 180 second(s) to restart process.',1494284266),(898,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284271),(899,3,'DONE','Process exited normally.',1494284271),(900,3,'WAIT','Waiting 180 second(s) to restart process.',1494284271),(901,2,'INIT','Starting process.',1494284445),(902,1,'INIT','Starting process.',1494284446),(903,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284446),(904,2,'DONE','Process exited normally.',1494284446),(905,2,'WAIT','Waiting 180 second(s) to restart process.',1494284446),(906,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284446),(907,1,'DONE','Process exited normally.',1494284446),(908,1,'WAIT','Waiting 180 second(s) to restart process.',1494284446),(909,3,'INIT','Starting process.',1494284451),(910,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284467),(911,3,'DONE','Process exited normally.',1494284467),(912,3,'WAIT','Waiting 180 second(s) to restart process.',1494284467),(913,1,'INIT','Starting process.',1494284626),(914,2,'INIT','Starting process.',1494284626),(915,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284626),(916,1,'DONE','Process exited normally.',1494284626),(917,1,'WAIT','Waiting 180 second(s) to restart process.',1494284626),(918,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284626),(919,2,'DONE','Process exited normally.',1494284626),(920,2,'WAIT','Waiting 180 second(s) to restart process.',1494284626),(921,3,'INIT','Starting process.',1494284647),(922,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284663),(923,3,'DONE','Process exited normally.',1494284663),(924,3,'WAIT','Waiting 180 second(s) to restart process.',1494284663),(925,1,'INIT','Starting process.',1494284806),(926,2,'INIT','Starting process.',1494284806),(927,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284806),(928,1,'DONE','Process exited normally.',1494284806),(929,1,'WAIT','Waiting 180 second(s) to restart process.',1494284806),(930,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284806),(931,2,'DONE','Process exited normally.',1494284806),(932,2,'WAIT','Waiting 180 second(s) to restart process.',1494284806),(933,3,'INIT','Starting process.',1494284843),(934,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284859),(935,3,'DONE','Process exited normally.',1494284859),(936,3,'WAIT','Waiting 180 second(s) to restart process.',1494284859),(937,1,'INIT','Starting process.',1494284986),(938,2,'INIT','Starting process.',1494284986),(939,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284986),(940,1,'DONE','Process exited normally.',1494284986),(941,1,'WAIT','Waiting 180 second(s) to restart process.',1494284986),(942,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494284986),(943,2,'DONE','Process exited normally.',1494284986),(944,2,'WAIT','Waiting 180 second(s) to restart process.',1494284986),(945,3,'INIT','Starting process.',1494285039),(946,3,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494285055),(947,3,'DONE','Process exited normally.',1494285055),(948,3,'WAIT','Waiting 179 second(s) to restart process.',1494285056),(949,1,'INIT','Starting process.',1494285166),(950,2,'INIT','Starting process.',1494285166),(951,1,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494285166),(952,1,'DONE','Process exited normally.',1494285166),(953,1,'WAIT','Waiting 180 second(s) to restart process.',1494285166),(954,2,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494285166),(955,2,'DONE','Process exited normally.',1494285166),(956,2,'WAIT','Waiting 180 second(s) to restart process.',1494285166),(957,4,'INIT','Starting process.',1494292740),(958,5,'INIT','Starting process.',1494292740),(959,6,'INIT','Starting process.',1494292740),(960,4,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494292740),(961,4,'DONE','Process exited normally.',1494292740),(962,4,'WAIT','Waiting 180 second(s) to restart process.',1494292740),(963,5,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494292740),(964,5,'DONE','Process exited normally.',1494292740),(965,5,'WAIT','Waiting 180 second(s) to restart process.',1494292740),(966,6,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494292756),(967,6,'DONE','Process exited normally.',1494292756),(968,6,'WAIT','Waiting 180 second(s) to restart process.',1494292756),(969,7,'INIT','Starting process.',1494366399),(970,8,'INIT','Starting process.',1494366399),(971,9,'INIT','Starting process.',1494366399),(972,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366399),(973,7,'DONE','Process exited normally.',1494366399),(974,7,'WAIT','Waiting 180 second(s) to restart process.',1494366399),(975,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366399),(976,8,'DONE','Process exited normally.',1494366399),(977,8,'WAIT','Waiting 180 second(s) to restart process.',1494366399),(978,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366415),(979,9,'DONE','Process exited normally.',1494366415),(980,9,'WAIT','Waiting 180 second(s) to restart process.',1494366415),(981,7,'INIT','Starting process.',1494366579),(982,8,'INIT','Starting process.',1494366579),(983,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366580),(984,7,'DONE','Process exited normally.',1494366580),(985,7,'WAIT','Waiting 180 second(s) to restart process.',1494366580),(986,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366580),(987,8,'DONE','Process exited normally.',1494366580),(988,8,'WAIT','Waiting 180 second(s) to restart process.',1494366580),(989,9,'INIT','Starting process.',1494366595),(990,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366611),(991,9,'DONE','Process exited normally.',1494366611),(992,9,'WAIT','Waiting 180 second(s) to restart process.',1494366611),(993,7,'INIT','Starting process.',1494366760),(994,8,'INIT','Starting process.',1494366760),(995,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366761),(996,7,'DONE','Process exited normally.',1494366761),(997,7,'WAIT','Waiting 180 second(s) to restart process.',1494366761),(998,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366761),(999,8,'DONE','Process exited normally.',1494366761),(1000,8,'WAIT','Waiting 180 second(s) to restart process.',1494366761),(1001,9,'INIT','Starting process.',1494366791),(1002,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366807),(1003,9,'DONE','Process exited normally.',1494366807),(1004,9,'WAIT','Waiting 180 second(s) to restart process.',1494366807),(1005,7,'INIT','Starting process.',1494366941),(1006,8,'INIT','Starting process.',1494366941),(1007,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366942),(1008,7,'DONE','Process exited normally.',1494366942),(1009,7,'WAIT','Waiting 180 second(s) to restart process.',1494366942),(1010,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494366942),(1011,8,'DONE','Process exited normally.',1494366942),(1012,8,'WAIT','Waiting 180 second(s) to restart process.',1494366942),(1013,9,'INIT','Starting process.',1494366987),(1014,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367003),(1015,9,'DONE','Process exited normally.',1494367003),(1016,9,'WAIT','Waiting 180 second(s) to restart process.',1494367003),(1017,7,'INIT','Starting process.',1494367122),(1018,8,'INIT','Starting process.',1494367123),(1019,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367123),(1020,7,'DONE','Process exited normally.',1494367123),(1021,7,'WAIT','Waiting 180 second(s) to restart process.',1494367123),(1022,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367123),(1023,8,'DONE','Process exited normally.',1494367123),(1024,8,'WAIT','Waiting 180 second(s) to restart process.',1494367123),(1025,9,'INIT','Starting process.',1494367183),(1026,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367199),(1027,9,'DONE','Process exited normally.',1494367199),(1028,9,'WAIT','Waiting 180 second(s) to restart process.',1494367199),(1029,7,'INIT','Starting process.',1494367303),(1030,8,'INIT','Starting process.',1494367303),(1031,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367303),(1032,7,'DONE','Process exited normally.',1494367303),(1033,7,'WAIT','Waiting 180 second(s) to restart process.',1494367303),(1034,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367303),(1035,8,'DONE','Process exited normally.',1494367303),(1036,8,'WAIT','Waiting 180 second(s) to restart process.',1494367303),(1037,9,'INIT','Starting process.',1494367379),(1038,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367395),(1039,9,'DONE','Process exited normally.',1494367395),(1040,9,'WAIT','Waiting 180 second(s) to restart process.',1494367395),(1041,7,'INIT','Starting process.',1494367483),(1042,8,'INIT','Starting process.',1494367483),(1043,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367483),(1044,7,'DONE','Process exited normally.',1494367483),(1045,7,'WAIT','Waiting 180 second(s) to restart process.',1494367483),(1046,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367483),(1047,8,'DONE','Process exited normally.',1494367483),(1048,8,'WAIT','Waiting 180 second(s) to restart process.',1494367483),(1049,9,'INIT','Starting process.',1494367575),(1050,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367591),(1051,9,'DONE','Process exited normally.',1494367591),(1052,9,'WAIT','Waiting 180 second(s) to restart process.',1494367591),(1053,7,'INIT','Starting process.',1494367663),(1054,8,'INIT','Starting process.',1494367663),(1055,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367663),(1056,7,'DONE','Process exited normally.',1494367663),(1057,7,'WAIT','Waiting 180 second(s) to restart process.',1494367663),(1058,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367663),(1059,8,'DONE','Process exited normally.',1494367663),(1060,8,'WAIT','Waiting 180 second(s) to restart process.',1494367663),(1061,9,'INIT','Starting process.',1494367771),(1062,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367788),(1063,9,'DONE','Process exited normally.',1494367788),(1064,9,'WAIT','Waiting 180 second(s) to restart process.',1494367788),(1065,7,'INIT','Starting process.',1494367843),(1066,8,'INIT','Starting process.',1494367843),(1067,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367843),(1068,7,'DONE','Process exited normally.',1494367843),(1069,7,'WAIT','Waiting 180 second(s) to restart process.',1494367843),(1070,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367843),(1071,8,'DONE','Process exited normally.',1494367843),(1072,8,'WAIT','Waiting 180 second(s) to restart process.',1494367843),(1073,9,'INIT','Starting process.',1494367968),(1074,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494367985),(1075,9,'DONE','Process exited normally.',1494367985),(1076,9,'WAIT','Waiting 180 second(s) to restart process.',1494367985),(1077,7,'INIT','Starting process.',1494368023),(1078,8,'INIT','Starting process.',1494368023),(1079,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368023),(1080,7,'DONE','Process exited normally.',1494368023),(1081,7,'WAIT','Waiting 180 second(s) to restart process.',1494368023),(1082,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368023),(1083,8,'DONE','Process exited normally.',1494368023),(1084,8,'WAIT','Waiting 180 second(s) to restart process.',1494368023),(1085,9,'INIT','Starting process.',1494368165),(1086,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368182),(1087,9,'DONE','Process exited normally.',1494368182),(1088,9,'WAIT','Waiting 180 second(s) to restart process.',1494368182),(1089,7,'INIT','Starting process.',1494368203),(1090,8,'INIT','Starting process.',1494368203),(1091,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368203),(1092,7,'DONE','Process exited normally.',1494368203),(1093,7,'WAIT','Waiting 180 second(s) to restart process.',1494368203),(1094,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368203),(1095,8,'DONE','Process exited normally.',1494368203),(1096,8,'WAIT','Waiting 180 second(s) to restart process.',1494368203),(1097,9,'INIT','Starting process.',1494368362),(1098,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368378),(1099,9,'DONE','Process exited normally.',1494368378),(1100,9,'WAIT','Waiting 180 second(s) to restart process.',1494368378),(1101,7,'INIT','Starting process.',1494368383),(1102,8,'INIT','Starting process.',1494368383),(1103,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368383),(1104,7,'DONE','Process exited normally.',1494368383),(1105,7,'WAIT','Waiting 180 second(s) to restart process.',1494368383),(1106,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368383),(1107,8,'DONE','Process exited normally.',1494368383),(1108,8,'WAIT','Waiting 180 second(s) to restart process.',1494368383),(1109,9,'INIT','Starting process.',1494368558),(1110,7,'INIT','Starting process.',1494368563),(1111,8,'INIT','Starting process.',1494368563),(1112,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368563),(1113,7,'DONE','Process exited normally.',1494368563),(1114,7,'WAIT','Waiting 180 second(s) to restart process.',1494368563),(1115,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368563),(1116,8,'DONE','Process exited normally.',1494368563),(1117,8,'WAIT','Waiting 180 second(s) to restart process.',1494368563),(1118,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368574),(1119,9,'DONE','Process exited normally.',1494368574),(1120,9,'WAIT','Waiting 180 second(s) to restart process.',1494368574),(1121,7,'INIT','Starting process.',1494368743),(1122,8,'INIT','Starting process.',1494368743),(1123,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368744),(1124,7,'DONE','Process exited normally.',1494368744),(1125,7,'WAIT','Waiting 180 second(s) to restart process.',1494368744),(1126,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368744),(1127,8,'DONE','Process exited normally.',1494368744),(1128,8,'WAIT','Waiting 180 second(s) to restart process.',1494368744),(1129,9,'INIT','Starting process.',1494368754),(1130,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368770),(1131,9,'DONE','Process exited normally.',1494368770),(1132,9,'WAIT','Waiting 180 second(s) to restart process.',1494368770),(1133,7,'INIT','Starting process.',1494368924),(1134,8,'INIT','Starting process.',1494368924),(1135,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368925),(1136,7,'DONE','Process exited normally.',1494368925),(1137,7,'WAIT','Waiting 180 second(s) to restart process.',1494368925),(1138,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368925),(1139,8,'DONE','Process exited normally.',1494368925),(1140,8,'WAIT','Waiting 180 second(s) to restart process.',1494368925),(1141,9,'INIT','Starting process.',1494368950),(1142,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494368966),(1143,9,'DONE','Process exited normally.',1494368966),(1144,9,'WAIT','Waiting 180 second(s) to restart process.',1494368966),(1145,7,'INIT','Starting process.',1494369105),(1146,8,'INIT','Starting process.',1494369105),(1147,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369106),(1148,7,'DONE','Process exited normally.',1494369106),(1149,7,'WAIT','Waiting 180 second(s) to restart process.',1494369106),(1150,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369106),(1151,8,'DONE','Process exited normally.',1494369106),(1152,8,'WAIT','Waiting 180 second(s) to restart process.',1494369106),(1153,9,'INIT','Starting process.',1494369146),(1154,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369162),(1155,9,'DONE','Process exited normally.',1494369162),(1156,9,'WAIT','Waiting 180 second(s) to restart process.',1494369162),(1157,7,'INIT','Starting process.',1494369286),(1158,8,'INIT','Starting process.',1494369287),(1159,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369287),(1160,7,'DONE','Process exited normally.',1494369287),(1161,7,'WAIT','Waiting 180 second(s) to restart process.',1494369287),(1162,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369287),(1163,8,'DONE','Process exited normally.',1494369287),(1164,8,'WAIT','Waiting 180 second(s) to restart process.',1494369287),(1165,9,'INIT','Starting process.',1494369342),(1166,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369358),(1167,9,'DONE','Process exited normally.',1494369358),(1168,9,'WAIT','Waiting 180 second(s) to restart process.',1494369358),(1169,7,'INIT','Starting process.',1494369467),(1170,8,'INIT','Starting process.',1494369467),(1171,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369467),(1172,7,'DONE','Process exited normally.',1494369467),(1173,7,'WAIT','Waiting 180 second(s) to restart process.',1494369467),(1174,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369467),(1175,8,'DONE','Process exited normally.',1494369467),(1176,8,'WAIT','Waiting 180 second(s) to restart process.',1494369467),(1177,9,'INIT','Starting process.',1494369538),(1178,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369554),(1179,9,'DONE','Process exited normally.',1494369554),(1180,9,'WAIT','Waiting 180 second(s) to restart process.',1494369554),(1181,7,'INIT','Starting process.',1494369647),(1182,8,'INIT','Starting process.',1494369647),(1183,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369647),(1184,7,'DONE','Process exited normally.',1494369647),(1185,7,'WAIT','Waiting 180 second(s) to restart process.',1494369647),(1186,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369647),(1187,8,'DONE','Process exited normally.',1494369647),(1188,8,'WAIT','Waiting 180 second(s) to restart process.',1494369647),(1189,9,'INIT','Starting process.',1494369734),(1190,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369750),(1191,9,'DONE','Process exited normally.',1494369750),(1192,9,'WAIT','Waiting 180 second(s) to restart process.',1494369750),(1193,7,'INIT','Starting process.',1494369827),(1194,8,'INIT','Starting process.',1494369827),(1195,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369827),(1196,7,'DONE','Process exited normally.',1494369827),(1197,7,'WAIT','Waiting 180 second(s) to restart process.',1494369827),(1198,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369827),(1199,8,'DONE','Process exited normally.',1494369827),(1200,8,'WAIT','Waiting 180 second(s) to restart process.',1494369827),(1201,9,'INIT','Starting process.',1494369930),(1202,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494369947),(1203,9,'DONE','Process exited normally.',1494369947),(1204,9,'WAIT','Waiting 180 second(s) to restart process.',1494369947),(1205,7,'INIT','Starting process.',1494370007),(1206,8,'INIT','Starting process.',1494370007),(1207,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370007),(1208,7,'DONE','Process exited normally.',1494370007),(1209,7,'WAIT','Waiting 180 second(s) to restart process.',1494370007),(1210,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370007),(1211,8,'DONE','Process exited normally.',1494370007),(1212,8,'WAIT','Waiting 180 second(s) to restart process.',1494370007),(1213,9,'INIT','Starting process.',1494370127),(1214,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370144),(1215,9,'DONE','Process exited normally.',1494370144),(1216,9,'WAIT','Waiting 180 second(s) to restart process.',1494370144),(1217,7,'INIT','Starting process.',1494370187),(1218,8,'INIT','Starting process.',1494370187),(1219,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370187),(1220,7,'DONE','Process exited normally.',1494370187),(1221,7,'WAIT','Waiting 180 second(s) to restart process.',1494370187),(1222,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370187),(1223,8,'DONE','Process exited normally.',1494370187),(1224,8,'WAIT','Waiting 180 second(s) to restart process.',1494370187),(1225,9,'INIT','Starting process.',1494370324),(1226,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370341),(1227,9,'DONE','Process exited normally.',1494370341),(1228,9,'WAIT','Waiting 180 second(s) to restart process.',1494370341),(1229,7,'INIT','Starting process.',1494370367),(1230,8,'INIT','Starting process.',1494370367),(1231,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370367),(1232,7,'DONE','Process exited normally.',1494370367),(1233,7,'WAIT','Waiting 180 second(s) to restart process.',1494370367),(1234,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370367),(1235,8,'DONE','Process exited normally.',1494370367),(1236,8,'WAIT','Waiting 180 second(s) to restart process.',1494370367),(1237,9,'INIT','Starting process.',1494370521),(1238,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370538),(1239,9,'DONE','Process exited normally.',1494370538),(1240,9,'WAIT','Waiting 180 second(s) to restart process.',1494370538),(1241,7,'INIT','Starting process.',1494370547),(1242,8,'INIT','Starting process.',1494370547),(1243,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370547),(1244,7,'DONE','Process exited normally.',1494370547),(1245,7,'WAIT','Waiting 180 second(s) to restart process.',1494370547),(1246,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370547),(1247,8,'DONE','Process exited normally.',1494370547),(1248,8,'WAIT','Waiting 180 second(s) to restart process.',1494370547),(1249,9,'INIT','Starting process.',1494370718),(1250,7,'INIT','Starting process.',1494370727),(1251,8,'INIT','Starting process.',1494370727),(1252,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370727),(1253,7,'DONE','Process exited normally.',1494370727),(1254,7,'WAIT','Waiting 180 second(s) to restart process.',1494370727),(1255,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370727),(1256,8,'DONE','Process exited normally.',1494370727),(1257,8,'WAIT','Waiting 180 second(s) to restart process.',1494370727),(1258,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370734),(1259,9,'DONE','Process exited normally.',1494370734),(1260,9,'WAIT','Waiting 180 second(s) to restart process.',1494370734),(1261,7,'INIT','Starting process.',1494370907),(1262,8,'INIT','Starting process.',1494370907),(1263,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370907),(1264,7,'DONE','Process exited normally.',1494370908),(1265,7,'WAIT','Waiting 179 second(s) to restart process.',1494370908),(1266,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494370908),(1267,8,'DONE','Process exited normally.',1494370908),(1268,8,'WAIT','Waiting 179 second(s) to restart process.',1494370908),(1269,9,'INIT','Starting process.',1494370914),(1270,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494370930),(1271,9,'DONE','Process exited normally.',1494370930),(1272,9,'WAIT','Waiting 180 second(s) to restart process.',1494370930),(1273,7,'INIT','Starting process.',1494371087),(1274,8,'INIT','Starting process.',1494371087),(1275,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371088),(1276,7,'DONE','Process exited normally.',1494371088),(1277,7,'WAIT','Waiting 180 second(s) to restart process.',1494371088),(1278,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371088),(1279,8,'DONE','Process exited normally.',1494371088),(1280,8,'WAIT','Waiting 180 second(s) to restart process.',1494371088),(1281,9,'INIT','Starting process.',1494371110),(1282,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371126),(1283,9,'DONE','Process exited normally.',1494371126),(1284,9,'WAIT','Waiting 180 second(s) to restart process.',1494371126),(1285,7,'INIT','Starting process.',1494371268),(1286,8,'INIT','Starting process.',1494371268),(1287,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371269),(1288,7,'DONE','Process exited normally.',1494371269),(1289,7,'WAIT','Waiting 180 second(s) to restart process.',1494371269),(1290,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371269),(1291,8,'DONE','Process exited normally.',1494371269),(1292,8,'WAIT','Waiting 180 second(s) to restart process.',1494371269),(1293,9,'INIT','Starting process.',1494371306),(1294,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371322),(1295,9,'DONE','Process exited normally.',1494371322),(1296,9,'WAIT','Waiting 180 second(s) to restart process.',1494371322),(1297,7,'INIT','Starting process.',1494371449),(1298,8,'INIT','Starting process.',1494371449),(1299,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371450),(1300,7,'DONE','Process exited normally.',1494371450),(1301,7,'WAIT','Waiting 180 second(s) to restart process.',1494371450),(1302,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371450),(1303,8,'DONE','Process exited normally.',1494371450),(1304,8,'WAIT','Waiting 180 second(s) to restart process.',1494371450),(1305,9,'INIT','Starting process.',1494371502),(1306,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371518),(1307,9,'DONE','Process exited normally.',1494371518),(1308,9,'WAIT','Waiting 180 second(s) to restart process.',1494371518),(1309,7,'INIT','Starting process.',1494371630),(1310,8,'INIT','Starting process.',1494371630),(1311,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371631),(1312,7,'DONE','Process exited normally.',1494371631),(1313,7,'WAIT','Waiting 180 second(s) to restart process.',1494371631),(1314,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371631),(1315,8,'DONE','Process exited normally.',1494371631),(1316,8,'WAIT','Waiting 180 second(s) to restart process.',1494371631),(1317,9,'INIT','Starting process.',1494371698),(1318,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371714),(1319,9,'DONE','Process exited normally.',1494371714),(1320,9,'WAIT','Waiting 180 second(s) to restart process.',1494371714),(1321,7,'INIT','Starting process.',1494371811),(1322,8,'INIT','Starting process.',1494371812),(1323,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371812),(1324,7,'DONE','Process exited normally.',1494371812),(1325,7,'WAIT','Waiting 180 second(s) to restart process.',1494371812),(1326,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371812),(1327,8,'DONE','Process exited normally.',1494371812),(1328,8,'WAIT','Waiting 180 second(s) to restart process.',1494371812),(1329,9,'INIT','Starting process.',1494371894),(1330,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371910),(1331,9,'DONE','Process exited normally.',1494371910),(1332,9,'WAIT','Waiting 180 second(s) to restart process.',1494371910),(1333,7,'INIT','Starting process.',1494371992),(1334,8,'INIT','Starting process.',1494371992),(1335,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371992),(1336,7,'DONE','Process exited normally.',1494371992),(1337,7,'WAIT','Waiting 180 second(s) to restart process.',1494371992),(1338,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494371992),(1339,8,'DONE','Process exited normally.',1494371992),(1340,8,'WAIT','Waiting 180 second(s) to restart process.',1494371992),(1341,9,'INIT','Starting process.',1494372090),(1342,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372106),(1343,9,'DONE','Process exited normally.',1494372106),(1344,9,'WAIT','Waiting 180 second(s) to restart process.',1494372106),(1345,7,'INIT','Starting process.',1494372172),(1346,8,'INIT','Starting process.',1494372172),(1347,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372172),(1348,7,'DONE','Process exited normally.',1494372172),(1349,7,'WAIT','Waiting 180 second(s) to restart process.',1494372172),(1350,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372172),(1351,8,'DONE','Process exited normally.',1494372172),(1352,8,'WAIT','Waiting 180 second(s) to restart process.',1494372172),(1353,9,'INIT','Starting process.',1494372286),(1354,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372303),(1355,9,'DONE','Process exited normally.',1494372303),(1356,9,'WAIT','Waiting 180 second(s) to restart process.',1494372303),(1357,7,'INIT','Starting process.',1494372352),(1358,8,'INIT','Starting process.',1494372352),(1359,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372352),(1360,7,'DONE','Process exited normally.',1494372352),(1361,7,'WAIT','Waiting 180 second(s) to restart process.',1494372352),(1362,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372352),(1363,8,'DONE','Process exited normally.',1494372352),(1364,8,'WAIT','Waiting 180 second(s) to restart process.',1494372352),(1365,9,'INIT','Starting process.',1494372483),(1366,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372500),(1367,9,'DONE','Process exited normally.',1494372500),(1368,9,'WAIT','Waiting 180 second(s) to restart process.',1494372500),(1369,7,'INIT','Starting process.',1494372532),(1370,8,'INIT','Starting process.',1494372532),(1371,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372532),(1372,7,'DONE','Process exited normally.',1494372532),(1373,7,'WAIT','Waiting 180 second(s) to restart process.',1494372532),(1374,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372532),(1375,8,'DONE','Process exited normally.',1494372532),(1376,8,'WAIT','Waiting 180 second(s) to restart process.',1494372532),(1377,9,'INIT','Starting process.',1494372680),(1378,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372697),(1379,9,'DONE','Process exited normally.',1494372697),(1380,9,'WAIT','Waiting 180 second(s) to restart process.',1494372697),(1381,7,'INIT','Starting process.',1494372712),(1382,8,'INIT','Starting process.',1494372712),(1383,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372712),(1384,7,'DONE','Process exited normally.',1494372712),(1385,7,'WAIT','Waiting 180 second(s) to restart process.',1494372712),(1386,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372712),(1387,8,'DONE','Process exited normally.',1494372712),(1388,8,'WAIT','Waiting 180 second(s) to restart process.',1494372712),(1389,9,'INIT','Starting process.',1494372877),(1390,7,'INIT','Starting process.',1494372892),(1391,8,'INIT','Starting process.',1494372892),(1392,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372892),(1393,7,'DONE','Process exited normally.',1494372892),(1394,7,'WAIT','Waiting 180 second(s) to restart process.',1494372892),(1395,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372892),(1396,8,'DONE','Process exited normally.',1494372892),(1397,8,'WAIT','Waiting 180 second(s) to restart process.',1494372892),(1398,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494372894),(1399,9,'DONE','Process exited normally.',1494372894),(1400,9,'WAIT','Waiting 180 second(s) to restart process.',1494372894),(1401,7,'INIT','Starting process.',1494373072),(1402,8,'INIT','Starting process.',1494373072),(1403,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373072),(1404,7,'DONE','Process exited normally.',1494373072),(1405,7,'WAIT','Waiting 180 second(s) to restart process.',1494373072),(1406,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494373073),(1407,8,'DONE','Process exited normally.',1494373073),(1408,8,'WAIT','Waiting 179 second(s) to restart process.',1494373073),(1409,9,'INIT','Starting process.',1494373074),(1410,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373090),(1411,9,'DONE','Process exited normally.',1494373090),(1412,9,'WAIT','Waiting 180 second(s) to restart process.',1494373090),(1413,7,'INIT','Starting process.',1494373252),(1414,8,'INIT','Starting process.',1494373252),(1415,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373252),(1416,7,'DONE','Process exited normally.',1494373253),(1417,7,'WAIT','Waiting 179 second(s) to restart process.',1494373253),(1418,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373253),(1419,8,'DONE','Process exited normally.',1494373253),(1420,8,'WAIT','Waiting 180 second(s) to restart process.',1494373253),(1421,9,'INIT','Starting process.',1494373270),(1422,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373286),(1423,9,'DONE','Process exited normally.',1494373286),(1424,9,'WAIT','Waiting 180 second(s) to restart process.',1494373286),(1425,7,'INIT','Starting process.',1494373432),(1426,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373433),(1427,7,'DONE','Process exited normally.',1494373433),(1428,7,'WAIT','Waiting 180 second(s) to restart process.',1494373433),(1429,8,'INIT','Starting process.',1494373433),(1430,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373433),(1431,8,'DONE','Process exited normally.',1494373433),(1432,8,'WAIT','Waiting 180 second(s) to restart process.',1494373433),(1433,9,'INIT','Starting process.',1494373466),(1434,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373482),(1435,9,'DONE','Process exited normally.',1494373482),(1436,9,'WAIT','Waiting 180 second(s) to restart process.',1494373482),(1437,7,'INIT','Starting process.',1494373613),(1438,8,'INIT','Starting process.',1494373613),(1439,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373613),(1440,7,'DONE','Process exited normally.',1494373613),(1441,7,'WAIT','Waiting 180 second(s) to restart process.',1494373613),(1442,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373613),(1443,8,'DONE','Process exited normally.',1494373613),(1444,8,'WAIT','Waiting 180 second(s) to restart process.',1494373613),(1445,9,'INIT','Starting process.',1494373662),(1446,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373678),(1447,9,'DONE','Process exited normally.',1494373678),(1448,9,'WAIT','Waiting 180 second(s) to restart process.',1494373678),(1449,7,'INIT','Starting process.',1494373793),(1450,8,'INIT','Starting process.',1494373793),(1451,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373793),(1452,7,'DONE','Process exited normally.',1494373793),(1453,7,'WAIT','Waiting 180 second(s) to restart process.',1494373793),(1454,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373793),(1455,8,'DONE','Process exited normally.',1494373793),(1456,8,'WAIT','Waiting 180 second(s) to restart process.',1494373793),(1457,9,'INIT','Starting process.',1494373858),(1458,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373874),(1459,9,'DONE','Process exited normally.',1494373874),(1460,9,'WAIT','Waiting 180 second(s) to restart process.',1494373874),(1461,7,'INIT','Starting process.',1494373973),(1462,8,'INIT','Starting process.',1494373973),(1463,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373973),(1464,7,'DONE','Process exited normally.',1494373973),(1465,7,'WAIT','Waiting 180 second(s) to restart process.',1494373973),(1466,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494373973),(1467,8,'DONE','Process exited normally.',1494373973),(1468,8,'WAIT','Waiting 180 second(s) to restart process.',1494373973),(1469,9,'INIT','Starting process.',1494374054),(1470,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374071),(1471,9,'DONE','Process exited normally.',1494374071),(1472,9,'WAIT','Waiting 180 second(s) to restart process.',1494374071),(1473,7,'INIT','Starting process.',1494374153),(1474,8,'INIT','Starting process.',1494374153),(1475,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374153),(1476,7,'DONE','Process exited normally.',1494374153),(1477,7,'WAIT','Waiting 180 second(s) to restart process.',1494374153),(1478,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374153),(1479,8,'DONE','Process exited normally.',1494374153),(1480,8,'WAIT','Waiting 180 second(s) to restart process.',1494374153),(1481,9,'INIT','Starting process.',1494374251),(1482,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374268),(1483,9,'DONE','Process exited normally.',1494374268),(1484,9,'WAIT','Waiting 180 second(s) to restart process.',1494374268),(1485,7,'INIT','Starting process.',1494374333),(1486,8,'INIT','Starting process.',1494374333),(1487,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374333),(1488,7,'DONE','Process exited normally.',1494374333),(1489,7,'WAIT','Waiting 180 second(s) to restart process.',1494374333),(1490,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374333),(1491,8,'DONE','Process exited normally.',1494374333),(1492,8,'WAIT','Waiting 180 second(s) to restart process.',1494374333),(1493,9,'INIT','Starting process.',1494374448),(1494,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374464),(1495,9,'DONE','Process exited normally.',1494374464),(1496,9,'WAIT','Waiting 180 second(s) to restart process.',1494374464),(1497,7,'INIT','Starting process.',1494374513),(1498,8,'INIT','Starting process.',1494374513),(1499,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374513),(1500,7,'DONE','Process exited normally.',1494374513),(1501,7,'WAIT','Waiting 180 second(s) to restart process.',1494374513),(1502,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374513),(1503,8,'DONE','Process exited normally.',1494374513),(1504,8,'WAIT','Waiting 180 second(s) to restart process.',1494374513),(1505,9,'INIT','Starting process.',1494374644),(1506,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374660),(1507,9,'DONE','Process exited normally.',1494374660),(1508,9,'WAIT','Waiting 180 second(s) to restart process.',1494374660),(1509,7,'INIT','Starting process.',1494374693),(1510,8,'INIT','Starting process.',1494374693),(1511,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374693),(1512,7,'DONE','Process exited normally.',1494374693),(1513,7,'WAIT','Waiting 180 second(s) to restart process.',1494374693),(1514,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374693),(1515,8,'DONE','Process exited normally.',1494374693),(1516,8,'WAIT','Waiting 180 second(s) to restart process.',1494374693),(1517,9,'INIT','Starting process.',1494374840),(1518,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374856),(1519,9,'DONE','Process exited normally.',1494374856),(1520,9,'WAIT','Waiting 180 second(s) to restart process.',1494374856),(1521,7,'INIT','Starting process.',1494374873),(1522,8,'INIT','Starting process.',1494374873),(1523,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374873),(1524,7,'DONE','Process exited normally.',1494374873),(1525,7,'WAIT','Waiting 180 second(s) to restart process.',1494374873),(1526,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494374873),(1527,8,'DONE','Process exited normally.',1494374873),(1528,8,'WAIT','Waiting 180 second(s) to restart process.',1494374873),(1529,9,'INIT','Starting process.',1494375036),(1530,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375052),(1531,9,'DONE','Process exited normally.',1494375052),(1532,9,'WAIT','Waiting 180 second(s) to restart process.',1494375052),(1533,7,'INIT','Starting process.',1494375053),(1534,8,'INIT','Starting process.',1494375053),(1535,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375053),(1536,7,'DONE','Process exited normally.',1494375053),(1537,7,'WAIT','Waiting 180 second(s) to restart process.',1494375053),(1538,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494375054),(1539,8,'DONE','Process exited normally.',1494375054),(1540,8,'WAIT','Waiting 179 second(s) to restart process.',1494375054),(1541,9,'INIT','Starting process.',1494375232),(1542,7,'INIT','Starting process.',1494375233),(1543,8,'INIT','Starting process.',1494375233),(1544,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375233),(1545,7,'DONE','Process exited normally.',1494375233),(1546,7,'WAIT','Waiting 180 second(s) to restart process.',1494375233),(1547,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375233),(1548,8,'DONE','Process exited normally.',1494375233),(1549,8,'WAIT','Waiting 180 second(s) to restart process.',1494375233),(1550,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375248),(1551,9,'DONE','Process exited normally.',1494375248),(1552,9,'WAIT','Waiting 180 second(s) to restart process.',1494375248),(1553,7,'INIT','Starting process.',1494375413),(1554,8,'INIT','Starting process.',1494375413),(1555,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375413),(1556,7,'DONE','Process exited normally.',1494375413),(1557,7,'WAIT','Waiting 180 second(s) to restart process.',1494375413),(1558,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375413),(1559,8,'DONE','Process exited normally.',1494375413),(1560,8,'WAIT','Waiting 180 second(s) to restart process.',1494375413),(1561,9,'INIT','Starting process.',1494375428),(1562,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375444),(1563,9,'DONE','Process exited normally.',1494375444),(1564,9,'WAIT','Waiting 180 second(s) to restart process.',1494375444),(1565,7,'INIT','Starting process.',1494375593),(1566,8,'INIT','Starting process.',1494375593),(1567,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375593),(1568,7,'DONE','Process exited normally.',1494375593),(1569,7,'WAIT','Waiting 180 second(s) to restart process.',1494375593),(1570,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375593),(1571,8,'DONE','Process exited normally.',1494375593),(1572,8,'WAIT','Waiting 180 second(s) to restart process.',1494375593),(1573,9,'INIT','Starting process.',1494375624),(1574,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375640),(1575,9,'DONE','Process exited normally.',1494375640),(1576,9,'WAIT','Waiting 180 second(s) to restart process.',1494375640),(1577,7,'INIT','Starting process.',1494375773),(1578,8,'INIT','Starting process.',1494375773),(1579,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375773),(1580,7,'DONE','Process exited normally.',1494375773),(1581,7,'WAIT','Waiting 180 second(s) to restart process.',1494375773),(1582,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375773),(1583,8,'DONE','Process exited normally.',1494375773),(1584,8,'WAIT','Waiting 180 second(s) to restart process.',1494375773),(1585,9,'INIT','Starting process.',1494375820),(1586,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375837),(1587,9,'DONE','Process exited normally.',1494375837),(1588,9,'WAIT','Waiting 180 second(s) to restart process.',1494375837),(1589,7,'INIT','Starting process.',1494375953),(1590,8,'INIT','Starting process.',1494375953),(1591,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375953),(1592,7,'DONE','Process exited normally.',1494375953),(1593,7,'WAIT','Waiting 180 second(s) to restart process.',1494375953),(1594,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494375953),(1595,8,'DONE','Process exited normally.',1494375953),(1596,8,'WAIT','Waiting 180 second(s) to restart process.',1494375953),(1597,9,'INIT','Starting process.',1494376017),(1598,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376034),(1599,9,'DONE','Process exited normally.',1494376034),(1600,9,'WAIT','Waiting 180 second(s) to restart process.',1494376034),(1601,7,'INIT','Starting process.',1494376133),(1602,8,'INIT','Starting process.',1494376133),(1603,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376133),(1604,7,'DONE','Process exited normally.',1494376133),(1605,7,'WAIT','Waiting 180 second(s) to restart process.',1494376133),(1606,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376133),(1607,8,'DONE','Process exited normally.',1494376133),(1608,8,'WAIT','Waiting 180 second(s) to restart process.',1494376133),(1609,9,'INIT','Starting process.',1494376214),(1610,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376231),(1611,9,'DONE','Process exited normally.',1494376231),(1612,9,'WAIT','Waiting 180 second(s) to restart process.',1494376231),(1613,7,'INIT','Starting process.',1494376313),(1614,8,'INIT','Starting process.',1494376313),(1615,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376313),(1616,7,'DONE','Process exited normally.',1494376313),(1617,7,'WAIT','Waiting 180 second(s) to restart process.',1494376313),(1618,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376313),(1619,8,'DONE','Process exited normally.',1494376313),(1620,8,'WAIT','Waiting 180 second(s) to restart process.',1494376313),(1621,9,'INIT','Starting process.',1494376411),(1622,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376427),(1623,9,'DONE','Process exited normally.',1494376427),(1624,9,'WAIT','Waiting 180 second(s) to restart process.',1494376427),(1625,7,'INIT','Starting process.',1494376493),(1626,8,'INIT','Starting process.',1494376493),(1627,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376493),(1628,7,'DONE','Process exited normally.',1494376493),(1629,7,'WAIT','Waiting 180 second(s) to restart process.',1494376493),(1630,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376493),(1631,8,'DONE','Process exited normally.',1494376493),(1632,8,'WAIT','Waiting 180 second(s) to restart process.',1494376493),(1633,9,'INIT','Starting process.',1494376607),(1634,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376623),(1635,9,'DONE','Process exited normally.',1494376623),(1636,9,'WAIT','Waiting 180 second(s) to restart process.',1494376623),(1637,7,'INIT','Starting process.',1494376673),(1638,8,'INIT','Starting process.',1494376673),(1639,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376673),(1640,7,'DONE','Process exited normally.',1494376673),(1641,7,'WAIT','Waiting 180 second(s) to restart process.',1494376673),(1642,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376673),(1643,8,'DONE','Process exited normally.',1494376673),(1644,8,'WAIT','Waiting 180 second(s) to restart process.',1494376673),(1645,9,'INIT','Starting process.',1494376803),(1646,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376819),(1647,9,'DONE','Process exited normally.',1494376819),(1648,9,'WAIT','Waiting 180 second(s) to restart process.',1494376819),(1649,7,'INIT','Starting process.',1494376853),(1650,8,'INIT','Starting process.',1494376853),(1651,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494376853),(1652,7,'DONE','Process exited normally.',1494376853),(1653,7,'WAIT','Waiting 180 second(s) to restart process.',1494376853),(1654,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494376854),(1655,8,'DONE','Process exited normally.',1494376854),(1656,8,'WAIT','Waiting 179 second(s) to restart process.',1494376854),(1657,9,'INIT','Starting process.',1494376999),(1658,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377015),(1659,9,'DONE','Process exited normally.',1494377015),(1660,9,'WAIT','Waiting 180 second(s) to restart process.',1494377015),(1661,7,'INIT','Starting process.',1494377033),(1662,8,'INIT','Starting process.',1494377033),(1663,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377034),(1664,7,'DONE','Process exited normally.',1494377034),(1665,7,'WAIT','Waiting 180 second(s) to restart process.',1494377034),(1666,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377034),(1667,8,'DONE','Process exited normally.',1494377034),(1668,8,'WAIT','Waiting 180 second(s) to restart process.',1494377034),(1669,9,'INIT','Starting process.',1494377195),(1670,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377211),(1671,9,'DONE','Process exited normally.',1494377211),(1672,9,'WAIT','Waiting 180 second(s) to restart process.',1494377211),(1673,7,'INIT','Starting process.',1494377214),(1674,8,'INIT','Starting process.',1494377214),(1675,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377215),(1676,7,'DONE','Process exited normally.',1494377215),(1677,7,'WAIT','Waiting 180 second(s) to restart process.',1494377215),(1678,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377215),(1679,8,'DONE','Process exited normally.',1494377215),(1680,8,'WAIT','Waiting 180 second(s) to restart process.',1494377215),(1681,9,'INIT','Starting process.',1494377391),(1682,7,'INIT','Starting process.',1494377395),(1683,8,'INIT','Starting process.',1494377395),(1684,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377395),(1685,7,'DONE','Process exited normally.',1494377395),(1686,7,'WAIT','Waiting 180 second(s) to restart process.',1494377395),(1687,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377395),(1688,8,'DONE','Process exited normally.',1494377395),(1689,8,'WAIT','Waiting 180 second(s) to restart process.',1494377395),(1690,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377407),(1691,9,'DONE','Process exited normally.',1494377407),(1692,9,'WAIT','Waiting 180 second(s) to restart process.',1494377407),(1693,7,'INIT','Starting process.',1494377575),(1694,8,'INIT','Starting process.',1494377575),(1695,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377575),(1696,7,'DONE','Process exited normally.',1494377575),(1697,7,'WAIT','Waiting 180 second(s) to restart process.',1494377575),(1698,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377575),(1699,8,'DONE','Process exited normally.',1494377575),(1700,8,'WAIT','Waiting 180 second(s) to restart process.',1494377575),(1701,9,'INIT','Starting process.',1494377587),(1702,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377603),(1703,9,'DONE','Process exited normally.',1494377603),(1704,9,'WAIT','Waiting 180 second(s) to restart process.',1494377603),(1705,7,'INIT','Starting process.',1494377755),(1706,8,'INIT','Starting process.',1494377755),(1707,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377755),(1708,7,'DONE','Process exited normally.',1494377755),(1709,7,'WAIT','Waiting 180 second(s) to restart process.',1494377755),(1710,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377755),(1711,8,'DONE','Process exited normally.',1494377755),(1712,8,'WAIT','Waiting 180 second(s) to restart process.',1494377755),(1713,9,'INIT','Starting process.',1494377783),(1714,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377799),(1715,9,'DONE','Process exited normally.',1494377799),(1716,9,'WAIT','Waiting 180 second(s) to restart process.',1494377799),(1717,7,'INIT','Starting process.',1494377935),(1718,8,'INIT','Starting process.',1494377935),(1719,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377935),(1720,7,'DONE','Process exited normally.',1494377935),(1721,7,'WAIT','Waiting 180 second(s) to restart process.',1494377935),(1722,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377935),(1723,8,'DONE','Process exited normally.',1494377935),(1724,8,'WAIT','Waiting 180 second(s) to restart process.',1494377935),(1725,9,'INIT','Starting process.',1494377979),(1726,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494377996),(1727,9,'DONE','Process exited normally.',1494377996),(1728,9,'WAIT','Waiting 180 second(s) to restart process.',1494377996),(1729,7,'INIT','Starting process.',1494378115),(1730,8,'INIT','Starting process.',1494378115),(1731,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378115),(1732,7,'DONE','Process exited normally.',1494378115),(1733,7,'WAIT','Waiting 180 second(s) to restart process.',1494378115),(1734,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378115),(1735,8,'DONE','Process exited normally.',1494378115),(1736,8,'WAIT','Waiting 180 second(s) to restart process.',1494378115),(1737,9,'INIT','Starting process.',1494378176),(1738,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378193),(1739,9,'DONE','Process exited normally.',1494378193),(1740,9,'WAIT','Waiting 180 second(s) to restart process.',1494378193),(1741,7,'INIT','Starting process.',1494378295),(1742,8,'INIT','Starting process.',1494378295),(1743,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378295),(1744,7,'DONE','Process exited normally.',1494378295),(1745,7,'WAIT','Waiting 180 second(s) to restart process.',1494378295),(1746,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378295),(1747,8,'DONE','Process exited normally.',1494378295),(1748,8,'WAIT','Waiting 180 second(s) to restart process.',1494378295),(1749,9,'INIT','Starting process.',1494378373),(1750,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378390),(1751,9,'DONE','Process exited normally.',1494378390),(1752,9,'WAIT','Waiting 180 second(s) to restart process.',1494378390),(1753,7,'INIT','Starting process.',1494378475),(1754,8,'INIT','Starting process.',1494378475),(1755,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378475),(1756,7,'DONE','Process exited normally.',1494378475),(1757,7,'WAIT','Waiting 180 second(s) to restart process.',1494378475),(1758,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378475),(1759,8,'DONE','Process exited normally.',1494378475),(1760,8,'WAIT','Waiting 180 second(s) to restart process.',1494378475),(1761,9,'INIT','Starting process.',1494378570),(1762,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378586),(1763,9,'DONE','Process exited normally.',1494378586),(1764,9,'WAIT','Waiting 180 second(s) to restart process.',1494378586),(1765,7,'INIT','Starting process.',1494378655),(1766,8,'INIT','Starting process.',1494378655),(1767,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378655),(1768,7,'DONE','Process exited normally.',1494378655),(1769,7,'WAIT','Waiting 180 second(s) to restart process.',1494378655),(1770,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378655),(1771,8,'DONE','Process exited normally.',1494378655),(1772,8,'WAIT','Waiting 180 second(s) to restart process.',1494378655),(1773,9,'INIT','Starting process.',1494378766),(1774,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378782),(1775,9,'DONE','Process exited normally.',1494378782),(1776,9,'WAIT','Waiting 180 second(s) to restart process.',1494378782),(1777,7,'INIT','Starting process.',1494378835),(1778,8,'INIT','Starting process.',1494378835),(1779,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378835),(1780,7,'DONE','Process exited normally.',1494378835),(1781,7,'WAIT','Waiting 180 second(s) to restart process.',1494378835),(1782,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378835),(1783,8,'DONE','Process exited normally.',1494378836),(1784,8,'WAIT','Waiting 179 second(s) to restart process.',1494378836),(1785,9,'INIT','Starting process.',1494378962),(1786,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494378978),(1787,9,'DONE','Process exited normally.',1494378978),(1788,9,'WAIT','Waiting 180 second(s) to restart process.',1494378978),(1789,7,'INIT','Starting process.',1494379015),(1790,8,'INIT','Starting process.',1494379015),(1791,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379016),(1792,7,'DONE','Process exited normally.',1494379016),(1793,7,'WAIT','Waiting 180 second(s) to restart process.',1494379016),(1794,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494379016),(1795,8,'DONE','Process exited normally.',1494379016),(1796,8,'WAIT','Waiting 179 second(s) to restart process.',1494379016),(1797,9,'INIT','Starting process.',1494379158),(1798,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379174),(1799,9,'DONE','Process exited normally.',1494379174),(1800,9,'WAIT','Waiting 180 second(s) to restart process.',1494379174),(1801,8,'INIT','Starting process.',1494379195),(1802,7,'INIT','Starting process.',1494379196),(1803,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379196),(1804,8,'DONE','Process exited normally.',1494379196),(1805,8,'WAIT','Waiting 180 second(s) to restart process.',1494379196),(1806,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379196),(1807,7,'DONE','Process exited normally.',1494379196),(1808,7,'WAIT','Waiting 180 second(s) to restart process.',1494379196),(1809,9,'INIT','Starting process.',1494379354),(1810,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379370),(1811,9,'DONE','Process exited normally.',1494379370),(1812,9,'WAIT','Waiting 180 second(s) to restart process.',1494379370),(1813,7,'INIT','Starting process.',1494379376),(1814,8,'INIT','Starting process.',1494379376),(1815,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379376),(1816,7,'DONE','Process exited normally.',1494379376),(1817,7,'WAIT','Waiting 180 second(s) to restart process.',1494379376),(1818,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379376),(1819,8,'DONE','Process exited normally.',1494379376),(1820,8,'WAIT','Waiting 180 second(s) to restart process.',1494379376),(1821,9,'INIT','Starting process.',1494379550),(1822,7,'INIT','Starting process.',1494379556),(1823,8,'INIT','Starting process.',1494379556),(1824,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379557),(1825,7,'DONE','Process exited normally.',1494379557),(1826,7,'WAIT','Waiting 180 second(s) to restart process.',1494379557),(1827,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379557),(1828,8,'DONE','Process exited normally.',1494379557),(1829,8,'WAIT','Waiting 180 second(s) to restart process.',1494379557),(1830,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379567),(1831,9,'DONE','Process exited normally.',1494379567),(1832,9,'WAIT','Waiting 180 second(s) to restart process.',1494379567),(1833,7,'INIT','Starting process.',1494379737),(1834,8,'INIT','Starting process.',1494379737),(1835,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379737),(1836,7,'DONE','Process exited normally.',1494379737),(1837,7,'WAIT','Waiting 180 second(s) to restart process.',1494379737),(1838,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379737),(1839,8,'DONE','Process exited normally.',1494379737),(1840,8,'WAIT','Waiting 180 second(s) to restart process.',1494379737),(1841,9,'INIT','Starting process.',1494379747),(1842,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379764),(1843,9,'DONE','Process exited normally.',1494379764),(1844,9,'WAIT','Waiting 180 second(s) to restart process.',1494379764),(1845,7,'INIT','Starting process.',1494379917),(1846,8,'INIT','Starting process.',1494379917),(1847,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379917),(1848,7,'DONE','Process exited normally.',1494379917),(1849,7,'WAIT','Waiting 180 second(s) to restart process.',1494379917),(1850,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379917),(1851,8,'DONE','Process exited normally.',1494379917),(1852,8,'WAIT','Waiting 180 second(s) to restart process.',1494379917),(1853,9,'INIT','Starting process.',1494379944),(1854,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494379961),(1855,9,'DONE','Process exited normally.',1494379961),(1856,9,'WAIT','Waiting 180 second(s) to restart process.',1494379961),(1857,7,'INIT','Starting process.',1494380097),(1858,8,'INIT','Starting process.',1494380097),(1859,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380097),(1860,7,'DONE','Process exited normally.',1494380097),(1861,7,'WAIT','Waiting 180 second(s) to restart process.',1494380097),(1862,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380097),(1863,8,'DONE','Process exited normally.',1494380097),(1864,8,'WAIT','Waiting 180 second(s) to restart process.',1494380097),(1865,9,'INIT','Starting process.',1494380141),(1866,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380157),(1867,9,'DONE','Process exited normally.',1494380157),(1868,9,'WAIT','Waiting 180 second(s) to restart process.',1494380157),(1869,7,'INIT','Starting process.',1494380277),(1870,8,'INIT','Starting process.',1494380277),(1871,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380277),(1872,7,'DONE','Process exited normally.',1494380277),(1873,7,'WAIT','Waiting 180 second(s) to restart process.',1494380277),(1874,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380277),(1875,8,'DONE','Process exited normally.',1494380277),(1876,8,'WAIT','Waiting 180 second(s) to restart process.',1494380277),(1877,9,'INIT','Starting process.',1494380337),(1878,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380353),(1879,9,'DONE','Process exited normally.',1494380353),(1880,9,'WAIT','Waiting 180 second(s) to restart process.',1494380353),(1881,7,'INIT','Starting process.',1494380457),(1882,8,'INIT','Starting process.',1494380457),(1883,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380458),(1884,7,'DONE','Process exited normally.',1494380458),(1885,7,'WAIT','Waiting 179 second(s) to restart process.',1494380458),(1886,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494380458),(1887,8,'DONE','Process exited normally.',1494380458),(1888,8,'WAIT','Waiting 179 second(s) to restart process.',1494380458),(1889,9,'INIT','Starting process.',1494380533),(1890,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380549),(1891,9,'DONE','Process exited normally.',1494380549),(1892,9,'WAIT','Waiting 180 second(s) to restart process.',1494380549),(1893,7,'INIT','Starting process.',1494380637),(1894,8,'INIT','Starting process.',1494380637),(1895,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380638),(1896,7,'DONE','Process exited normally.',1494380638),(1897,7,'WAIT','Waiting 180 second(s) to restart process.',1494380638),(1898,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380638),(1899,8,'DONE','Process exited normally.',1494380638),(1900,8,'WAIT','Waiting 180 second(s) to restart process.',1494380638),(1901,9,'INIT','Starting process.',1494380729),(1902,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380745),(1903,9,'DONE','Process exited normally.',1494380745),(1904,9,'WAIT','Waiting 180 second(s) to restart process.',1494380745),(1905,7,'INIT','Starting process.',1494380818),(1906,8,'INIT','Starting process.',1494380818),(1907,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380819),(1908,7,'DONE','Process exited normally.',1494380819),(1909,7,'WAIT','Waiting 180 second(s) to restart process.',1494380819),(1910,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380819),(1911,8,'DONE','Process exited normally.',1494380819),(1912,8,'WAIT','Waiting 180 second(s) to restart process.',1494380819),(1913,9,'INIT','Starting process.',1494380925),(1914,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494380941),(1915,9,'DONE','Process exited normally.',1494380941),(1916,9,'WAIT','Waiting 180 second(s) to restart process.',1494380941),(1917,7,'INIT','Starting process.',1494380999),(1918,8,'INIT','Starting process.',1494380999),(1919,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381000),(1920,7,'DONE','Process exited normally.',1494381000),(1921,7,'WAIT','Waiting 180 second(s) to restart process.',1494381000),(1922,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381000),(1923,8,'DONE','Process exited normally.',1494381000),(1924,8,'WAIT','Waiting 180 second(s) to restart process.',1494381000),(1925,9,'INIT','Starting process.',1494381121),(1926,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381137),(1927,9,'DONE','Process exited normally.',1494381137),(1928,9,'WAIT','Waiting 180 second(s) to restart process.',1494381137),(1929,7,'INIT','Starting process.',1494381180),(1930,8,'INIT','Starting process.',1494381180),(1931,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381181),(1932,7,'DONE','Process exited normally.',1494381181),(1933,7,'WAIT','Waiting 180 second(s) to restart process.',1494381181),(1934,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381181),(1935,8,'DONE','Process exited normally.',1494381181),(1936,8,'WAIT','Waiting 180 second(s) to restart process.',1494381181),(1937,9,'INIT','Starting process.',1494381317),(1938,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381333),(1939,9,'DONE','Process exited normally.',1494381333),(1940,9,'WAIT','Waiting 180 second(s) to restart process.',1494381333),(1941,7,'INIT','Starting process.',1494381361),(1942,8,'INIT','Starting process.',1494381362),(1943,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381362),(1944,7,'DONE','Process exited normally.',1494381362),(1945,7,'WAIT','Waiting 180 second(s) to restart process.',1494381362),(1946,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381362),(1947,8,'DONE','Process exited normally.',1494381362),(1948,8,'WAIT','Waiting 180 second(s) to restart process.',1494381362),(1949,9,'INIT','Starting process.',1494381513),(1950,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381529),(1951,9,'DONE','Process exited normally.',1494381529),(1952,9,'WAIT','Waiting 180 second(s) to restart process.',1494381529),(1953,7,'INIT','Starting process.',1494381542),(1954,8,'INIT','Starting process.',1494381542),(1955,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381542),(1956,7,'DONE','Process exited normally.',1494381542),(1957,7,'WAIT','Waiting 180 second(s) to restart process.',1494381542),(1958,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381542),(1959,8,'DONE','Process exited normally.',1494381542),(1960,8,'WAIT','Waiting 180 second(s) to restart process.',1494381542),(1961,9,'INIT','Starting process.',1494381709),(1962,7,'INIT','Starting process.',1494381722),(1963,8,'INIT','Starting process.',1494381722),(1964,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381723),(1965,7,'DONE','Process exited normally.',1494381723),(1966,7,'WAIT','Waiting 180 second(s) to restart process.',1494381723),(1967,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381723),(1968,8,'DONE','Process exited normally.',1494381723),(1969,8,'WAIT','Waiting 180 second(s) to restart process.',1494381723),(1970,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381726),(1971,9,'DONE','Process exited normally.',1494381726),(1972,9,'WAIT','Waiting 180 second(s) to restart process.',1494381726),(1973,7,'INIT','Starting process.',1494381903),(1974,8,'INIT','Starting process.',1494381903),(1975,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381903),(1976,7,'DONE','Process exited normally.',1494381903),(1977,7,'WAIT','Waiting 180 second(s) to restart process.',1494381903),(1978,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381903),(1979,8,'DONE','Process exited normally.',1494381903),(1980,8,'WAIT','Waiting 180 second(s) to restart process.',1494381903),(1981,9,'INIT','Starting process.',1494381906),(1982,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494381923),(1983,9,'DONE','Process exited normally.',1494381923),(1984,9,'WAIT','Waiting 180 second(s) to restart process.',1494381923),(1985,7,'INIT','Starting process.',1494382083),(1986,8,'INIT','Starting process.',1494382083),(1987,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382083),(1988,7,'DONE','Process exited normally.',1494382083),(1989,7,'WAIT','Waiting 180 second(s) to restart process.',1494382083),(1990,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382083),(1991,8,'DONE','Process exited normally.',1494382083),(1992,8,'WAIT','Waiting 180 second(s) to restart process.',1494382083),(1993,9,'INIT','Starting process.',1494382103),(1994,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382120),(1995,9,'DONE','Process exited normally.',1494382120),(1996,9,'WAIT','Waiting 180 second(s) to restart process.',1494382120),(1997,7,'INIT','Starting process.',1494382263),(1998,8,'INIT','Starting process.',1494382263),(1999,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382263),(2000,7,'DONE','Process exited normally.',1494382263),(2001,7,'WAIT','Waiting 180 second(s) to restart process.',1494382263),(2002,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382263),(2003,8,'DONE','Process exited normally.',1494382263),(2004,8,'WAIT','Waiting 180 second(s) to restart process.',1494382263),(2005,9,'INIT','Starting process.',1494382300),(2006,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382316),(2007,9,'DONE','Process exited normally.',1494382316),(2008,9,'WAIT','Waiting 180 second(s) to restart process.',1494382316),(2009,7,'INIT','Starting process.',1494382443),(2010,8,'INIT','Starting process.',1494382443),(2011,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382443),(2012,7,'DONE','Process exited normally.',1494382443),(2013,7,'WAIT','Waiting 180 second(s) to restart process.',1494382443),(2014,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382443),(2015,8,'DONE','Process exited normally.',1494382444),(2016,8,'WAIT','Waiting 179 second(s) to restart process.',1494382444),(2017,9,'INIT','Starting process.',1494382496),(2018,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382512),(2019,9,'DONE','Process exited normally.',1494382512),(2020,9,'WAIT','Waiting 180 second(s) to restart process.',1494382512),(2021,7,'INIT','Starting process.',1494382623),(2022,8,'INIT','Starting process.',1494382623),(2023,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382623),(2024,7,'DONE','Process exited normally.',1494382623),(2025,7,'WAIT','Waiting 180 second(s) to restart process.',1494382623),(2026,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494382624),(2027,8,'DONE','Process exited normally.',1494382624),(2028,8,'WAIT','Waiting 179 second(s) to restart process.',1494382624),(2029,9,'INIT','Starting process.',1494382692),(2030,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382708),(2031,9,'DONE','Process exited normally.',1494382708),(2032,9,'WAIT','Waiting 180 second(s) to restart process.',1494382708),(2033,7,'INIT','Starting process.',1494382803),(2034,8,'INIT','Starting process.',1494382803),(2035,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382804),(2036,7,'DONE','Process exited normally.',1494382804),(2037,7,'WAIT','Waiting 180 second(s) to restart process.',1494382804),(2038,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382804),(2039,8,'DONE','Process exited normally.',1494382804),(2040,8,'WAIT','Waiting 180 second(s) to restart process.',1494382804),(2041,9,'INIT','Starting process.',1494382888),(2042,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382904),(2043,9,'DONE','Process exited normally.',1494382904),(2044,9,'WAIT','Waiting 180 second(s) to restart process.',1494382904),(2045,7,'INIT','Starting process.',1494382984),(2046,8,'INIT','Starting process.',1494382984),(2047,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382985),(2048,7,'DONE','Process exited normally.',1494382985),(2049,7,'WAIT','Waiting 180 second(s) to restart process.',1494382985),(2050,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494382985),(2051,8,'DONE','Process exited normally.',1494382985),(2052,8,'WAIT','Waiting 180 second(s) to restart process.',1494382985),(2053,9,'INIT','Starting process.',1494383084),(2054,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383100),(2055,9,'DONE','Process exited normally.',1494383100),(2056,9,'WAIT','Waiting 180 second(s) to restart process.',1494383100),(2057,7,'INIT','Starting process.',1494383165),(2058,8,'INIT','Starting process.',1494383165),(2059,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383166),(2060,7,'DONE','Process exited normally.',1494383166),(2061,7,'WAIT','Waiting 180 second(s) to restart process.',1494383166),(2062,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383166),(2063,8,'DONE','Process exited normally.',1494383166),(2064,8,'WAIT','Waiting 180 second(s) to restart process.',1494383166),(2065,9,'INIT','Starting process.',1494383280),(2066,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383296),(2067,9,'DONE','Process exited normally.',1494383296),(2068,9,'WAIT','Waiting 180 second(s) to restart process.',1494383296),(2069,7,'INIT','Starting process.',1494383346),(2070,8,'INIT','Starting process.',1494383346),(2071,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383347),(2072,7,'DONE','Process exited normally.',1494383347),(2073,7,'WAIT','Waiting 180 second(s) to restart process.',1494383347),(2074,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383347),(2075,8,'DONE','Process exited normally.',1494383347),(2076,8,'WAIT','Waiting 180 second(s) to restart process.',1494383347),(2077,9,'INIT','Starting process.',1494383476),(2078,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383492),(2079,9,'DONE','Process exited normally.',1494383492),(2080,9,'WAIT','Waiting 180 second(s) to restart process.',1494383492),(2081,7,'INIT','Starting process.',1494383527),(2082,8,'INIT','Starting process.',1494383527),(2083,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383527),(2084,7,'DONE','Process exited normally.',1494383527),(2085,7,'WAIT','Waiting 180 second(s) to restart process.',1494383527),(2086,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383527),(2087,8,'DONE','Process exited normally.',1494383527),(2088,8,'WAIT','Waiting 180 second(s) to restart process.',1494383527),(2089,9,'INIT','Starting process.',1494383672),(2090,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383688),(2091,9,'DONE','Process exited normally.',1494383688),(2092,9,'WAIT','Waiting 180 second(s) to restart process.',1494383688),(2093,7,'INIT','Starting process.',1494383707),(2094,8,'INIT','Starting process.',1494383707),(2095,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383707),(2096,7,'DONE','Process exited normally.',1494383707),(2097,7,'WAIT','Waiting 180 second(s) to restart process.',1494383707),(2098,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383707),(2099,8,'DONE','Process exited normally.',1494383707),(2100,8,'WAIT','Waiting 180 second(s) to restart process.',1494383707),(2101,9,'INIT','Starting process.',1494383868),(2102,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383884),(2103,9,'DONE','Process exited normally.',1494383884),(2104,9,'WAIT','Waiting 180 second(s) to restart process.',1494383884),(2105,7,'INIT','Starting process.',1494383887),(2106,8,'INIT','Starting process.',1494383887),(2107,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383887),(2108,7,'DONE','Process exited normally.',1494383887),(2109,7,'WAIT','Waiting 180 second(s) to restart process.',1494383887),(2110,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494383887),(2111,8,'DONE','Process exited normally.',1494383887),(2112,8,'WAIT','Waiting 180 second(s) to restart process.',1494383887),(2113,9,'INIT','Starting process.',1494384064),(2114,7,'INIT','Starting process.',1494384067),(2115,8,'INIT','Starting process.',1494384067),(2116,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384068),(2117,7,'DONE','Process exited normally.',1494384068),(2118,7,'WAIT','Waiting 180 second(s) to restart process.',1494384068),(2119,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384068),(2120,8,'DONE','Process exited normally.',1494384068),(2121,8,'WAIT','Waiting 180 second(s) to restart process.',1494384068),(2122,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384081),(2123,9,'DONE','Process exited normally.',1494384081),(2124,9,'WAIT','Waiting 180 second(s) to restart process.',1494384081),(2125,7,'INIT','Starting process.',1494384248),(2126,8,'INIT','Starting process.',1494384248),(2127,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384248),(2128,7,'DONE','Process exited normally.',1494384248),(2129,7,'WAIT','Waiting 180 second(s) to restart process.',1494384248),(2130,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384248),(2131,8,'DONE','Process exited normally.',1494384248),(2132,8,'WAIT','Waiting 180 second(s) to restart process.',1494384248),(2133,9,'INIT','Starting process.',1494384261),(2134,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384278),(2135,9,'DONE','Process exited normally.',1494384278),(2136,9,'WAIT','Waiting 180 second(s) to restart process.',1494384278),(2137,7,'INIT','Starting process.',1494384428),(2138,8,'INIT','Starting process.',1494384428),(2139,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384428),(2140,7,'DONE','Process exited normally.',1494384428),(2141,7,'WAIT','Waiting 180 second(s) to restart process.',1494384428),(2142,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384428),(2143,8,'DONE','Process exited normally.',1494384428),(2144,8,'WAIT','Waiting 180 second(s) to restart process.',1494384428),(2145,9,'INIT','Starting process.',1494384458),(2146,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384475),(2147,9,'DONE','Process exited normally.',1494384475),(2148,9,'WAIT','Waiting 180 second(s) to restart process.',1494384475),(2149,7,'INIT','Starting process.',1494384608),(2150,8,'INIT','Starting process.',1494384608),(2151,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384608),(2152,7,'DONE','Process exited normally.',1494384608),(2153,7,'WAIT','Waiting 180 second(s) to restart process.',1494384608),(2154,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384608),(2155,8,'DONE','Process exited normally.',1494384608),(2156,8,'WAIT','Waiting 180 second(s) to restart process.',1494384608),(2157,9,'INIT','Starting process.',1494384655),(2158,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384671),(2159,9,'DONE','Process exited normally.',1494384671),(2160,9,'WAIT','Waiting 180 second(s) to restart process.',1494384671),(2161,7,'INIT','Starting process.',1494384788),(2162,8,'INIT','Starting process.',1494384788),(2163,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384788),(2164,7,'DONE','Process exited normally.',1494384788),(2165,7,'WAIT','Waiting 180 second(s) to restart process.',1494384788),(2166,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384788),(2167,8,'DONE','Process exited normally.',1494384788),(2168,8,'WAIT','Waiting 180 second(s) to restart process.',1494384788),(2169,9,'INIT','Starting process.',1494384851),(2170,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384867),(2171,9,'DONE','Process exited normally.',1494384867),(2172,9,'WAIT','Waiting 180 second(s) to restart process.',1494384867),(2173,7,'INIT','Starting process.',1494384968),(2174,8,'INIT','Starting process.',1494384968),(2175,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494384968),(2176,7,'DONE','Process exited normally.',1494384968),(2177,7,'WAIT','Waiting 180 second(s) to restart process.',1494384968),(2178,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494384969),(2179,8,'DONE','Process exited normally.',1494384969),(2180,8,'WAIT','Waiting 179 second(s) to restart process.',1494384969),(2181,9,'INIT','Starting process.',1494385047),(2182,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385063),(2183,9,'DONE','Process exited normally.',1494385063),(2184,9,'WAIT','Waiting 180 second(s) to restart process.',1494385063),(2185,7,'INIT','Starting process.',1494385148),(2186,8,'INIT','Starting process.',1494385148),(2187,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385148),(2188,7,'DONE','Process exited normally.',1494385149),(2189,7,'WAIT','Waiting 179 second(s) to restart process.',1494385149),(2190,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385149),(2191,8,'DONE','Process exited normally.',1494385149),(2192,8,'WAIT','Waiting 180 second(s) to restart process.',1494385149),(2193,9,'INIT','Starting process.',1494385243),(2194,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385259),(2195,9,'DONE','Process exited normally.',1494385259),(2196,9,'WAIT','Waiting 180 second(s) to restart process.',1494385259),(2197,7,'INIT','Starting process.',1494385328),(2198,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385329),(2199,7,'DONE','Process exited normally.',1494385329),(2200,7,'WAIT','Waiting 180 second(s) to restart process.',1494385329),(2201,8,'INIT','Starting process.',1494385329),(2202,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385329),(2203,8,'DONE','Process exited normally.',1494385329),(2204,8,'WAIT','Waiting 180 second(s) to restart process.',1494385329),(2205,9,'INIT','Starting process.',1494385439),(2206,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385455),(2207,9,'DONE','Process exited normally.',1494385455),(2208,9,'WAIT','Waiting 180 second(s) to restart process.',1494385455),(2209,7,'INIT','Starting process.',1494385509),(2210,8,'INIT','Starting process.',1494385509),(2211,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385509),(2212,7,'DONE','Process exited normally.',1494385509),(2213,7,'WAIT','Waiting 180 second(s) to restart process.',1494385509),(2214,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385509),(2215,8,'DONE','Process exited normally.',1494385509),(2216,8,'WAIT','Waiting 180 second(s) to restart process.',1494385509),(2217,9,'INIT','Starting process.',1494385635),(2218,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385652),(2219,9,'DONE','Process exited normally.',1494385652),(2220,9,'WAIT','Waiting 180 second(s) to restart process.',1494385652),(2221,7,'INIT','Starting process.',1494385689),(2222,8,'INIT','Starting process.',1494385689),(2223,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385689),(2224,7,'DONE','Process exited normally.',1494385689),(2225,7,'WAIT','Waiting 180 second(s) to restart process.',1494385689),(2226,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385689),(2227,8,'DONE','Process exited normally.',1494385689),(2228,8,'WAIT','Waiting 180 second(s) to restart process.',1494385689),(2229,9,'INIT','Starting process.',1494385832),(2230,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385849),(2231,9,'DONE','Process exited normally.',1494385849),(2232,9,'WAIT','Waiting 180 second(s) to restart process.',1494385849),(2233,7,'INIT','Starting process.',1494385869),(2234,8,'INIT','Starting process.',1494385869),(2235,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385869),(2236,7,'DONE','Process exited normally.',1494385869),(2237,7,'WAIT','Waiting 180 second(s) to restart process.',1494385869),(2238,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494385869),(2239,8,'DONE','Process exited normally.',1494385869),(2240,8,'WAIT','Waiting 180 second(s) to restart process.',1494385869),(2241,9,'INIT','Starting process.',1494386029),(2242,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386046),(2243,9,'DONE','Process exited normally.',1494386046),(2244,9,'WAIT','Waiting 180 second(s) to restart process.',1494386046),(2245,7,'INIT','Starting process.',1494386049),(2246,8,'INIT','Starting process.',1494386049),(2247,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386049),(2248,7,'DONE','Process exited normally.',1494386049),(2249,7,'WAIT','Waiting 180 second(s) to restart process.',1494386049),(2250,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386049),(2251,8,'DONE','Process exited normally.',1494386049),(2252,8,'WAIT','Waiting 180 second(s) to restart process.',1494386049),(2253,9,'INIT','Starting process.',1494386226),(2254,7,'INIT','Starting process.',1494386229),(2255,8,'INIT','Starting process.',1494386229),(2256,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386229),(2257,7,'DONE','Process exited normally.',1494386229),(2258,7,'WAIT','Waiting 180 second(s) to restart process.',1494386229),(2259,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386229),(2260,8,'DONE','Process exited normally.',1494386229),(2261,8,'WAIT','Waiting 180 second(s) to restart process.',1494386229),(2262,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386242),(2263,9,'DONE','Process exited normally.',1494386242),(2264,9,'WAIT','Waiting 180 second(s) to restart process.',1494386242),(2265,7,'INIT','Starting process.',1494386409),(2266,8,'INIT','Starting process.',1494386409),(2267,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386410),(2268,7,'DONE','Process exited normally.',1494386410),(2269,7,'WAIT','Waiting 180 second(s) to restart process.',1494386410),(2270,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386410),(2271,8,'DONE','Process exited normally.',1494386410),(2272,8,'WAIT','Waiting 180 second(s) to restart process.',1494386410),(2273,9,'INIT','Starting process.',1494386422),(2274,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386438),(2275,9,'DONE','Process exited normally.',1494386438),(2276,9,'WAIT','Waiting 180 second(s) to restart process.',1494386438),(2277,7,'INIT','Starting process.',1494386590),(2278,8,'INIT','Starting process.',1494386590),(2279,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386591),(2280,7,'DONE','Process exited normally.',1494386591),(2281,7,'WAIT','Waiting 180 second(s) to restart process.',1494386591),(2282,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386591),(2283,8,'DONE','Process exited normally.',1494386591),(2284,8,'WAIT','Waiting 180 second(s) to restart process.',1494386591),(2285,9,'INIT','Starting process.',1494386618),(2286,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386634),(2287,9,'DONE','Process exited normally.',1494386634),(2288,9,'WAIT','Waiting 180 second(s) to restart process.',1494386634),(2289,7,'INIT','Starting process.',1494386771),(2290,8,'INIT','Starting process.',1494386771),(2291,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386772),(2292,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386772),(2293,8,'DONE','Process exited normally.',1494386772),(2294,8,'WAIT','Waiting 180 second(s) to restart process.',1494386772),(2295,7,'DONE','Process exited normally.',1494386772),(2296,7,'WAIT','Waiting 180 second(s) to restart process.',1494386772),(2297,9,'INIT','Starting process.',1494386814),(2298,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386830),(2299,9,'DONE','Process exited normally.',1494386830),(2300,9,'WAIT','Waiting 180 second(s) to restart process.',1494386830),(2301,7,'INIT','Starting process.',1494386952),(2302,8,'INIT','Starting process.',1494386952),(2303,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386953),(2304,7,'DONE','Process exited normally.',1494386953),(2305,7,'WAIT','Waiting 180 second(s) to restart process.',1494386953),(2306,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494386953),(2307,8,'DONE','Process exited normally.',1494386953),(2308,8,'WAIT','Waiting 180 second(s) to restart process.',1494386953),(2309,9,'INIT','Starting process.',1494387010),(2310,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387026),(2311,9,'DONE','Process exited normally.',1494387026),(2312,9,'WAIT','Waiting 180 second(s) to restart process.',1494387026),(2313,7,'INIT','Starting process.',1494387133),(2314,8,'INIT','Starting process.',1494387133),(2315,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387134),(2316,7,'DONE','Process exited normally.',1494387134),(2317,7,'WAIT','Waiting 180 second(s) to restart process.',1494387134),(2318,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387134),(2319,8,'DONE','Process exited normally.',1494387134),(2320,8,'WAIT','Waiting 180 second(s) to restart process.',1494387134),(2321,9,'INIT','Starting process.',1494387206),(2322,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387222),(2323,9,'DONE','Process exited normally.',1494387222),(2324,9,'WAIT','Waiting 180 second(s) to restart process.',1494387222),(2325,7,'INIT','Starting process.',1494387314),(2326,8,'INIT','Starting process.',1494387314),(2327,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387315),(2328,7,'DONE','Process exited normally.',1494387315),(2329,7,'WAIT','Waiting 180 second(s) to restart process.',1494387315),(2330,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387315),(2331,8,'DONE','Process exited normally.',1494387315),(2332,8,'WAIT','Waiting 180 second(s) to restart process.',1494387315),(2333,9,'INIT','Starting process.',1494387402),(2334,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387418),(2335,9,'DONE','Process exited normally.',1494387418),(2336,9,'WAIT','Waiting 180 second(s) to restart process.',1494387418),(2337,7,'INIT','Starting process.',1494387495),(2338,8,'INIT','Starting process.',1494387495),(2339,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387495),(2340,7,'DONE','Process exited normally.',1494387495),(2341,7,'WAIT','Waiting 180 second(s) to restart process.',1494387495),(2342,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387495),(2343,8,'DONE','Process exited normally.',1494387495),(2344,8,'WAIT','Waiting 180 second(s) to restart process.',1494387495),(2345,9,'INIT','Starting process.',1494387598),(2346,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387614),(2347,9,'DONE','Process exited normally.',1494387614),(2348,9,'WAIT','Waiting 180 second(s) to restart process.',1494387614),(2349,7,'INIT','Starting process.',1494387675),(2350,8,'INIT','Starting process.',1494387675),(2351,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387675),(2352,7,'DONE','Process exited normally.',1494387675),(2353,7,'WAIT','Waiting 180 second(s) to restart process.',1494387675),(2354,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387675),(2355,8,'DONE','Process exited normally.',1494387675),(2356,8,'WAIT','Waiting 180 second(s) to restart process.',1494387675),(2357,9,'INIT','Starting process.',1494387794),(2358,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387810),(2359,9,'DONE','Process exited normally.',1494387811),(2360,9,'WAIT','Waiting 179 second(s) to restart process.',1494387811),(2361,7,'INIT','Starting process.',1494387855),(2362,8,'INIT','Starting process.',1494387855),(2363,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387855),(2364,7,'DONE','Process exited normally.',1494387855),(2365,7,'WAIT','Waiting 180 second(s) to restart process.',1494387855),(2366,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494387855),(2367,8,'DONE','Process exited normally.',1494387855),(2368,8,'WAIT','Waiting 180 second(s) to restart process.',1494387855),(2369,9,'INIT','Starting process.',1494387990),(2370,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388007),(2371,9,'DONE','Process exited normally.',1494388007),(2372,9,'WAIT','Waiting 180 second(s) to restart process.',1494388007),(2373,7,'INIT','Starting process.',1494388035),(2374,8,'INIT','Starting process.',1494388035),(2375,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388035),(2376,7,'DONE','Process exited normally.',1494388035),(2377,7,'WAIT','Waiting 180 second(s) to restart process.',1494388035),(2378,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388035),(2379,8,'DONE','Process exited normally.',1494388035),(2380,8,'WAIT','Waiting 180 second(s) to restart process.',1494388035),(2381,9,'INIT','Starting process.',1494388187),(2382,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388204),(2383,9,'DONE','Process exited normally.',1494388204),(2384,9,'WAIT','Waiting 180 second(s) to restart process.',1494388204),(2385,7,'INIT','Starting process.',1494388215),(2386,8,'INIT','Starting process.',1494388215),(2387,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388215),(2388,7,'DONE','Process exited normally.',1494388215),(2389,7,'WAIT','Waiting 180 second(s) to restart process.',1494388215),(2390,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388215),(2391,8,'DONE','Process exited normally.',1494388215),(2392,8,'WAIT','Waiting 180 second(s) to restart process.',1494388215),(2393,9,'INIT','Starting process.',1494388384),(2394,7,'INIT','Starting process.',1494388395),(2395,8,'INIT','Starting process.',1494388395),(2396,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388395),(2397,7,'DONE','Process exited normally.',1494388395),(2398,7,'WAIT','Waiting 180 second(s) to restart process.',1494388395),(2399,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388395),(2400,8,'DONE','Process exited normally.',1494388395),(2401,8,'WAIT','Waiting 180 second(s) to restart process.',1494388395),(2402,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388401),(2403,9,'DONE','Process exited normally.',1494388401),(2404,9,'WAIT','Waiting 180 second(s) to restart process.',1494388401),(2405,7,'INIT','Starting process.',1494388575),(2406,8,'INIT','Starting process.',1494388575),(2407,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388575),(2408,7,'DONE','Process exited normally.',1494388575),(2409,7,'WAIT','Waiting 180 second(s) to restart process.',1494388575),(2410,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494388576),(2411,8,'DONE','Process exited normally.',1494388576),(2412,8,'WAIT','Waiting 179 second(s) to restart process.',1494388576),(2413,9,'INIT','Starting process.',1494388581),(2414,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388597),(2415,9,'DONE','Process exited normally.',1494388597),(2416,9,'WAIT','Waiting 180 second(s) to restart process.',1494388597),(2417,7,'INIT','Starting process.',1494388755),(2418,8,'INIT','Starting process.',1494388755),(2419,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388756),(2420,7,'DONE','Process exited normally.',1494388756),(2421,7,'WAIT','Waiting 180 second(s) to restart process.',1494388756),(2422,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388756),(2423,8,'DONE','Process exited normally.',1494388756),(2424,8,'WAIT','Waiting 180 second(s) to restart process.',1494388756),(2425,9,'INIT','Starting process.',1494388777),(2426,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388793),(2427,9,'DONE','Process exited normally.',1494388793),(2428,9,'WAIT','Waiting 180 second(s) to restart process.',1494388793),(2429,7,'INIT','Starting process.',1494388936),(2430,8,'INIT','Starting process.',1494388936),(2431,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388937),(2432,7,'DONE','Process exited normally.',1494388937),(2433,7,'WAIT','Waiting 180 second(s) to restart process.',1494388937),(2434,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388937),(2435,8,'DONE','Process exited normally.',1494388937),(2436,8,'WAIT','Waiting 180 second(s) to restart process.',1494388937),(2437,9,'INIT','Starting process.',1494388973),(2438,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494388989),(2439,9,'DONE','Process exited normally.',1494388989),(2440,9,'WAIT','Waiting 180 second(s) to restart process.',1494388989),(2441,7,'INIT','Starting process.',1494389117),(2442,8,'INIT','Starting process.',1494389117),(2443,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389118),(2444,7,'DONE','Process exited normally.',1494389118),(2445,7,'WAIT','Waiting 180 second(s) to restart process.',1494389118),(2446,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389118),(2447,8,'DONE','Process exited normally.',1494389118),(2448,8,'WAIT','Waiting 180 second(s) to restart process.',1494389118),(2449,9,'INIT','Starting process.',1494389169),(2450,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389185),(2451,9,'DONE','Process exited normally.',1494389185),(2452,9,'WAIT','Waiting 180 second(s) to restart process.',1494389185),(2453,7,'INIT','Starting process.',1494389298),(2454,8,'INIT','Starting process.',1494389298),(2455,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389299),(2456,7,'DONE','Process exited normally.',1494389299),(2457,7,'WAIT','Waiting 180 second(s) to restart process.',1494389299),(2458,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389299),(2459,8,'DONE','Process exited normally.',1494389299),(2460,8,'WAIT','Waiting 180 second(s) to restart process.',1494389299),(2461,9,'INIT','Starting process.',1494389365),(2462,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494389381),(2463,9,'DONE','Process exited normally.',1494389381),(2464,9,'WAIT','Waiting 180 second(s) to restart process.',1494389381),(2465,7,'INIT','Starting process.',1494420406),(2466,8,'INIT','Starting process.',1494420406),(2467,9,'INIT','Starting process.',1494420406),(2468,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420406),(2469,7,'DONE','Process exited normally.',1494420406),(2470,7,'WAIT','Waiting 180 second(s) to restart process.',1494420406),(2471,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420407),(2472,8,'DONE','Process exited normally.',1494420407),(2473,8,'WAIT','Waiting 180 second(s) to restart process.',1494420407),(2474,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420422),(2475,9,'DONE','Process exited normally.',1494420422),(2476,9,'WAIT','Waiting 180 second(s) to restart process.',1494420422),(2477,7,'INIT','Starting process.',1494420586),(2478,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420586),(2479,7,'DONE','Process exited normally.',1494420586),(2480,7,'WAIT','Waiting 180 second(s) to restart process.',1494420586),(2481,8,'INIT','Starting process.',1494420587),(2482,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494420588),(2483,8,'DONE','Process exited normally.',1494420588),(2484,8,'WAIT','Waiting 179 second(s) to restart process.',1494420588),(2485,9,'INIT','Starting process.',1494420602),(2486,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420618),(2487,9,'DONE','Process exited normally.',1494420618),(2488,9,'WAIT','Waiting 180 second(s) to restart process.',1494420618),(2489,7,'INIT','Starting process.',1494420766),(2490,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420767),(2491,7,'DONE','Process exited normally.',1494420767),(2492,7,'WAIT','Waiting 180 second(s) to restart process.',1494420767),(2493,8,'INIT','Starting process.',1494420767),(2494,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420767),(2495,8,'DONE','Process exited normally.',1494420767),(2496,8,'WAIT','Waiting 180 second(s) to restart process.',1494420767),(2497,9,'INIT','Starting process.',1494420798),(2498,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420814),(2499,9,'DONE','Process exited normally.',1494420814),(2500,9,'WAIT','Waiting 180 second(s) to restart process.',1494420814),(2501,7,'INIT','Starting process.',1494420947),(2502,8,'INIT','Starting process.',1494420947),(2503,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420947),(2504,7,'DONE','Process exited normally.',1494420947),(2505,7,'WAIT','Waiting 180 second(s) to restart process.',1494420947),(2506,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494420947),(2507,8,'DONE','Process exited normally.',1494420947),(2508,8,'WAIT','Waiting 180 second(s) to restart process.',1494420947),(2509,9,'INIT','Starting process.',1494420994),(2510,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421010),(2511,9,'DONE','Process exited normally.',1494421010),(2512,9,'WAIT','Waiting 180 second(s) to restart process.',1494421010),(2513,7,'INIT','Starting process.',1494421127),(2514,8,'INIT','Starting process.',1494421127),(2515,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421127),(2516,7,'DONE','Process exited normally.',1494421127),(2517,7,'WAIT','Waiting 180 second(s) to restart process.',1494421127),(2518,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421127),(2519,8,'DONE','Process exited normally.',1494421127),(2520,8,'WAIT','Waiting 180 second(s) to restart process.',1494421127),(2521,9,'INIT','Starting process.',1494421190),(2522,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421207),(2523,9,'DONE','Process exited normally.',1494421207),(2524,9,'WAIT','Waiting 180 second(s) to restart process.',1494421207),(2525,7,'INIT','Starting process.',1494421307),(2526,8,'INIT','Starting process.',1494421307),(2527,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421307),(2528,7,'DONE','Process exited normally.',1494421307),(2529,7,'WAIT','Waiting 180 second(s) to restart process.',1494421307),(2530,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421307),(2531,8,'DONE','Process exited normally.',1494421307),(2532,8,'WAIT','Waiting 180 second(s) to restart process.',1494421307),(2533,9,'INIT','Starting process.',1494421387),(2534,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421404),(2535,9,'DONE','Process exited normally.',1494421404),(2536,9,'WAIT','Waiting 180 second(s) to restart process.',1494421404),(2537,7,'INIT','Starting process.',1494421487),(2538,8,'INIT','Starting process.',1494421487),(2539,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421487),(2540,7,'DONE','Process exited normally.',1494421487),(2541,7,'WAIT','Waiting 180 second(s) to restart process.',1494421487),(2542,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421487),(2543,8,'DONE','Process exited normally.',1494421487),(2544,8,'WAIT','Waiting 180 second(s) to restart process.',1494421487),(2545,9,'INIT','Starting process.',1494421584),(2546,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421601),(2547,9,'DONE','Process exited normally.',1494421601),(2548,9,'WAIT','Waiting 180 second(s) to restart process.',1494421601),(2549,7,'INIT','Starting process.',1494421667),(2550,8,'INIT','Starting process.',1494421667),(2551,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421667),(2552,7,'DONE','Process exited normally.',1494421667),(2553,7,'WAIT','Waiting 180 second(s) to restart process.',1494421667),(2554,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421667),(2555,8,'DONE','Process exited normally.',1494421667),(2556,8,'WAIT','Waiting 180 second(s) to restart process.',1494421667),(2557,9,'INIT','Starting process.',1494421781),(2558,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421797),(2559,9,'DONE','Process exited normally.',1494421797),(2560,9,'WAIT','Waiting 180 second(s) to restart process.',1494421797),(2561,7,'INIT','Starting process.',1494421847),(2562,8,'INIT','Starting process.',1494421847),(2563,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421847),(2564,7,'DONE','Process exited normally.',1494421847),(2565,7,'WAIT','Waiting 180 second(s) to restart process.',1494421847),(2566,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421847),(2567,8,'DONE','Process exited normally.',1494421847),(2568,8,'WAIT','Waiting 180 second(s) to restart process.',1494421847),(2569,9,'INIT','Starting process.',1494421977),(2570,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494421993),(2571,9,'DONE','Process exited normally.',1494421993),(2572,9,'WAIT','Waiting 180 second(s) to restart process.',1494421993),(2573,7,'INIT','Starting process.',1494422027),(2574,8,'INIT','Starting process.',1494422027),(2575,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422027),(2576,7,'DONE','Process exited normally.',1494422027),(2577,7,'WAIT','Waiting 180 second(s) to restart process.',1494422027),(2578,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422027),(2579,8,'DONE','Process exited normally.',1494422027),(2580,8,'WAIT','Waiting 180 second(s) to restart process.',1494422027),(2581,9,'INIT','Starting process.',1494422173),(2582,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422189),(2583,9,'DONE','Process exited normally.',1494422189),(2584,9,'WAIT','Waiting 180 second(s) to restart process.',1494422189),(2585,7,'INIT','Starting process.',1494422207),(2586,8,'INIT','Starting process.',1494422207),(2587,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422207),(2588,7,'DONE','Process exited normally.',1494422207),(2589,7,'WAIT','Waiting 180 second(s) to restart process.',1494422207),(2590,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422207),(2591,8,'DONE','Process exited normally.',1494422207),(2592,8,'WAIT','Waiting 180 second(s) to restart process.',1494422207),(2593,9,'INIT','Starting process.',1494422369),(2594,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422385),(2595,9,'DONE','Process exited normally.',1494422385),(2596,9,'WAIT','Waiting 180 second(s) to restart process.',1494422385),(2597,7,'INIT','Starting process.',1494422387),(2598,8,'INIT','Starting process.',1494422387),(2599,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422387),(2600,7,'DONE','Process exited normally.',1494422387),(2601,7,'WAIT','Waiting 180 second(s) to restart process.',1494422387),(2602,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494422388),(2603,8,'DONE','Process exited normally.',1494422388),(2604,8,'WAIT','Waiting 179 second(s) to restart process.',1494422388),(2605,9,'INIT','Starting process.',1494422565),(2606,7,'INIT','Starting process.',1494422567),(2607,8,'INIT','Starting process.',1494422567),(2608,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422567),(2609,7,'DONE','Process exited normally.',1494422567),(2610,7,'WAIT','Waiting 180 second(s) to restart process.',1494422567),(2611,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422567),(2612,8,'DONE','Process exited normally.',1494422567),(2613,8,'WAIT','Waiting 180 second(s) to restart process.',1494422567),(2614,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422581),(2615,9,'DONE','Process exited normally.',1494422581),(2616,9,'WAIT','Waiting 180 second(s) to restart process.',1494422581),(2617,7,'INIT','Starting process.',1494422747),(2618,8,'INIT','Starting process.',1494422747),(2619,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422747),(2620,7,'DONE','Process exited normally.',1494422747),(2621,7,'WAIT','Waiting 180 second(s) to restart process.',1494422747),(2622,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422747),(2623,8,'DONE','Process exited normally.',1494422747),(2624,8,'WAIT','Waiting 180 second(s) to restart process.',1494422747),(2625,9,'INIT','Starting process.',1494422761),(2626,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422777),(2627,9,'DONE','Process exited normally.',1494422777),(2628,9,'WAIT','Waiting 180 second(s) to restart process.',1494422777),(2629,7,'INIT','Starting process.',1494422927),(2630,8,'INIT','Starting process.',1494422927),(2631,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422927),(2632,7,'DONE','Process exited normally.',1494422927),(2633,7,'WAIT','Waiting 180 second(s) to restart process.',1494422927),(2634,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422927),(2635,8,'DONE','Process exited normally.',1494422927),(2636,8,'WAIT','Waiting 180 second(s) to restart process.',1494422927),(2637,9,'INIT','Starting process.',1494422957),(2638,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494422973),(2639,9,'DONE','Process exited normally.',1494422973),(2640,9,'WAIT','Waiting 180 second(s) to restart process.',1494422973),(2641,7,'INIT','Starting process.',1494423107),(2642,8,'INIT','Starting process.',1494423107),(2643,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423107),(2644,7,'DONE','Process exited normally.',1494423107),(2645,7,'WAIT','Waiting 180 second(s) to restart process.',1494423107),(2646,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423107),(2647,8,'DONE','Process exited normally.',1494423107),(2648,8,'WAIT','Waiting 180 second(s) to restart process.',1494423107),(2649,9,'INIT','Starting process.',1494423153),(2650,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423170),(2651,9,'DONE','Process exited normally.',1494423170),(2652,9,'WAIT','Waiting 180 second(s) to restart process.',1494423170),(2653,7,'INIT','Starting process.',1494423287),(2654,8,'INIT','Starting process.',1494423287),(2655,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423287),(2656,7,'DONE','Process exited normally.',1494423287),(2657,7,'WAIT','Waiting 180 second(s) to restart process.',1494423287),(2658,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423287),(2659,8,'DONE','Process exited normally.',1494423287),(2660,8,'WAIT','Waiting 180 second(s) to restart process.',1494423287),(2661,9,'INIT','Starting process.',1494423350),(2662,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423367),(2663,9,'DONE','Process exited normally.',1494423367),(2664,9,'WAIT','Waiting 180 second(s) to restart process.',1494423367),(2665,7,'INIT','Starting process.',1494423467),(2666,8,'INIT','Starting process.',1494423467),(2667,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423467),(2668,7,'DONE','Process exited normally.',1494423467),(2669,7,'WAIT','Waiting 180 second(s) to restart process.',1494423467),(2670,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423467),(2671,8,'DONE','Process exited normally.',1494423467),(2672,8,'WAIT','Waiting 180 second(s) to restart process.',1494423467),(2673,9,'INIT','Starting process.',1494423547),(2674,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423564),(2675,9,'DONE','Process exited normally.',1494423564),(2676,9,'WAIT','Waiting 180 second(s) to restart process.',1494423564),(2677,7,'INIT','Starting process.',1494423647),(2678,8,'INIT','Starting process.',1494423647),(2679,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423647),(2680,7,'DONE','Process exited normally.',1494423647),(2681,7,'WAIT','Waiting 180 second(s) to restart process.',1494423647),(2682,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423647),(2683,8,'DONE','Process exited normally.',1494423647),(2684,8,'WAIT','Waiting 180 second(s) to restart process.',1494423647),(2685,9,'INIT','Starting process.',1494423744),(2686,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423761),(2687,9,'DONE','Process exited normally.',1494423761),(2688,9,'WAIT','Waiting 180 second(s) to restart process.',1494423761),(2689,7,'INIT','Starting process.',1494423827),(2690,8,'INIT','Starting process.',1494423827),(2691,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423827),(2692,7,'DONE','Process exited normally.',1494423827),(2693,7,'WAIT','Waiting 180 second(s) to restart process.',1494423827),(2694,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423827),(2695,8,'DONE','Process exited normally.',1494423827),(2696,8,'WAIT','Waiting 180 second(s) to restart process.',1494423827),(2697,9,'INIT','Starting process.',1494423941),(2698,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494423957),(2699,9,'DONE','Process exited normally.',1494423957),(2700,9,'WAIT','Waiting 180 second(s) to restart process.',1494423957),(2701,7,'INIT','Starting process.',1494424007),(2702,8,'INIT','Starting process.',1494424007),(2703,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424007),(2704,7,'DONE','Process exited normally.',1494424007),(2705,7,'WAIT','Waiting 180 second(s) to restart process.',1494424007),(2706,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424007),(2707,8,'DONE','Process exited normally.',1494424007),(2708,8,'WAIT','Waiting 180 second(s) to restart process.',1494424007),(2709,9,'INIT','Starting process.',1494424137),(2710,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424153),(2711,9,'DONE','Process exited normally.',1494424153),(2712,9,'WAIT','Waiting 180 second(s) to restart process.',1494424153),(2713,7,'INIT','Starting process.',1494424187),(2714,8,'INIT','Starting process.',1494424187),(2715,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424187),(2716,7,'DONE','Process exited normally.',1494424187),(2717,7,'WAIT','Waiting 180 second(s) to restart process.',1494424187),(2718,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424187),(2719,8,'DONE','Process exited normally.',1494424187),(2720,8,'WAIT','Waiting 180 second(s) to restart process.',1494424187),(2721,9,'INIT','Starting process.',1494424333),(2722,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424349),(2723,9,'DONE','Process exited normally.',1494424349),(2724,9,'WAIT','Waiting 180 second(s) to restart process.',1494424349),(2725,7,'INIT','Starting process.',1494424367),(2726,8,'INIT','Starting process.',1494424367),(2727,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424367),(2728,7,'DONE','Process exited normally.',1494424367),(2729,7,'WAIT','Waiting 180 second(s) to restart process.',1494424367),(2730,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424367),(2731,8,'DONE','Process exited normally.',1494424367),(2732,8,'WAIT','Waiting 180 second(s) to restart process.',1494424367),(2733,9,'INIT','Starting process.',1494424529),(2734,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424545),(2735,9,'DONE','Process exited normally.',1494424545),(2736,9,'WAIT','Waiting 180 second(s) to restart process.',1494424545),(2737,7,'INIT','Starting process.',1494424547),(2738,8,'INIT','Starting process.',1494424547),(2739,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424547),(2740,7,'DONE','Process exited normally.',1494424547),(2741,7,'WAIT','Waiting 180 second(s) to restart process.',1494424547),(2742,8,'ZZZZ','Process is preparing to hibernate for 179 second(s).',1494424548),(2743,8,'DONE','Process exited normally.',1494424548),(2744,8,'WAIT','Waiting 179 second(s) to restart process.',1494424548),(2745,9,'INIT','Starting process.',1494424725),(2746,7,'INIT','Starting process.',1494424727),(2747,8,'INIT','Starting process.',1494424727),(2748,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424727),(2749,7,'DONE','Process exited normally.',1494424727),(2750,7,'WAIT','Waiting 180 second(s) to restart process.',1494424727),(2751,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424727),(2752,8,'DONE','Process exited normally.',1494424727),(2753,8,'WAIT','Waiting 180 second(s) to restart process.',1494424727),(2754,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424741),(2755,9,'DONE','Process exited normally.',1494424741),(2756,9,'WAIT','Waiting 180 second(s) to restart process.',1494424741),(2757,7,'INIT','Starting process.',1494424907),(2758,8,'INIT','Starting process.',1494424907),(2759,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424907),(2760,7,'DONE','Process exited normally.',1494424907),(2761,7,'WAIT','Waiting 180 second(s) to restart process.',1494424907),(2762,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424907),(2763,8,'DONE','Process exited normally.',1494424907),(2764,8,'WAIT','Waiting 180 second(s) to restart process.',1494424907),(2765,9,'INIT','Starting process.',1494424921),(2766,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494424937),(2767,9,'DONE','Process exited normally.',1494424937),(2768,9,'WAIT','Waiting 180 second(s) to restart process.',1494424937),(2769,7,'INIT','Starting process.',1494425087),(2770,8,'INIT','Starting process.',1494425087),(2771,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425087),(2772,7,'DONE','Process exited normally.',1494425087),(2773,7,'WAIT','Waiting 180 second(s) to restart process.',1494425087),(2774,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425087),(2775,8,'DONE','Process exited normally.',1494425087),(2776,8,'WAIT','Waiting 180 second(s) to restart process.',1494425087),(2777,9,'INIT','Starting process.',1494425117),(2778,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425133),(2779,9,'DONE','Process exited normally.',1494425133),(2780,9,'WAIT','Waiting 180 second(s) to restart process.',1494425133),(2781,7,'INIT','Starting process.',1494425267),(2782,8,'INIT','Starting process.',1494425267),(2783,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425267),(2784,7,'DONE','Process exited normally.',1494425267),(2785,7,'WAIT','Waiting 180 second(s) to restart process.',1494425267),(2786,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425267),(2787,8,'DONE','Process exited normally.',1494425267),(2788,8,'WAIT','Waiting 180 second(s) to restart process.',1494425267),(2789,9,'INIT','Starting process.',1494425313),(2790,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425329),(2791,9,'DONE','Process exited normally.',1494425329),(2792,9,'WAIT','Waiting 180 second(s) to restart process.',1494425329),(2793,7,'INIT','Starting process.',1494425447),(2794,8,'INIT','Starting process.',1494425447),(2795,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425447),(2796,7,'DONE','Process exited normally.',1494425447),(2797,7,'WAIT','Waiting 180 second(s) to restart process.',1494425447),(2798,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425447),(2799,8,'DONE','Process exited normally.',1494425447),(2800,8,'WAIT','Waiting 180 second(s) to restart process.',1494425447),(2801,9,'INIT','Starting process.',1494425509),(2802,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425525),(2803,9,'DONE','Process exited normally.',1494425525),(2804,9,'WAIT','Waiting 180 second(s) to restart process.',1494425525),(2805,7,'INIT','Starting process.',1494425627),(2806,8,'INIT','Starting process.',1494425627),(2807,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425627),(2808,7,'DONE','Process exited normally.',1494425627),(2809,7,'WAIT','Waiting 180 second(s) to restart process.',1494425627),(2810,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425627),(2811,8,'DONE','Process exited normally.',1494425627),(2812,8,'WAIT','Waiting 180 second(s) to restart process.',1494425627),(2813,9,'INIT','Starting process.',1494425705),(2814,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425722),(2815,9,'DONE','Process exited normally.',1494425722),(2816,9,'WAIT','Waiting 180 second(s) to restart process.',1494425722),(2817,7,'INIT','Starting process.',1494425807),(2818,8,'INIT','Starting process.',1494425807),(2819,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425807),(2820,7,'DONE','Process exited normally.',1494425807),(2821,7,'WAIT','Waiting 180 second(s) to restart process.',1494425807),(2822,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425807),(2823,8,'DONE','Process exited normally.',1494425807),(2824,8,'WAIT','Waiting 180 second(s) to restart process.',1494425807),(2825,9,'INIT','Starting process.',1494425902),(2826,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425919),(2827,9,'DONE','Process exited normally.',1494425919),(2828,9,'WAIT','Waiting 180 second(s) to restart process.',1494425919),(2829,7,'INIT','Starting process.',1494425987),(2830,8,'INIT','Starting process.',1494425987),(2831,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425987),(2832,7,'DONE','Process exited normally.',1494425987),(2833,7,'WAIT','Waiting 180 second(s) to restart process.',1494425987),(2834,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494425987),(2835,8,'DONE','Process exited normally.',1494425987),(2836,8,'WAIT','Waiting 180 second(s) to restart process.',1494425987),(2837,9,'INIT','Starting process.',1494426099),(2838,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426116),(2839,9,'DONE','Process exited normally.',1494426116),(2840,9,'WAIT','Waiting 180 second(s) to restart process.',1494426116),(2841,7,'INIT','Starting process.',1494426167),(2842,8,'INIT','Starting process.',1494426167),(2843,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426167),(2844,7,'DONE','Process exited normally.',1494426167),(2845,7,'WAIT','Waiting 180 second(s) to restart process.',1494426167),(2846,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426167),(2847,8,'DONE','Process exited normally.',1494426167),(2848,8,'WAIT','Waiting 180 second(s) to restart process.',1494426167),(2849,9,'INIT','Starting process.',1494426296),(2850,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426312),(2851,9,'DONE','Process exited normally.',1494426312),(2852,9,'WAIT','Waiting 180 second(s) to restart process.',1494426312),(2853,7,'INIT','Starting process.',1494426347),(2854,8,'INIT','Starting process.',1494426347),(2855,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426347),(2856,7,'DONE','Process exited normally.',1494426347),(2857,7,'WAIT','Waiting 180 second(s) to restart process.',1494426347),(2858,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426347),(2859,8,'DONE','Process exited normally.',1494426347),(2860,8,'WAIT','Waiting 180 second(s) to restart process.',1494426347),(2861,9,'INIT','Starting process.',1494426492),(2862,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426508),(2863,9,'DONE','Process exited normally.',1494426508),(2864,9,'WAIT','Waiting 180 second(s) to restart process.',1494426508),(2865,7,'INIT','Starting process.',1494426527),(2866,8,'INIT','Starting process.',1494426527),(2867,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426527),(2868,7,'DONE','Process exited normally.',1494426527),(2869,7,'WAIT','Waiting 180 second(s) to restart process.',1494426527),(2870,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426527),(2871,8,'DONE','Process exited normally.',1494426527),(2872,8,'WAIT','Waiting 180 second(s) to restart process.',1494426527),(2873,9,'INIT','Starting process.',1494426688),(2874,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426704),(2875,9,'DONE','Process exited normally.',1494426704),(2876,9,'WAIT','Waiting 180 second(s) to restart process.',1494426704),(2877,7,'INIT','Starting process.',1494426707),(2878,8,'INIT','Starting process.',1494426707),(2879,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426707),(2880,7,'DONE','Process exited normally.',1494426707),(2881,7,'WAIT','Waiting 180 second(s) to restart process.',1494426707),(2882,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426707),(2883,8,'DONE','Process exited normally.',1494426707),(2884,8,'WAIT','Waiting 180 second(s) to restart process.',1494426707),(2885,9,'INIT','Starting process.',1494426884),(2886,7,'INIT','Starting process.',1494426887),(2887,8,'INIT','Starting process.',1494426887),(2888,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426887),(2889,7,'DONE','Process exited normally.',1494426887),(2890,7,'WAIT','Waiting 180 second(s) to restart process.',1494426887),(2891,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426887),(2892,8,'DONE','Process exited normally.',1494426887),(2893,8,'WAIT','Waiting 180 second(s) to restart process.',1494426887),(2894,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494426900),(2895,9,'DONE','Process exited normally.',1494426900),(2896,9,'WAIT','Waiting 180 second(s) to restart process.',1494426900),(2897,7,'INIT','Starting process.',1494427067),(2898,8,'INIT','Starting process.',1494427067),(2899,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427068),(2900,7,'DONE','Process exited normally.',1494427068),(2901,7,'WAIT','Waiting 180 second(s) to restart process.',1494427068),(2902,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427068),(2903,8,'DONE','Process exited normally.',1494427068),(2904,8,'WAIT','Waiting 180 second(s) to restart process.',1494427068),(2905,9,'INIT','Starting process.',1494427080),(2906,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427096),(2907,9,'DONE','Process exited normally.',1494427096),(2908,9,'WAIT','Waiting 180 second(s) to restart process.',1494427096),(2909,7,'INIT','Starting process.',1494427248),(2910,8,'INIT','Starting process.',1494427249),(2911,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427249),(2912,7,'DONE','Process exited normally.',1494427249),(2913,7,'WAIT','Waiting 180 second(s) to restart process.',1494427249),(2914,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427249),(2915,8,'DONE','Process exited normally.',1494427249),(2916,8,'WAIT','Waiting 180 second(s) to restart process.',1494427249),(2917,9,'INIT','Starting process.',1494427276),(2918,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427292),(2919,9,'DONE','Process exited normally.',1494427292),(2920,9,'WAIT','Waiting 180 second(s) to restart process.',1494427292),(2921,7,'INIT','Starting process.',1494427429),(2922,8,'INIT','Starting process.',1494427429),(2923,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427429),(2924,7,'DONE','Process exited normally.',1494427429),(2925,7,'WAIT','Waiting 180 second(s) to restart process.',1494427429),(2926,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427429),(2927,8,'DONE','Process exited normally.',1494427429),(2928,8,'WAIT','Waiting 180 second(s) to restart process.',1494427429),(2929,9,'INIT','Starting process.',1494427472),(2930,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427488),(2931,9,'DONE','Process exited normally.',1494427488),(2932,9,'WAIT','Waiting 180 second(s) to restart process.',1494427488),(2933,7,'INIT','Starting process.',1494427609),(2934,8,'INIT','Starting process.',1494427609),(2935,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427609),(2936,7,'DONE','Process exited normally.',1494427609),(2937,7,'WAIT','Waiting 180 second(s) to restart process.',1494427609),(2938,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427609),(2939,8,'DONE','Process exited normally.',1494427609),(2940,8,'WAIT','Waiting 180 second(s) to restart process.',1494427609),(2941,9,'INIT','Starting process.',1494427668),(2942,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427684),(2943,9,'DONE','Process exited normally.',1494427684),(2944,9,'WAIT','Waiting 180 second(s) to restart process.',1494427684),(2945,7,'INIT','Starting process.',1494427789),(2946,8,'INIT','Starting process.',1494427789),(2947,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427789),(2948,7,'DONE','Process exited normally.',1494427789),(2949,7,'WAIT','Waiting 180 second(s) to restart process.',1494427789),(2950,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427789),(2951,8,'DONE','Process exited normally.',1494427789),(2952,8,'WAIT','Waiting 180 second(s) to restart process.',1494427789),(2953,9,'INIT','Starting process.',1494427864),(2954,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427880),(2955,9,'DONE','Process exited normally.',1494427880),(2956,9,'WAIT','Waiting 180 second(s) to restart process.',1494427880),(2957,7,'INIT','Starting process.',1494427969),(2958,8,'INIT','Starting process.',1494427969),(2959,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427969),(2960,7,'DONE','Process exited normally.',1494427969),(2961,7,'WAIT','Waiting 180 second(s) to restart process.',1494427969),(2962,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494427969),(2963,8,'DONE','Process exited normally.',1494427969),(2964,8,'WAIT','Waiting 180 second(s) to restart process.',1494427969),(2965,9,'INIT','Starting process.',1494428060),(2966,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428077),(2967,9,'DONE','Process exited normally.',1494428077),(2968,9,'WAIT','Waiting 180 second(s) to restart process.',1494428077),(2969,7,'INIT','Starting process.',1494428149),(2970,8,'INIT','Starting process.',1494428149),(2971,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428149),(2972,7,'DONE','Process exited normally.',1494428149),(2973,7,'WAIT','Waiting 180 second(s) to restart process.',1494428149),(2974,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428149),(2975,8,'DONE','Process exited normally.',1494428149),(2976,8,'WAIT','Waiting 180 second(s) to restart process.',1494428149),(2977,9,'INIT','Starting process.',1494428257),(2978,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428274),(2979,9,'DONE','Process exited normally.',1494428274),(2980,9,'WAIT','Waiting 180 second(s) to restart process.',1494428274),(2981,7,'INIT','Starting process.',1494428329),(2982,8,'INIT','Starting process.',1494428329),(2983,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428329),(2984,7,'DONE','Process exited normally.',1494428329),(2985,7,'WAIT','Waiting 180 second(s) to restart process.',1494428329),(2986,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428329),(2987,8,'DONE','Process exited normally.',1494428329),(2988,8,'WAIT','Waiting 180 second(s) to restart process.',1494428329),(2989,9,'INIT','Starting process.',1494428454),(2990,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428471),(2991,9,'DONE','Process exited normally.',1494428471),(2992,9,'WAIT','Waiting 180 second(s) to restart process.',1494428471),(2993,7,'INIT','Starting process.',1494428509),(2994,8,'INIT','Starting process.',1494428509),(2995,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428509),(2996,7,'DONE','Process exited normally.',1494428509),(2997,7,'WAIT','Waiting 180 second(s) to restart process.',1494428509),(2998,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428509),(2999,8,'DONE','Process exited normally.',1494428509),(3000,8,'WAIT','Waiting 180 second(s) to restart process.',1494428509),(3001,9,'INIT','Starting process.',1494428651),(3002,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428667),(3003,9,'DONE','Process exited normally.',1494428667),(3004,9,'WAIT','Waiting 180 second(s) to restart process.',1494428667),(3005,7,'INIT','Starting process.',1494428689),(3006,8,'INIT','Starting process.',1494428689),(3007,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428689),(3008,7,'DONE','Process exited normally.',1494428689),(3009,7,'WAIT','Waiting 180 second(s) to restart process.',1494428689),(3010,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428689),(3011,8,'DONE','Process exited normally.',1494428689),(3012,8,'WAIT','Waiting 180 second(s) to restart process.',1494428689),(3013,9,'INIT','Starting process.',1494428847),(3014,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428863),(3015,9,'DONE','Process exited normally.',1494428863),(3016,9,'WAIT','Waiting 180 second(s) to restart process.',1494428863),(3017,7,'INIT','Starting process.',1494428869),(3018,8,'INIT','Starting process.',1494428869),(3019,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428869),(3020,7,'DONE','Process exited normally.',1494428869),(3021,7,'WAIT','Waiting 180 second(s) to restart process.',1494428869),(3022,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494428869),(3023,8,'DONE','Process exited normally.',1494428869),(3024,8,'WAIT','Waiting 180 second(s) to restart process.',1494428869),(3025,9,'INIT','Starting process.',1494429043),(3026,7,'INIT','Starting process.',1494429049),(3027,8,'INIT','Starting process.',1494429049),(3028,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429049),(3029,7,'DONE','Process exited normally.',1494429049),(3030,7,'WAIT','Waiting 180 second(s) to restart process.',1494429049),(3031,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429049),(3032,8,'DONE','Process exited normally.',1494429049),(3033,8,'WAIT','Waiting 180 second(s) to restart process.',1494429049),(3034,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429059),(3035,9,'DONE','Process exited normally.',1494429059),(3036,9,'WAIT','Waiting 180 second(s) to restart process.',1494429059),(3037,7,'INIT','Starting process.',1494429229),(3038,8,'INIT','Starting process.',1494429229),(3039,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429230),(3040,7,'DONE','Process exited normally.',1494429230),(3041,7,'WAIT','Waiting 180 second(s) to restart process.',1494429230),(3042,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429230),(3043,8,'DONE','Process exited normally.',1494429230),(3044,8,'WAIT','Waiting 180 second(s) to restart process.',1494429230),(3045,9,'INIT','Starting process.',1494429239),(3046,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429255),(3047,9,'DONE','Process exited normally.',1494429255),(3048,9,'WAIT','Waiting 180 second(s) to restart process.',1494429255),(3049,7,'INIT','Starting process.',1494429410),(3050,8,'INIT','Starting process.',1494429410),(3051,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429411),(3052,7,'DONE','Process exited normally.',1494429411),(3053,7,'WAIT','Waiting 180 second(s) to restart process.',1494429411),(3054,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429411),(3055,8,'DONE','Process exited normally.',1494429411),(3056,8,'WAIT','Waiting 180 second(s) to restart process.',1494429411),(3057,9,'INIT','Starting process.',1494429435),(3058,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429451),(3059,9,'DONE','Process exited normally.',1494429451),(3060,9,'WAIT','Waiting 180 second(s) to restart process.',1494429451),(3061,7,'INIT','Starting process.',1494429591),(3062,8,'INIT','Starting process.',1494429591),(3063,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429591),(3064,7,'DONE','Process exited normally.',1494429591),(3065,7,'WAIT','Waiting 180 second(s) to restart process.',1494429591),(3066,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429591),(3067,8,'DONE','Process exited normally.',1494429591),(3068,8,'WAIT','Waiting 180 second(s) to restart process.',1494429591),(3069,9,'INIT','Starting process.',1494429631),(3070,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429647),(3071,9,'DONE','Process exited normally.',1494429647),(3072,9,'WAIT','Waiting 180 second(s) to restart process.',1494429647),(3073,7,'INIT','Starting process.',1494429771),(3074,8,'INIT','Starting process.',1494429771),(3075,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429771),(3076,7,'DONE','Process exited normally.',1494429771),(3077,7,'WAIT','Waiting 180 second(s) to restart process.',1494429771),(3078,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429771),(3079,8,'DONE','Process exited normally.',1494429771),(3080,8,'WAIT','Waiting 180 second(s) to restart process.',1494429771),(3081,9,'INIT','Starting process.',1494429827),(3082,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429843),(3083,9,'DONE','Process exited normally.',1494429843),(3084,9,'WAIT','Waiting 180 second(s) to restart process.',1494429843),(3085,7,'INIT','Starting process.',1494429951),(3086,8,'INIT','Starting process.',1494429951),(3087,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429951),(3088,7,'DONE','Process exited normally.',1494429951),(3089,7,'WAIT','Waiting 180 second(s) to restart process.',1494429951),(3090,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494429951),(3091,8,'DONE','Process exited normally.',1494429951),(3092,8,'WAIT','Waiting 180 second(s) to restart process.',1494429951),(3093,9,'INIT','Starting process.',1494430023),(3094,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430039),(3095,9,'DONE','Process exited normally.',1494430039),(3096,9,'WAIT','Waiting 180 second(s) to restart process.',1494430039),(3097,7,'INIT','Starting process.',1494430131),(3098,8,'INIT','Starting process.',1494430131),(3099,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430131),(3100,7,'DONE','Process exited normally.',1494430131),(3101,7,'WAIT','Waiting 180 second(s) to restart process.',1494430131),(3102,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430131),(3103,8,'DONE','Process exited normally.',1494430131),(3104,8,'WAIT','Waiting 180 second(s) to restart process.',1494430131),(3105,9,'INIT','Starting process.',1494430219),(3106,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430236),(3107,9,'DONE','Process exited normally.',1494430236),(3108,9,'WAIT','Waiting 180 second(s) to restart process.',1494430236),(3109,7,'INIT','Starting process.',1494430311),(3110,8,'INIT','Starting process.',1494430311),(3111,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430311),(3112,7,'DONE','Process exited normally.',1494430311),(3113,7,'WAIT','Waiting 180 second(s) to restart process.',1494430311),(3114,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430311),(3115,8,'DONE','Process exited normally.',1494430311),(3116,8,'WAIT','Waiting 180 second(s) to restart process.',1494430311),(3117,9,'INIT','Starting process.',1494430416),(3118,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430433),(3119,9,'DONE','Process exited normally.',1494430433),(3120,9,'WAIT','Waiting 180 second(s) to restart process.',1494430433),(3121,7,'INIT','Starting process.',1494430491),(3122,8,'INIT','Starting process.',1494430491),(3123,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430491),(3124,7,'DONE','Process exited normally.',1494430491),(3125,7,'WAIT','Waiting 180 second(s) to restart process.',1494430491),(3126,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430491),(3127,8,'DONE','Process exited normally.',1494430491),(3128,8,'WAIT','Waiting 180 second(s) to restart process.',1494430491),(3129,9,'INIT','Starting process.',1494430613),(3130,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430630),(3131,9,'DONE','Process exited normally.',1494430630),(3132,9,'WAIT','Waiting 180 second(s) to restart process.',1494430630),(3133,7,'INIT','Starting process.',1494430671),(3134,8,'INIT','Starting process.',1494430671),(3135,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430671),(3136,7,'DONE','Process exited normally.',1494430671),(3137,7,'WAIT','Waiting 180 second(s) to restart process.',1494430671),(3138,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430671),(3139,8,'DONE','Process exited normally.',1494430671),(3140,8,'WAIT','Waiting 180 second(s) to restart process.',1494430671),(3141,9,'INIT','Starting process.',1494430810),(3142,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430826),(3143,9,'DONE','Process exited normally.',1494430826),(3144,9,'WAIT','Waiting 180 second(s) to restart process.',1494430826),(3145,7,'INIT','Starting process.',1494430851),(3146,8,'INIT','Starting process.',1494430851),(3147,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430851),(3148,7,'DONE','Process exited normally.',1494430851),(3149,7,'WAIT','Waiting 180 second(s) to restart process.',1494430851),(3150,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494430851),(3151,8,'DONE','Process exited normally.',1494430851),(3152,8,'WAIT','Waiting 180 second(s) to restart process.',1494430851),(3153,9,'INIT','Starting process.',1494431006),(3154,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431022),(3155,9,'DONE','Process exited normally.',1494431022),(3156,9,'WAIT','Waiting 180 second(s) to restart process.',1494431022),(3157,7,'INIT','Starting process.',1494431031),(3158,8,'INIT','Starting process.',1494431031),(3159,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431031),(3160,7,'DONE','Process exited normally.',1494431031),(3161,7,'WAIT','Waiting 180 second(s) to restart process.',1494431031),(3162,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431031),(3163,8,'DONE','Process exited normally.',1494431031),(3164,8,'WAIT','Waiting 180 second(s) to restart process.',1494431031),(3165,9,'INIT','Starting process.',1494431202),(3166,7,'INIT','Starting process.',1494431211),(3167,8,'INIT','Starting process.',1494431211),(3168,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431211),(3169,7,'DONE','Process exited normally.',1494431211),(3170,7,'WAIT','Waiting 180 second(s) to restart process.',1494431211),(3171,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431211),(3172,8,'DONE','Process exited normally.',1494431211),(3173,8,'WAIT','Waiting 180 second(s) to restart process.',1494431211),(3174,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431218),(3175,9,'DONE','Process exited normally.',1494431218),(3176,9,'WAIT','Waiting 180 second(s) to restart process.',1494431218),(3177,7,'INIT','Starting process.',1494431391),(3178,8,'INIT','Starting process.',1494431391),(3179,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431392),(3180,7,'DONE','Process exited normally.',1494431392),(3181,7,'WAIT','Waiting 180 second(s) to restart process.',1494431392),(3182,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431392),(3183,8,'DONE','Process exited normally.',1494431392),(3184,8,'WAIT','Waiting 180 second(s) to restart process.',1494431392),(3185,9,'INIT','Starting process.',1494431398),(3186,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431414),(3187,9,'DONE','Process exited normally.',1494431414),(3188,9,'WAIT','Waiting 180 second(s) to restart process.',1494431414),(3189,7,'INIT','Starting process.',1494431572),(3190,8,'INIT','Starting process.',1494431572),(3191,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431573),(3192,7,'DONE','Process exited normally.',1494431573),(3193,7,'WAIT','Waiting 180 second(s) to restart process.',1494431573),(3194,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431573),(3195,8,'DONE','Process exited normally.',1494431573),(3196,8,'WAIT','Waiting 180 second(s) to restart process.',1494431573),(3197,9,'INIT','Starting process.',1494431594),(3198,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431610),(3199,9,'DONE','Process exited normally.',1494431610),(3200,9,'WAIT','Waiting 180 second(s) to restart process.',1494431610),(3201,7,'INIT','Starting process.',1494431753),(3202,8,'INIT','Starting process.',1494431753),(3203,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431753),(3204,7,'DONE','Process exited normally.',1494431753),(3205,7,'WAIT','Waiting 180 second(s) to restart process.',1494431753),(3206,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431753),(3207,8,'DONE','Process exited normally.',1494431753),(3208,8,'WAIT','Waiting 180 second(s) to restart process.',1494431753),(3209,9,'INIT','Starting process.',1494431790),(3210,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431806),(3211,9,'DONE','Process exited normally.',1494431806),(3212,9,'WAIT','Waiting 180 second(s) to restart process.',1494431806),(3213,7,'INIT','Starting process.',1494431933),(3214,8,'INIT','Starting process.',1494431933),(3215,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431933),(3216,7,'DONE','Process exited normally.',1494431933),(3217,7,'WAIT','Waiting 180 second(s) to restart process.',1494431933),(3218,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494431933),(3219,8,'DONE','Process exited normally.',1494431933),(3220,8,'WAIT','Waiting 180 second(s) to restart process.',1494431933),(3221,9,'INIT','Starting process.',1494431986),(3222,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432002),(3223,9,'DONE','Process exited normally.',1494432002),(3224,9,'WAIT','Waiting 180 second(s) to restart process.',1494432002),(3225,7,'INIT','Starting process.',1494432113),(3226,8,'INIT','Starting process.',1494432113),(3227,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432113),(3228,7,'DONE','Process exited normally.',1494432113),(3229,7,'WAIT','Waiting 180 second(s) to restart process.',1494432113),(3230,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432113),(3231,8,'DONE','Process exited normally.',1494432113),(3232,8,'WAIT','Waiting 180 second(s) to restart process.',1494432113),(3233,9,'INIT','Starting process.',1494432182),(3234,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432198),(3235,9,'DONE','Process exited normally.',1494432198),(3236,9,'WAIT','Waiting 180 second(s) to restart process.',1494432198),(3237,7,'INIT','Starting process.',1494432293),(3238,8,'INIT','Starting process.',1494432293),(3239,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432293),(3240,7,'DONE','Process exited normally.',1494432293),(3241,7,'WAIT','Waiting 180 second(s) to restart process.',1494432293),(3242,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432293),(3243,8,'DONE','Process exited normally.',1494432293),(3244,8,'WAIT','Waiting 180 second(s) to restart process.',1494432293),(3245,9,'INIT','Starting process.',1494432378),(3246,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432394),(3247,9,'DONE','Process exited normally.',1494432394),(3248,9,'WAIT','Waiting 180 second(s) to restart process.',1494432394),(3249,7,'INIT','Starting process.',1494432473),(3250,8,'INIT','Starting process.',1494432473),(3251,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432473),(3252,7,'DONE','Process exited normally.',1494432473),(3253,7,'WAIT','Waiting 180 second(s) to restart process.',1494432473),(3254,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432473),(3255,8,'DONE','Process exited normally.',1494432473),(3256,8,'WAIT','Waiting 180 second(s) to restart process.',1494432473),(3257,9,'INIT','Starting process.',1494432574),(3258,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432591),(3259,9,'DONE','Process exited normally.',1494432591),(3260,9,'WAIT','Waiting 180 second(s) to restart process.',1494432591),(3261,7,'INIT','Starting process.',1494432653),(3262,8,'INIT','Starting process.',1494432653),(3263,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432653),(3264,7,'DONE','Process exited normally.',1494432653),(3265,7,'WAIT','Waiting 180 second(s) to restart process.',1494432653),(3266,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432653),(3267,8,'DONE','Process exited normally.',1494432653),(3268,8,'WAIT','Waiting 180 second(s) to restart process.',1494432653),(3269,9,'INIT','Starting process.',1494432771),(3270,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432788),(3271,9,'DONE','Process exited normally.',1494432788),(3272,9,'WAIT','Waiting 180 second(s) to restart process.',1494432788),(3273,7,'INIT','Starting process.',1494432833),(3274,8,'INIT','Starting process.',1494432833),(3275,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432833),(3276,7,'DONE','Process exited normally.',1494432833),(3277,7,'WAIT','Waiting 180 second(s) to restart process.',1494432833),(3278,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432833),(3279,8,'DONE','Process exited normally.',1494432833),(3280,8,'WAIT','Waiting 180 second(s) to restart process.',1494432833),(3281,9,'INIT','Starting process.',1494432968),(3282,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494432985),(3283,9,'DONE','Process exited normally.',1494432985),(3284,9,'WAIT','Waiting 180 second(s) to restart process.',1494432985),(3285,7,'INIT','Starting process.',1494433013),(3286,8,'INIT','Starting process.',1494433013),(3287,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433013),(3288,7,'DONE','Process exited normally.',1494433013),(3289,7,'WAIT','Waiting 180 second(s) to restart process.',1494433013),(3290,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433013),(3291,8,'DONE','Process exited normally.',1494433013),(3292,8,'WAIT','Waiting 180 second(s) to restart process.',1494433013),(3293,9,'INIT','Starting process.',1494433165),(3294,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433182),(3295,9,'DONE','Process exited normally.',1494433182),(3296,9,'WAIT','Waiting 180 second(s) to restart process.',1494433182),(3297,7,'INIT','Starting process.',1494433193),(3298,8,'INIT','Starting process.',1494433193),(3299,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433193),(3300,7,'DONE','Process exited normally.',1494433193),(3301,7,'WAIT','Waiting 180 second(s) to restart process.',1494433193),(3302,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433193),(3303,8,'DONE','Process exited normally.',1494433193),(3304,8,'WAIT','Waiting 180 second(s) to restart process.',1494433193),(3305,9,'INIT','Starting process.',1494433362),(3306,7,'INIT','Starting process.',1494433373),(3307,8,'INIT','Starting process.',1494433373),(3308,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433373),(3309,7,'DONE','Process exited normally.',1494433373),(3310,7,'WAIT','Waiting 180 second(s) to restart process.',1494433373),(3311,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433373),(3312,8,'DONE','Process exited normally.',1494433373),(3313,8,'WAIT','Waiting 180 second(s) to restart process.',1494433373),(3314,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433378),(3315,9,'DONE','Process exited normally.',1494433378),(3316,9,'WAIT','Waiting 180 second(s) to restart process.',1494433378),(3317,7,'INIT','Starting process.',1494433553),(3318,8,'INIT','Starting process.',1494433553),(3319,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433553),(3320,7,'DONE','Process exited normally.',1494433554),(3321,7,'WAIT','Waiting 179 second(s) to restart process.',1494433554),(3322,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433554),(3323,8,'DONE','Process exited normally.',1494433554),(3324,8,'WAIT','Waiting 180 second(s) to restart process.',1494433554),(3325,9,'INIT','Starting process.',1494433558),(3326,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433574),(3327,9,'DONE','Process exited normally.',1494433574),(3328,9,'WAIT','Waiting 180 second(s) to restart process.',1494433574),(3329,7,'INIT','Starting process.',1494433733),(3330,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433734),(3331,7,'DONE','Process exited normally.',1494433734),(3332,7,'WAIT','Waiting 180 second(s) to restart process.',1494433734),(3333,8,'INIT','Starting process.',1494433734),(3334,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433734),(3335,8,'DONE','Process exited normally.',1494433734),(3336,8,'WAIT','Waiting 180 second(s) to restart process.',1494433734),(3337,9,'INIT','Starting process.',1494433754),(3338,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433770),(3339,9,'DONE','Process exited normally.',1494433770),(3340,9,'WAIT','Waiting 180 second(s) to restart process.',1494433770),(3341,7,'INIT','Starting process.',1494433914),(3342,8,'INIT','Starting process.',1494433914),(3343,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433914),(3344,7,'DONE','Process exited normally.',1494433914),(3345,7,'WAIT','Waiting 180 second(s) to restart process.',1494433914),(3346,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433914),(3347,8,'DONE','Process exited normally.',1494433914),(3348,8,'WAIT','Waiting 180 second(s) to restart process.',1494433914),(3349,9,'INIT','Starting process.',1494433950),(3350,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494433966),(3351,9,'DONE','Process exited normally.',1494433966),(3352,9,'WAIT','Waiting 180 second(s) to restart process.',1494433966),(3353,7,'INIT','Starting process.',1494434094),(3354,8,'INIT','Starting process.',1494434094),(3355,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434094),(3356,7,'DONE','Process exited normally.',1494434094),(3357,7,'WAIT','Waiting 180 second(s) to restart process.',1494434094),(3358,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434094),(3359,8,'DONE','Process exited normally.',1494434094),(3360,8,'WAIT','Waiting 180 second(s) to restart process.',1494434094),(3361,9,'INIT','Starting process.',1494434146),(3362,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434162),(3363,9,'DONE','Process exited normally.',1494434162),(3364,9,'WAIT','Waiting 180 second(s) to restart process.',1494434162),(3365,7,'INIT','Starting process.',1494434274),(3366,8,'INIT','Starting process.',1494434274),(3367,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434274),(3368,7,'DONE','Process exited normally.',1494434274),(3369,7,'WAIT','Waiting 180 second(s) to restart process.',1494434274),(3370,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434274),(3371,8,'DONE','Process exited normally.',1494434274),(3372,8,'WAIT','Waiting 180 second(s) to restart process.',1494434274),(3373,9,'INIT','Starting process.',1494434342),(3374,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434359),(3375,9,'DONE','Process exited normally.',1494434359),(3376,9,'WAIT','Waiting 180 second(s) to restart process.',1494434359),(3377,7,'INIT','Starting process.',1494434454),(3378,8,'INIT','Starting process.',1494434454),(3379,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434454),(3380,7,'DONE','Process exited normally.',1494434454),(3381,7,'WAIT','Waiting 180 second(s) to restart process.',1494434454),(3382,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434454),(3383,8,'DONE','Process exited normally.',1494434454),(3384,8,'WAIT','Waiting 180 second(s) to restart process.',1494434454),(3385,9,'INIT','Starting process.',1494434539),(3386,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434556),(3387,9,'DONE','Process exited normally.',1494434556),(3388,9,'WAIT','Waiting 180 second(s) to restart process.',1494434556),(3389,7,'INIT','Starting process.',1494434634),(3390,8,'INIT','Starting process.',1494434634),(3391,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434634),(3392,7,'DONE','Process exited normally.',1494434634),(3393,7,'WAIT','Waiting 180 second(s) to restart process.',1494434634),(3394,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434634),(3395,8,'DONE','Process exited normally.',1494434634),(3396,8,'WAIT','Waiting 180 second(s) to restart process.',1494434634),(3397,9,'INIT','Starting process.',1494434736),(3398,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434753),(3399,9,'DONE','Process exited normally.',1494434753),(3400,9,'WAIT','Waiting 180 second(s) to restart process.',1494434753),(3401,7,'INIT','Starting process.',1494434814),(3402,8,'INIT','Starting process.',1494434814),(3403,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434814),(3404,7,'DONE','Process exited normally.',1494434814),(3405,7,'WAIT','Waiting 180 second(s) to restart process.',1494434814),(3406,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434814),(3407,8,'DONE','Process exited normally.',1494434814),(3408,8,'WAIT','Waiting 180 second(s) to restart process.',1494434814),(3409,9,'INIT','Starting process.',1494434933),(3410,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434949),(3411,9,'DONE','Process exited normally.',1494434949),(3412,9,'WAIT','Waiting 180 second(s) to restart process.',1494434949),(3413,7,'INIT','Starting process.',1494434994),(3414,8,'INIT','Starting process.',1494434994),(3415,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434994),(3416,7,'DONE','Process exited normally.',1494434994),(3417,7,'WAIT','Waiting 180 second(s) to restart process.',1494434994),(3418,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494434994),(3419,8,'DONE','Process exited normally.',1494434994),(3420,8,'WAIT','Waiting 180 second(s) to restart process.',1494434994),(3421,9,'INIT','Starting process.',1494435129),(3422,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435145),(3423,9,'DONE','Process exited normally.',1494435145),(3424,9,'WAIT','Waiting 180 second(s) to restart process.',1494435145),(3425,7,'INIT','Starting process.',1494435174),(3426,8,'INIT','Starting process.',1494435174),(3427,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435174),(3428,7,'DONE','Process exited normally.',1494435174),(3429,7,'WAIT','Waiting 180 second(s) to restart process.',1494435174),(3430,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435174),(3431,8,'DONE','Process exited normally.',1494435174),(3432,8,'WAIT','Waiting 180 second(s) to restart process.',1494435174),(3433,9,'INIT','Starting process.',1494435325),(3434,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435341),(3435,9,'DONE','Process exited normally.',1494435341),(3436,9,'WAIT','Waiting 180 second(s) to restart process.',1494435341),(3437,7,'INIT','Starting process.',1494435354),(3438,8,'INIT','Starting process.',1494435354),(3439,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435354),(3440,7,'DONE','Process exited normally.',1494435354),(3441,7,'WAIT','Waiting 180 second(s) to restart process.',1494435354),(3442,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435354),(3443,8,'DONE','Process exited normally.',1494435354),(3444,8,'WAIT','Waiting 179 second(s) to restart process.',1494435355),(3445,9,'INIT','Starting process.',1494435521),(3446,7,'INIT','Starting process.',1494435534),(3447,8,'INIT','Starting process.',1494435534),(3448,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435534),(3449,7,'DONE','Process exited normally.',1494435534),(3450,7,'WAIT','Waiting 180 second(s) to restart process.',1494435534),(3451,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435534),(3452,8,'DONE','Process exited normally.',1494435534),(3453,8,'WAIT','Waiting 180 second(s) to restart process.',1494435534),(3454,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435537),(3455,9,'DONE','Process exited normally.',1494435537),(3456,9,'WAIT','Waiting 180 second(s) to restart process.',1494435537),(3457,7,'INIT','Starting process.',1494435714),(3458,8,'INIT','Starting process.',1494435714),(3459,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435714),(3460,7,'DONE','Process exited normally.',1494435714),(3461,7,'WAIT','Waiting 180 second(s) to restart process.',1494435714),(3462,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435714),(3463,8,'DONE','Process exited normally.',1494435714),(3464,8,'WAIT','Waiting 180 second(s) to restart process.',1494435714),(3465,9,'INIT','Starting process.',1494435717),(3466,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435733),(3467,9,'DONE','Process exited normally.',1494435733),(3468,9,'WAIT','Waiting 180 second(s) to restart process.',1494435733),(3469,7,'INIT','Starting process.',1494435894),(3470,8,'INIT','Starting process.',1494435894),(3471,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435894),(3472,7,'DONE','Process exited normally.',1494435894),(3473,7,'WAIT','Waiting 180 second(s) to restart process.',1494435894),(3474,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435894),(3475,8,'DONE','Process exited normally.',1494435894),(3476,8,'WAIT','Waiting 180 second(s) to restart process.',1494435894),(3477,9,'INIT','Starting process.',1494435913),(3478,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494435929),(3479,9,'DONE','Process exited normally.',1494435929),(3480,9,'WAIT','Waiting 180 second(s) to restart process.',1494435929),(3481,7,'INIT','Starting process.',1494436074),(3482,8,'INIT','Starting process.',1494436074),(3483,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436074),(3484,7,'DONE','Process exited normally.',1494436074),(3485,7,'WAIT','Waiting 180 second(s) to restart process.',1494436074),(3486,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436074),(3487,8,'DONE','Process exited normally.',1494436074),(3488,8,'WAIT','Waiting 180 second(s) to restart process.',1494436074),(3489,9,'INIT','Starting process.',1494436109),(3490,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436125),(3491,9,'DONE','Process exited normally.',1494436125),(3492,9,'WAIT','Waiting 180 second(s) to restart process.',1494436125),(3493,7,'INIT','Starting process.',1494436254),(3494,8,'INIT','Starting process.',1494436254),(3495,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436254),(3496,7,'DONE','Process exited normally.',1494436254),(3497,7,'WAIT','Waiting 180 second(s) to restart process.',1494436254),(3498,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436254),(3499,8,'DONE','Process exited normally.',1494436254),(3500,8,'WAIT','Waiting 180 second(s) to restart process.',1494436254),(3501,9,'INIT','Starting process.',1494436305),(3502,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436321),(3503,9,'DONE','Process exited normally.',1494436321),(3504,9,'WAIT','Waiting 180 second(s) to restart process.',1494436321),(3505,7,'INIT','Starting process.',1494436434),(3506,8,'INIT','Starting process.',1494436434),(3507,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436434),(3508,7,'DONE','Process exited normally.',1494436434),(3509,7,'WAIT','Waiting 180 second(s) to restart process.',1494436434),(3510,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436434),(3511,8,'DONE','Process exited normally.',1494436434),(3512,8,'WAIT','Waiting 180 second(s) to restart process.',1494436434),(3513,9,'INIT','Starting process.',1494436501),(3514,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436518),(3515,9,'DONE','Process exited normally.',1494436518),(3516,9,'WAIT','Waiting 180 second(s) to restart process.',1494436518),(3517,7,'INIT','Starting process.',1494436614),(3518,8,'INIT','Starting process.',1494436614),(3519,7,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436614),(3520,7,'DONE','Process exited normally.',1494436614),(3521,7,'WAIT','Waiting 180 second(s) to restart process.',1494436614),(3522,8,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436614),(3523,8,'DONE','Process exited normally.',1494436614),(3524,8,'WAIT','Waiting 180 second(s) to restart process.',1494436614),(3525,9,'INIT','Starting process.',1494436698),(3526,9,'ZZZZ','Process is preparing to hibernate for 180 second(s).',1494436715),(3527,9,'DONE','Process exited normally.',1494436715),(3528,9,'WAIT','Waiting 180 second(s) to restart process.',1494436715);
/*!40000 ALTER TABLE `daemon_logevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_differential`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_differential` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_differential`;

--
-- Table structure for table `differential_affectedpath`
--

DROP TABLE IF EXISTS `differential_affectedpath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_affectedpath` (
  `repositoryID` int(10) unsigned NOT NULL,
  `pathID` int(10) unsigned NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `revisionID` int(10) unsigned NOT NULL,
  KEY `repositoryID` (`repositoryID`,`pathID`,`epoch`),
  KEY `revisionID` (`revisionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_affectedpath`
--

LOCK TABLES `differential_affectedpath` WRITE;
/*!40000 ALTER TABLE `differential_affectedpath` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_affectedpath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_changeset`
--

DROP TABLE IF EXISTS `differential_changeset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_changeset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `diffID` int(10) unsigned NOT NULL,
  `oldFile` longblob,
  `filename` longblob NOT NULL,
  `awayPaths` longtext COLLATE utf8mb4_bin,
  `changeType` int(10) unsigned NOT NULL,
  `fileType` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin,
  `oldProperties` longtext COLLATE utf8mb4_bin,
  `newProperties` longtext COLLATE utf8mb4_bin,
  `addLines` int(10) unsigned NOT NULL,
  `delLines` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `diffID` (`diffID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_changeset`
--

LOCK TABLES `differential_changeset` WRITE;
/*!40000 ALTER TABLE `differential_changeset` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_changeset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_changeset_parse_cache`
--

DROP TABLE IF EXISTS `differential_changeset_parse_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_changeset_parse_cache` (
  `id` int(10) unsigned NOT NULL,
  `cache` longblob NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dateCreated` (`dateCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_changeset_parse_cache`
--

LOCK TABLES `differential_changeset_parse_cache` WRITE;
/*!40000 ALTER TABLE `differential_changeset_parse_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_changeset_parse_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_commit`
--

DROP TABLE IF EXISTS `differential_commit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_commit` (
  `revisionID` int(10) unsigned NOT NULL,
  `commitPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`revisionID`,`commitPHID`),
  UNIQUE KEY `commitPHID` (`commitPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_commit`
--

LOCK TABLES `differential_commit` WRITE;
/*!40000 ALTER TABLE `differential_commit` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_commit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_customfieldnumericindex`
--

DROP TABLE IF EXISTS `differential_customfieldnumericindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_customfieldnumericindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`),
  KEY `key_find` (`indexKey`,`indexValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_customfieldnumericindex`
--

LOCK TABLES `differential_customfieldnumericindex` WRITE;
/*!40000 ALTER TABLE `differential_customfieldnumericindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_customfieldnumericindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_customfieldstorage`
--

DROP TABLE IF EXISTS `differential_customfieldstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_customfieldstorage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_customfieldstorage`
--

LOCK TABLES `differential_customfieldstorage` WRITE;
/*!40000 ALTER TABLE `differential_customfieldstorage` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_customfieldstorage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_customfieldstringindex`
--

DROP TABLE IF EXISTS `differential_customfieldstringindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_customfieldstringindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`(64)),
  KEY `key_find` (`indexKey`,`indexValue`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_customfieldstringindex`
--

LOCK TABLES `differential_customfieldstringindex` WRITE;
/*!40000 ALTER TABLE `differential_customfieldstringindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_customfieldstringindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_diff`
--

DROP TABLE IF EXISTS `differential_diff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_diff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `revisionID` int(10) unsigned DEFAULT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `repositoryPHID` varbinary(64) DEFAULT NULL,
  `sourceMachine` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `sourcePath` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceControlSystem` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceControlBaseRevision` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceControlPath` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `lintStatus` int(10) unsigned NOT NULL,
  `unitStatus` int(10) unsigned NOT NULL,
  `lineCount` int(10) unsigned NOT NULL,
  `branch` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `bookmark` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `creationMethod` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `repositoryUUID` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `commitPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `revisionID` (`revisionID`),
  KEY `key_commit` (`commitPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_diff`
--

LOCK TABLES `differential_diff` WRITE;
/*!40000 ALTER TABLE `differential_diff` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_diff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_diffproperty`
--

DROP TABLE IF EXISTS `differential_diffproperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_diffproperty` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `diffID` int(10) unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `diffID` (`diffID`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_diffproperty`
--

LOCK TABLES `differential_diffproperty` WRITE;
/*!40000 ALTER TABLE `differential_diffproperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_diffproperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_difftransaction`
--

DROP TABLE IF EXISTS `differential_difftransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_difftransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_difftransaction`
--

LOCK TABLES `differential_difftransaction` WRITE;
/*!40000 ALTER TABLE `differential_difftransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_difftransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_draft`
--

DROP TABLE IF EXISTS `differential_draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_draft` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `draftKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_unique` (`objectPHID`,`authorPHID`,`draftKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_draft`
--

LOCK TABLES `differential_draft` WRITE;
/*!40000 ALTER TABLE `differential_draft` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_hiddencomment`
--

DROP TABLE IF EXISTS `differential_hiddencomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_hiddencomment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `commentID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_user` (`userPHID`,`commentID`),
  KEY `key_comment` (`commentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_hiddencomment`
--

LOCK TABLES `differential_hiddencomment` WRITE;
/*!40000 ALTER TABLE `differential_hiddencomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_hiddencomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_hunk`
--

DROP TABLE IF EXISTS `differential_hunk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_hunk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `changesetID` int(10) unsigned NOT NULL,
  `changes` longtext COLLATE utf8mb4_bin,
  `oldOffset` int(10) unsigned NOT NULL,
  `oldLen` int(10) unsigned NOT NULL,
  `newOffset` int(10) unsigned NOT NULL,
  `newLen` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `changesetID` (`changesetID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_hunk`
--

LOCK TABLES `differential_hunk` WRITE;
/*!40000 ALTER TABLE `differential_hunk` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_hunk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_hunk_modern`
--

DROP TABLE IF EXISTS `differential_hunk_modern`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_hunk_modern` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `changesetID` int(10) unsigned NOT NULL,
  `oldOffset` int(10) unsigned NOT NULL,
  `oldLen` int(10) unsigned NOT NULL,
  `newOffset` int(10) unsigned NOT NULL,
  `newLen` int(10) unsigned NOT NULL,
  `dataType` binary(4) NOT NULL,
  `dataEncoding` varchar(16) COLLATE utf8mb4_bin DEFAULT NULL,
  `dataFormat` binary(4) NOT NULL,
  `data` longblob NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_changeset` (`changesetID`),
  KEY `key_created` (`dateCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_hunk_modern`
--

LOCK TABLES `differential_hunk_modern` WRITE;
/*!40000 ALTER TABLE `differential_hunk_modern` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_hunk_modern` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_reviewer`
--

DROP TABLE IF EXISTS `differential_reviewer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_reviewer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `revisionPHID` varbinary(64) NOT NULL,
  `reviewerPHID` varbinary(64) NOT NULL,
  `reviewerStatus` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `lastActionDiffPHID` varbinary(64) DEFAULT NULL,
  `lastCommentDiffPHID` varbinary(64) DEFAULT NULL,
  `lastActorPHID` varbinary(64) DEFAULT NULL,
  `voidedPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_revision` (`revisionPHID`,`reviewerPHID`),
  KEY `key_reviewer` (`reviewerPHID`,`revisionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_reviewer`
--

LOCK TABLES `differential_reviewer` WRITE;
/*!40000 ALTER TABLE `differential_reviewer` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_reviewer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_revision`
--

DROP TABLE IF EXISTS `differential_revision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_revision` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `originalTitle` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `summary` longtext COLLATE utf8mb4_bin NOT NULL,
  `testPlan` longtext COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `lastReviewerPHID` varbinary(64) DEFAULT NULL,
  `lineCount` int(10) unsigned DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `attached` longtext COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(40) NOT NULL,
  `branchName` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `authorPHID` (`authorPHID`,`status`),
  KEY `repositoryPHID` (`repositoryPHID`),
  KEY `key_status` (`status`,`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_revision`
--

LOCK TABLES `differential_revision` WRITE;
/*!40000 ALTER TABLE `differential_revision` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_revision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_revisionhash`
--

DROP TABLE IF EXISTS `differential_revisionhash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_revisionhash` (
  `revisionID` int(10) unsigned NOT NULL,
  `type` binary(4) NOT NULL,
  `hash` binary(40) NOT NULL,
  KEY `type` (`type`,`hash`),
  KEY `revisionID` (`revisionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_revisionhash`
--

LOCK TABLES `differential_revisionhash` WRITE;
/*!40000 ALTER TABLE `differential_revisionhash` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_revisionhash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_transaction`
--

DROP TABLE IF EXISTS `differential_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_transaction`
--

LOCK TABLES `differential_transaction` WRITE;
/*!40000 ALTER TABLE `differential_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `differential_transaction_comment`
--

DROP TABLE IF EXISTS `differential_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `differential_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `revisionPHID` varbinary(64) DEFAULT NULL,
  `changesetID` int(10) unsigned DEFAULT NULL,
  `isNewFile` tinyint(1) NOT NULL,
  `lineNumber` int(10) unsigned NOT NULL,
  `lineLength` int(10) unsigned NOT NULL,
  `fixedState` varchar(12) COLLATE utf8mb4_bin DEFAULT NULL,
  `hasReplies` tinyint(1) NOT NULL,
  `replyToCommentPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`),
  KEY `key_changeset` (`changesetID`),
  KEY `key_draft` (`authorPHID`,`transactionPHID`),
  KEY `key_revision` (`revisionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `differential_transaction_comment`
--

LOCK TABLES `differential_transaction_comment` WRITE;
/*!40000 ALTER TABLE `differential_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `differential_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_draft`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_draft` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_draft`;

--
-- Table structure for table `draft`
--

DROP TABLE IF EXISTS `draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draft` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) NOT NULL,
  `draftKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `draft` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authorPHID` (`authorPHID`,`draftKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draft`
--

LOCK TABLES `draft` WRITE;
/*!40000 ALTER TABLE `draft` DISABLE KEYS */;
/*!40000 ALTER TABLE `draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draft_versioneddraft`
--

DROP TABLE IF EXISTS `draft_versioneddraft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draft_versioneddraft` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_object` (`objectPHID`,`authorPHID`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draft_versioneddraft`
--

LOCK TABLES `draft_versioneddraft` WRITE;
/*!40000 ALTER TABLE `draft_versioneddraft` DISABLE KEYS */;
/*!40000 ALTER TABLE `draft_versioneddraft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_drydock`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_drydock` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_drydock`;

--
-- Table structure for table `drydock_authorization`
--

DROP TABLE IF EXISTS `drydock_authorization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_authorization` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `blueprintPHID` varbinary(64) NOT NULL,
  `blueprintAuthorizationState` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `objectAuthorizationState` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_unique` (`objectPHID`,`blueprintPHID`),
  KEY `key_blueprint` (`blueprintPHID`,`blueprintAuthorizationState`),
  KEY `key_object` (`objectPHID`,`objectAuthorizationState`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_authorization`
--

LOCK TABLES `drydock_authorization` WRITE;
/*!40000 ALTER TABLE `drydock_authorization` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_authorization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_blueprint`
--

DROP TABLE IF EXISTS `drydock_blueprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_blueprint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `className` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `blueprintName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_blueprint`
--

LOCK TABLES `drydock_blueprint` WRITE;
/*!40000 ALTER TABLE `drydock_blueprint` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_blueprint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_blueprintname_ngrams`
--

DROP TABLE IF EXISTS `drydock_blueprintname_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_blueprintname_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_blueprintname_ngrams`
--

LOCK TABLES `drydock_blueprintname_ngrams` WRITE;
/*!40000 ALTER TABLE `drydock_blueprintname_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_blueprintname_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_blueprinttransaction`
--

DROP TABLE IF EXISTS `drydock_blueprinttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_blueprinttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_blueprinttransaction`
--

LOCK TABLES `drydock_blueprinttransaction` WRITE;
/*!40000 ALTER TABLE `drydock_blueprinttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_blueprinttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_command`
--

DROP TABLE IF EXISTS `drydock_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_command` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) NOT NULL,
  `targetPHID` varbinary(64) NOT NULL,
  `command` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `isConsumed` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_target` (`targetPHID`,`isConsumed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_command`
--

LOCK TABLES `drydock_command` WRITE;
/*!40000 ALTER TABLE `drydock_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_lease`
--

DROP TABLE IF EXISTS `drydock_lease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_lease` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `until` int(10) unsigned DEFAULT NULL,
  `ownerPHID` varbinary(64) DEFAULT NULL,
  `attributes` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `resourceType` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `resourcePHID` varbinary(64) DEFAULT NULL,
  `authorizingPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_resource` (`resourcePHID`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_lease`
--

LOCK TABLES `drydock_lease` WRITE;
/*!40000 ALTER TABLE `drydock_lease` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_lease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_log`
--

DROP TABLE IF EXISTS `drydock_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `epoch` int(10) unsigned NOT NULL,
  `blueprintPHID` varbinary(64) DEFAULT NULL,
  `resourcePHID` varbinary(64) DEFAULT NULL,
  `leasePHID` varbinary(64) DEFAULT NULL,
  `type` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `epoch` (`epoch`),
  KEY `key_blueprint` (`blueprintPHID`,`type`),
  KEY `key_resource` (`resourcePHID`,`type`),
  KEY `key_lease` (`leasePHID`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_log`
--

LOCK TABLES `drydock_log` WRITE;
/*!40000 ALTER TABLE `drydock_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_repositoryoperation`
--

DROP TABLE IF EXISTS `drydock_repositoryoperation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_repositoryoperation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `repositoryTarget` longblob NOT NULL,
  `operationType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `operationState` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isDismissed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`),
  KEY `key_repository` (`repositoryPHID`,`operationState`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_repositoryoperation`
--

LOCK TABLES `drydock_repositoryoperation` WRITE;
/*!40000 ALTER TABLE `drydock_repositoryoperation` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_repositoryoperation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_resource`
--

DROP TABLE IF EXISTS `drydock_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_resource` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `ownerPHID` varbinary(64) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `attributes` longtext COLLATE utf8mb4_bin NOT NULL,
  `capabilities` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `blueprintPHID` varbinary(64) NOT NULL,
  `until` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_type` (`type`,`status`),
  KEY `key_blueprint` (`blueprintPHID`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_resource`
--

LOCK TABLES `drydock_resource` WRITE;
/*!40000 ALTER TABLE `drydock_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drydock_slotlock`
--

DROP TABLE IF EXISTS `drydock_slotlock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drydock_slotlock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ownerPHID` varbinary(64) NOT NULL,
  `lockIndex` binary(12) NOT NULL,
  `lockKey` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_lock` (`lockIndex`),
  KEY `key_owner` (`ownerPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drydock_slotlock`
--

LOCK TABLES `drydock_slotlock` WRITE;
/*!40000 ALTER TABLE `drydock_slotlock` DISABLE KEYS */;
/*!40000 ALTER TABLE `drydock_slotlock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_feed`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_feed` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_feed`;

--
-- Table structure for table `feed_storydata`
--

DROP TABLE IF EXISTS `feed_storydata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_storydata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `chronologicalKey` bigint(20) unsigned NOT NULL,
  `storyType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `storyData` longtext COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chronologicalKey` (`chronologicalKey`),
  UNIQUE KEY `phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_storydata`
--

LOCK TABLES `feed_storydata` WRITE;
/*!40000 ALTER TABLE `feed_storydata` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_storydata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed_storynotification`
--

DROP TABLE IF EXISTS `feed_storynotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_storynotification` (
  `userPHID` varbinary(64) NOT NULL,
  `primaryObjectPHID` varbinary(64) NOT NULL,
  `chronologicalKey` bigint(20) unsigned NOT NULL,
  `hasViewed` tinyint(1) NOT NULL,
  UNIQUE KEY `userPHID` (`userPHID`,`chronologicalKey`),
  KEY `userPHID_2` (`userPHID`,`hasViewed`,`primaryObjectPHID`),
  KEY `key_object` (`primaryObjectPHID`),
  KEY `key_chronological` (`chronologicalKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_storynotification`
--

LOCK TABLES `feed_storynotification` WRITE;
/*!40000 ALTER TABLE `feed_storynotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_storynotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed_storyreference`
--

DROP TABLE IF EXISTS `feed_storyreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_storyreference` (
  `objectPHID` varbinary(64) NOT NULL,
  `chronologicalKey` bigint(20) unsigned NOT NULL,
  UNIQUE KEY `objectPHID` (`objectPHID`,`chronologicalKey`),
  KEY `chronologicalKey` (`chronologicalKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_storyreference`
--

LOCK TABLES `feed_storyreference` WRITE;
/*!40000 ALTER TABLE `feed_storyreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_storyreference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_file`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_file` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_file`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `byteSize` bigint(20) unsigned NOT NULL,
  `storageEngine` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `storageFormat` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `storageHandle` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `secretKey` binary(20) DEFAULT NULL,
  `contentHash` binary(64) DEFAULT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `ttl` int(10) unsigned DEFAULT NULL,
  `isExplicitUpload` tinyint(1) DEFAULT '1',
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `isPartial` tinyint(1) NOT NULL DEFAULT '0',
  `builtinKey` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `key_builtin` (`builtinKey`),
  KEY `authorPHID` (`authorPHID`),
  KEY `contentHash` (`contentHash`),
  KEY `key_ttl` (`ttl`),
  KEY `key_dateCreated` (`dateCreated`),
  KEY `key_partial` (`authorPHID`,`isPartial`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (1,0x504849442D46494C452D71766279747A63366667756F7A6A7A736E766669,'alphanumeric/lato-white/A.png-#335862-0,0,0,0.3.png','image/png',4250,'blob','raw','1',1494270894,1494270894,NULL,0x7878376834336A6E646E723434766B6D64626E35,0x61656564393939353762363861613431353837303264616238663739313137383732396464396537623337356434363866643638633861633665643133633531,'{\"storage\":[],\"integrity\":\"66d3dc923eb055fda9ac31054a0e35c015ff4209da9bda35bd5d2b1c3af12549\",\"canCDN\":1,\"profile\":true,\"width\":400,\"height\":400}',NULL,0,0x74336879786733666271363378646E6C79626432,0x7573657273,0,NULL),(2,0x504849442D46494C452D64656E66796D65336D73646A6C6B657772646A72,'alphanumeric/lato-white/P.png-#d39edb-0,0,0,0.3.png','image/png',2568,'blob','raw','2',1494271766,1494271766,NULL,0x3762696374736462323534773735337A706C7A6C,0x37343539653266666431653162333564656236323337643630643539313430636637666234313434613161633135636162306139343838343331333230636561,'{\"storage\":[],\"integrity\":\"f034485b76fcc92a0267a2c7db14525ff761596dcc4e15ac4ac897e2fa4d6a04\",\"canCDN\":1,\"profile\":true,\"width\":400,\"height\":400}',NULL,0,0x64686E746A7A65716D34666F7961646368696E33,0x7573657273,0,NULL),(3,0x504849442D46494C452D6C747436667677347A79673578716B767861737A,'profile.png','image/png',3752,'blob','raw','3',1494271918,1494271918,NULL,0x36686B6870783661787769776B347973736C3567,0x64313535633766323637373066373938346161383936303761626438653335396462356564643233646664373962333161363961616531366265336630396639,'{\"storage\":[],\"integrity\":\"bb93833b3a2afe196752c83f0211dd75e9c553be86a0d2007a70d3238214cb2c\",\"canCDN\":1,\"builtin\":\"builtin:disk(name=profile.png)-ZMh_B1wLplhX\",\"width\":400,\"height\":400}',1494876718,0,0x706C7A3364706F7932626676646334626B353777,0x7573657273,0,'builtin:disk(name=profile.png)-ZMh_B1wLplhX');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_chunk`
--

DROP TABLE IF EXISTS `file_chunk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_chunk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chunkHandle` binary(12) NOT NULL,
  `byteStart` bigint(20) unsigned NOT NULL,
  `byteEnd` bigint(20) unsigned NOT NULL,
  `dataFilePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `key_file` (`chunkHandle`,`byteStart`,`byteEnd`),
  KEY `key_data` (`dataFilePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_chunk`
--

LOCK TABLES `file_chunk` WRITE;
/*!40000 ALTER TABLE `file_chunk` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_chunk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_externalrequest`
--

DROP TABLE IF EXISTS `file_externalrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_externalrequest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filePHID` varbinary(64) DEFAULT NULL,
  `ttl` int(10) unsigned NOT NULL,
  `uri` longtext COLLATE utf8mb4_bin NOT NULL,
  `uriIndex` binary(12) NOT NULL,
  `isSuccessful` tinyint(1) NOT NULL,
  `responseMessage` longtext COLLATE utf8mb4_bin,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_uriindex` (`uriIndex`),
  KEY `key_ttl` (`ttl`),
  KEY `key_file` (`filePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_externalrequest`
--

LOCK TABLES `file_externalrequest` WRITE;
/*!40000 ALTER TABLE `file_externalrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_externalrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_imagemacro`
--

DROP TABLE IF EXISTS `file_imagemacro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_imagemacro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `filePHID` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  `audioPHID` varbinary(64) DEFAULT NULL,
  `audioBehavior` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `name` (`name`),
  KEY `key_disabled` (`isDisabled`),
  KEY `key_dateCreated` (`dateCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_imagemacro`
--

LOCK TABLES `file_imagemacro` WRITE;
/*!40000 ALTER TABLE `file_imagemacro` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_imagemacro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storageblob`
--

DROP TABLE IF EXISTS `file_storageblob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_storageblob` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longblob NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storageblob`
--

LOCK TABLES `file_storageblob` WRITE;
/*!40000 ALTER TABLE `file_storageblob` DISABLE KEYS */;
INSERT INTO `file_storageblob` VALUES (1,0x89504E470D0A1A0A0000000D49484452000001900000019008020000000FDDA19B000010614944415478DAEDDD4D6B5C597EC0E1DB497B4695DA44E5A6402FA4916C441692AA36EAB88A81188666D66EC82204F211B2C9ECB2C807C8745621D39B40683234A4C1ED4D426CD34DF730947ADA21E86D13E11726587628503921294ACB2CDC31B2AD9254529D7FDD5BF7795633CD8C4A7D25FDEADC53F79CF3CE7BCB2B194011FC964B00081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520588060010816C078BD1BF01AEF7FF023171ACAE037DFFDCA080B40B000C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B00026EB5D978053FCED5FFC7479713EE6B5EE7CF5CB4F3EBFE39A6384C5452C2DCC85D52ACBB27663D53547B0B8A08F7E7C33F2E5EA576B2DCD42B0B8806A65A6DD8CCEC78737365C79048B0BDCA0AD552B95E8176DAED56BB32E3E82C5686EFDF80F27F2BA06590816A3099E6E3FEE27ED0F5C7F048B11044FB71F67EA1DC16234F1D3EDAFBD7A63CD8F00C1E25C3EBCB1113FDDFEDA37D0DAA85666FC20102CCED58B3C44D30F02C1E20CF5DAECFACAF5897F1B1F4DE8334A048B22C94929EA576BEB2BD7FC38102CF27E3FF8FF77859E6F40B038AD11139E6E3FAEDD5C35F58E603154AE1E80AA562A9E6F40B03859BD36DB6EE62B10B74CBD23580CBB1FCCDBB7B4BC38BFB430E7478360F1A67C2EE29BE02221048B9C6A3556EB576B39FCC64CBD235814E07EF02553EF0816AFC9E174FB6B316D59A6836091FBE1D54BEB2BD76D438A60F1BDFCEF9967692182C5CBF1CBB57C4EB7BB2B44B078FB7EB0004BF6AA958A0D6710ACB2AB56668A327831C842B00CAF0A530153EF0856D9156B32DB5D2182555E85986E3FCE0960085699EF070BF6F7EF043004ABA4AA9599C99EE5E5AE10C1E2BCDA8DB5FC6C2E3AC2B7DD5C33F52E58944ED2BDF13A5BBB06590816E3B1B430B7BC389FE88B3F7EFAECFEB70FD27DF3A6DE058B7249BA2BDECEFEC39DFD87E9BEBE13C0048B12493DDDDED9DEED0F8E9236CB0960824559A49E6EDFD97F94A59EC66A6DD88654B0288598E9F6ED9423ACCCD4BB605106F5DA6CBAE9F62CCB5EDD093E3978DE3DECA57B213B640916D32FF5DF79677BEFC4FF3CFEF29A7A172CA65ED24D5ABA87BD6EEFC5ABFF9AFEAED0D4BB6031C5B5BAB19174BAFD8D21D5E6F65E7F3048F7724E00132C0CAF2EEE6EE7D76F266C2BE15DA113C0048BA955AFCDAEAF5C4FF7F5FB83C19383E76FFCC39DC47785B74CBD0B165329F974FB4983A9CEF66ED2175D5E9C5F5A98F3C3152CDC0F8E18AC93DAD41F1C257D82344BBCCC08C162025A8DD5A4D3EDFDC16073C8430C9B291F6EC84CBD0B165338BC4AFC5CF82993EBA9EF0A4DBD0B1653A55E9B6D37D3FE499F52A580BB4227800916865763B81F7C29E9F6589913C0048B69927AC7BB331FB64AFD04696669A160311D5A8DD5D46779DDFEF2EBCB47CD5D218245F2FBC1EE61EFEDE7452F16B5CBA8562A369C112C8AAD5A99493DDD7EFBCB6FCEF33F7B72F0FCF1D36706590816131B5E65A3EC2173EFAD9586E365EA5DB028B6F4CB71768FEF2773BAD49F1566B621152C8A6B7DE55AEAE9F6919E620F7820CB0960824571EF07D3FEF5F60783519F624FBD4CA77EB5D66AACFAD10B160553ADCC245FEDBCB5D71F1C8DF47FB9FFED83D40F64B92B142C8A38BC0A986EBFC8FD5DEA07B2DACD3553EF8245C1A49E6EEF1EF62E767F97FA812C832CC1A2609616E6524FB75FF8449CD4C77F65A6DE058BA20DAF6EA67E89BB9778A8EA6EE7BBA4DF9B13C0048BC2A85666DACDB49F943D7EFAEC3CCB7186097920CB204BB0288276632DE9E6A2D9A59F59EFF65E042CD3B10DA96051000107C95C7E88F4C5F956205E6E9065EA5DB0C8B7A585B9E5C5F9A42FD1D9DA1DF5F1AB13BE48E27D93333B640916F91730DD3E96A7D50396E9987A172CF22EF5747B7F3018D794B9A97704ABD43EBCB1917ABA7D8CCFA907EC9BEC0430C122C7C14ABF83DDFD6FC7F908D5FDCDB4832C278009163955AFCDAEAF5C4FFA12DDC3DECEFEA3317EC1BB89B7F4CB423E3345B01859C087629D716F0E13B04C6779717E6961CEAF876051BAFBC1DB091E9EBA9DFE81AC804F4E112C46A955FAE9F6C74F9F9D7F37E4098EDADE66EA5DB028DDF02AD11112DDDE8B9DFD8749BF7353EF82458E044CB767291F9B4AFD5961E60430C12257F783A95F622CCB7186DF15265FA6E30430C1222F02F6AB4BFA547A7F701430C8B2B450B098BC566335F5E6A2FDC120F5693701832C7785824549EE07937F90B7B9BD97FA81AC6AA562C319C16292EAB5D97633F9E75F01C7466421CF3718640916533EBCEA1EF62EB31BF2F9052CD331F52E584C52C0747BEA03235E7972F03CF5BEC9996D48058B49595FB9967ABA3D0BD9B5EA957BE907594E00132C26753F98FC6F2FD1729C6102A6B1EA576BADC6AA5F1EC12254B5321330851C7054C471DDDE8BD4FB26BB2B142C2632BC8AF8AB0B783CEA0D9B116BA1D74CBD0B16A12276BF4AB91CE79444A6DE37D9204BB008357DD3EDAFF4074701CFA99A7A172C22EF0793FFBD052CC7191ECAE40F5238014CB0081233DD1EB01A79989DFD47A997E9644E00132C62C4EC4517F0DCF9296296E9D88654B0482EE01898B0E538C3DC0E799CC2D4BB6091D6D2C2DCF2E2FC74F4E2B462F65E042CD3B143966091FA6FECE674DC919D2960998EA977C122A16A65A6DD4CBEAC6467FF61E4729C61621EAA30F52E58A4D26EACA53ECB2B9BE8E783C7F5074701CB749C002658A41273EA7AFC729C61021E04730298609144BD361B30DD7E7FF341FC729C53EE0A0396E9DC32F52E588CDD47251B5E7DFFFDA45FA6B3BC38BFB430E7174CB018A780A7DB27B81C679898EDE4633E7B45B04A53AB1B1BE5996E3FEEC9C1F380653AA6DE058B820DAFB2492FC719FE5D255F0B6DEA5DB0189B7A6D767DE57AEA5779FCF4D96497E30C1DF7C53C90E50430C1622C62A6DBEFE5727895452DD37102986051A437FF4ECEA6DB8F8BD95ADED242C1E2B25A8DD580E9F6CED66E1E96E30C8F69C4C316EE0A058B4BFF15856C81B299E3E15516B54CA75AA9D87046B0B8B87A6DB6DD5C4B9F8341DE9E177D9BA97704CBF0EAE5FDE05E7E96E39C32060C58A663EA5DB0B8B898C35DF23FBCFA7E90B519B3E18C41966031BA566335E02CAFEE612FE71358AFC43CD7EA0430C122C7F78305A95516B54CA77EB5D66AACFAF5132C46F9B309996ECFF2BA1C67188753205879D40E7993CFED729CC98E07DBCD3553EFB9F5AE4B9043314F5D2F2FCEFFCBCFFFDAD53E7190F58B7FBEE73A186171B6F5956B01D3ED9CC2D4BB6071FEB7777F2D13E60430C1E25CAA9519CF5B7BDB40B08AF277A256F9F841B4366C432A589CC12627DE3C10AC62585A9833DDEECD03C12ACA5FC84D17213F4CBD0B1643552B33EDA6452179BB2B34F52E589CA4DD580BD85C94D17E284E00132C4EE4CCF45C0E7B9D002658BC6569616E7971DE75F04682601580E9F6DC5A5E9C5F5A98731D048B57F71DA6DBBD9D20580561BA3DEF3F2053EF82C52B160FE67E086CEA5DB0C8B22CCBEAB5D9F595EBAE83371504AB00ACFF280427800916DEBABDB5205805AAD58D0DD3EDDE5A102C7F038C59B552B1E18C609597E9766F30085691EE075D846231F52E58E5E568166F338CCAB98493D16AACC66C2EDA3DECFD67FA13DE7332FC89799B7164A16079A34EE52F7FFE77C53ADEF9C2FEFC4FFF38608EA97EB5D66AAC6E869C418D5BC25CA8D766DBCD88A51EDDC35E496A956559677BD75DA16051E0DFF8BB9DEFCA735537B7F7FA8341C00BB59B6BA6DE05AB44C2A6DBEF7FFBA05417F6FE66D0BFAF4196609545D874FBE3A7CFBABD17A5BAB6773BBF9EB2B71C046BC2C2362AF9E2CB6FCA766D9F1C3CEF867C24EA0430C12A856A6526EC69E9B049E85CB91D9569278009D6F40B9BFBE86CEDF6074725BCC29DA8070E3E6C6DD88654B0A65CD81625659B6E7FA5DB7BD1D9F27C83607169EB2BD762A6DBFB8341999F6C0CFB77B74396604DF7FD60D4D30C9B0FCA7C9D3BDBBB310F64997A17ACA91539DD1EF6E97E3EF507479DADA8992C53EF823595C29E6628D5729C530659413F56278009D6540A3BF1FC76F91EBF7ADBE6F65ECC03594E0013AC29B4B430B7BC381F35B8B09140E875B865EA5DB0A64CD859E73BFB0FCBB61C6798B089BCE5C5F9A58539175CB0A644B532D36EAEC6BC56C93F1F3CEEC9C1F3C74F9F4DD91B1282955CBBB1167396577F3028E7729C61EE450DB24CBD0BD6F4089BE3E86CED957339CED0F166D4E3FEA6DE056B4AC44EB71B5EBD31E43C8A5BA6E30430C19A023F69FF41CC0B750F7B361A7F5BD835710298604D83C0CD64D4EAE4BBC298653A99A5858255F85ADDD888996ECF4ABF1CE7B4946FC56D38E36A0B96E1D5D91E3F7D6639CEF04156D0491CD54AC58633825554F5DA6CCCD19E59E0E7F745B4B3FFA81B7594AC4196601555E48C8609ACB3EE97830659A6DE05CBFDE059B5DADAB51CE7ACBBC2B80500EE0A05AB785A8DD5B0E9764F339CA9DB7B11B64CC709608255C0E155D4DB6C7F3028EDF6ED23093BF4AC7EB5D66AACBAE0825518F5DA6CBB19B45023EC33FBA28B5C06E0AE50B00CAF4E16F6997DD1452ED36937D74CBD0B566184CD62740F7B3BFB8F5CF073C7DDD4BB60F1BA566335E62CAFCCD30C23DADCDE0B5BA663EA5DB0DC0FBEC9F6ED23273E6ACACF096082550091D3ED8F9F3EF3F8D5E889FF3AF0ADCB204BB0F2AD1DF879F6178657A37B72F03C72998E6D48052BD76297E3D8AE2FEFF7D1A6DE052BBFD657AEC54DB76FEDDA0DF9A2A18FFBA4C20E5982955F9173169E6EBFB06EEFC5CEFEC398D732F52E583955ADCC84AD76B61BF225FDC33FDD9DCAB731C1E2FCBF9771B3153FFBF43317FC3276F61F053EF5EE0430C1CA9FB0D98A3B5FFDD2D3ED97F7F1A79FC5ECDFE00430C1CA9DA585B998E9F6FB9B0F3EF9FC8E0B7E79FDC1D15FFDFD2F621E7CBF65EA5DB07236BCBA1953AB8FDD0C8ECF9383E73FFDF86F02C659CB8BF34B0B732EF858FCF6EFCC5E4DFD1ABFBBF07B537C05AB95993FFB933FFAC1952BE95EA27BD8FBD9A79FFDE3BDAFFCBE8ED77FFDCFFF7EFDAFFFF6C32B577E7FE9FDA42FF4C32B3F28C9E724FF7DF01F49BFFEBB7E6B2FA9DD584BB4B9687F30D8FEF7879BDB7B1E62487A6FF8C9E7776E7FF94DBBB1DA6EAE253A37A4DD5CFDE4F3198FCE5DDE3BEF2DAFA47E8DF73FF8910B0D65F09BEF7E95F4EB9BC3020A43B000C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B102C9700102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102C88177DE5B5E711500232C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000040B102C00C102102C40B000040B40B000C102102C00C102040B40B000C102102C8031FA3F066DD37AF15644780000000049454E44AE426082,1494270894,1494270894),(2,0x89504E470D0A1A0A0000000D49484452000001900000019008020000000FDDA19B000009CF4944415478DAEDDD317313671EC06159D6CA66916DD931029FE0C6BEC214210569DC90CC908634576526F57D8F6BD2DCF7B836F535A9A0481A1A288E14B8883D608D4131D6DA9617492B2F57F88E61C20DB1A5B0DA85E7A9A061E12FF9C7FBAE765753DF7CF96D09A008CA4600081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520588060010816C01FAB92C131BEFBDB3F0C1A3E06DFFDF3EF5658008205081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520580082050816806001820520580082050816806001081620580082052058806001081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060018205205800820508168060010816205800820520588060010816806001820530591523C8B3B0317BEDF6950FE95F94C4C3A43B3CFD75DCEE954AA53449FBD1E06470D28F12AF3882458E046125082BAF73FC7F73D68F06C9F1B01F0D4E8B0682457E73F666C8FAD1A0D719F4A341DC7E69098660916B33F5EA4CBD7AFAEB34498F76E2B8DDEBB68ED3E495E10816E45739282FACD516D66AA5D2723F1A1C6C758F768E87F189C90816E47DE5D5B8B9D4B8B9D48F06FB8F0FADB9040B8A51AE958DE534593ADA893B9B07CE7309161466B718B77B075BDDC3EDAE990816E45DD8980D1BB3CB9FD5F7FE1DC9D607F83F9311F0E109C2CACAC6F25FFE7AB5D60C4D43B0A018D96ADE6A5CBB7D65A61E98866041313689AB779A8D9B4BE560CA34040B0A60717D7EF5EBE6DB3703215890D31DE2B5DB571A37978C42B0A0384BAD3B7FAA84D3462158500033F5EADAD74D67E2050B0AF2BE0FCAAB779AF3AB35A3102C2886958D65CD122C2852B39C86172C288CC5F5F94F3EAD9B836041312CDFA8DB1B0A1614696FA85982058571F9F325D73A081614E487212837BFB8EC9643C1826208C24AF3D66573102C2886B031BBB83E6F0E8205C5B07CA3EE66C37CF28864FEEBE9BD67EFEF0F9FA957CB41F974FD325D2DBFFEAAC19CFE371E9457362EBDD78120588CE5BD7E2FFCEB3FFCC5CFAF1316041783D347B0E7B05F6163767EB5E6A9F08205A552A9D48F927E94745B71A9542A0753B5E6C5B9AB61AE1EC1BEFC59DDD71D0A16FC569ABC3ADCEE1E6E77CBC1D4C2DADCE2F5F9209CFC3B33082B8BEB0B2F7E8EBC4039DAAD1B01B92A5767F3F0977FED3CBDF7ECBD6E51CF68E9FABCCBB2040B7E47DCEE3DBDF7ACF5533B898793FCF108CA8BEB0B5E0EC182DFD76DC5DB3FB43A9B87935D647921040BCEBA496C3FDC7F7AEF599AA4935A64B9295AB0E07C3BC4AD1F5AFD68609125585000C3F8E4C9DDDD89346BA65EF51407C182736F0F27D5AC85B539F3172C18A559D99FCFAA5D0D0D5FB060C466657CD020ACD8150A168CA21F25ED87FB76858205C5D0D93CCCF86456D8983576C1821165BCC89AA957DDA6235830A2B8DD3BD8CAF4F12F61E382B10B168C68EF51C7AE50B0A01886F149960F75C8F98352050BF22ECB5BA3ADB0040BC6D26DC5595E47EA6A2CC182B11CEDC4991D2BB828588205E32DB2325C61398D25583086B8FD32C31596AF41102C18439ABCCAEC49CA82255830AE7E27A3DB74A6AB7E64040BC6D3CB2A58CE6109168CBDC29AD0D393112C38B7497D45058205E7763238C9EC58AE77172C18734B98188260010816806001820520580082C54725CBC7546579090582C50768BA3A9DD9B15C4221580082C5C7E1C225579F0B161444668FA97297B56041618275327097B560C17832BB2139391E9AB66041016A25588205E3CAF28CBB6009168C65EE6A98D9B186B16009168CAA124E67F99CF5B8DD3373C18291975717333B966B1A040BC6B2787D3EB36365F6DD3C08161FA0B0311B84D97DB3A9FDA060C1E83EF9B49EE5E1E2F64B33172C18717995E91558F170187BB08C60C148AE6C2C6779B8EE4E6CE68205236E06B33C7B5572024BB060E4CDE0F28D4CCF5EA549DA6D596109169CF72D1B4C356F35323EE891FDA060C108B5FAF3572BE520EBF7ADE59560C128B5CAF2469C53493C142CC18202D4AA542A1DFCD235FF9CA81801F937530F56362E4DA456A552E960EBC84B20587026F3ABB5CB9F2F657FDEEA7FB5EABA5E54B0E00CEFCE707A65E3529697B3BF6DEF51C70B2158F02EE5606A717D61E9FAFCA4165696578205675A552DACCD4D3C5596578205EF526B86B566B8B056CBC9DFC7F24AB0E0B75BBFB071A1D60CE7AE86795852BD962669FBE10B2F9060F1B1EFF8AAB5E0C2A5D9E0626576B13AA92B15CEB0198CD2E495D74BB0C8A9F7F130BC373FE09B5DACE66A0DF50E71BBD7D93CF496102CF22BE3E71FE4569AA4BBF77F35879C9E43300278D3F307FBCEB50B1614C0C156F770DB9D838205B9D78F063E19142C28803449777E7CEE9341C18202D4EAC9DD5DA7AE040B0AA0F553BB1F25E620589077BBF7F77C234E51B80E8B8F7A27F8FCC1BE8F05050B0A50AB277777ED04050BF22E8987AD1F9FAB956041DEF5A3C193BBBBAE60102CC8BBCEE661FBE1BE390816E45A9AA4BBF7F77CC3A06041DE755BF1EEFD5F6D03050B722D8987ED07FB1656820579B7F728EA6C1E58580916E4DAC15677EF51C7ED818205528560C118D2243DDA89A54AB020D79278D8797C78B075E45C956041AE97549DCD0377D80816E4BA53DD56EC4A05C1829CEA4783B8DDEBB662CFAE122CC8E34AAAD719C4ED5E3F1AC4ED97CE4F2158E448DCEE25C7C3E478D88F06BD4EDF877D0816135B2BBDFDDB3449FBD1E03455A68460710E8FBFDF360472CE9750008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520580082050816806001081620580082052058806001081620584600081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520588060010816806001820520580082050816402E558C20CFE276EFF1F7DBE6005658806001081620580082052058806001081680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816205800820520588060010816806001820520580082050816806001081620580082052058806001081680600182052058008205081680600108162058008205205880600108162058008205205880600108168060018205205800820508168060019CD7D4375F7E6B0A80151680600182052058008205081680600108162058008205205880600108168060018205205800820508168060010816205800820520588060010816806001820520588060010816C01FE83F4B28D0D880D6535C0000000049454E44AE426082,1494271766,1494271766),(3,0x89504E470D0A1A0A0000000D4948445200000190000001900803000000B761C6FE00000129504C5445C4CDE0C4CDE0C4CDE0C4CDE0C4CDE0C4CDE0CDD5E5E9ECF3ECEFF5E6E9F2E0E5EFD1D8E7C9D2E3CAD2E3C5CEE1FFFFFFEFF1F6D3DAE8DFE4EED2D9E7E2E7F0E3E7F0FEFEFFE7EBF3C6CFE1CBD3E4FCFCFDE1E6EFDDE2EDF4F6F9E6EAF2C5CEE0F1F3F8EDF0F5CDD4E4DEE3EEF6F7FAFBFCFDEEF0F6C7D0E2F9FAFCF0F2F7FDFDFEE5E9F1F2F4F8D0D7E6F8F9FBFEFEFECFD6E6EFF2F7F5F6FADCE1EDDDE3EDD5DCE9CCD4E4E2E6F0D7DDEAD9DFEBF7F9FBFAFBFCC7CFE1F3F5F9DBE1ECF6F8FBF7F8FBFCFDFEE1E5EFD4DAE8D8DEEBFBFBFDE4E8F1D6DCE9D6DCEAC8D1E2CCD3E4EAEEF4E7EBF2D2D9E8D8DEEAEEF1F6CED6E5C9D1E3DADFEBC8D0E2F3F4F8EBEEF5D4DBE9D0D8E7DAE0ECEDF0F6EBEEF4FAFAFCEAEDF4D5DBE9E9EDF4F1F3F7D9DEEBE8EBF3DCE1EC29299E310000000674524E53DEEEFFFEF9F1BFEDC32500000D28494441547801ECD50109C0301004C1CB27EFDF72A12A0E98B1B0C02639D448AA82F0E7981A9C937BA706F766A892F7861AEF6577A8B1DB3675531744100411044104411041104410044110411044100411848F1DBBCA6E1B8AC228BCD6793056FE63902307CD168599999919E63F898205B1E470A29BB639DF14F6DB1682837010C64142E1483416FF212538C85F211181A545A247C593C9642ACD4144C9C021D323A458167FB42A1C44885C1B1CEDD4ACA313B6AE6E0E2240228F678248053C287210014A709543E4A5A42A6850E520C1ABA970C5C82BADC1434F7090C01970990A7974C1AF9B8304ADA7178EBE7E6A141F80DF207190A0C97085A9D1908A26C31C2468233A1C6DA3F44019CBC24F95BB3948C0BAAB70A5E841CF009A68FD14340E320E575521D7C424FCA63AA68983046E060E35490EC5D0E117E9A1E071905216B6AC4C8E90063F759604E020DD7370CC90233E0F9F85483F71101116E15A228B2267E1A32D93101CE4C74CD333196D81CFCAEA3471103186E018AC515D68125ED9489104E1204A15367D8DEA4A53F09A8C93301C641D8E8C1568B50F1E535D1BF4D938482DE7B349B62DD8CA52BD47045EDB3BF4A9384868B7C330F6E03313360CA3AB6379A8028B2ED7C369F0989C25AFFEE5F6AECC3E07799FA45C30CD5EBC4A2FFDA69868A4CB12359868D5B44900282739C81BD50E0EC3732B3A5E6FE6A84689634F8EC212D9948D9E68595D80E38483BC81123A357AF176AA3C8006E604D54DEFA75326BC3A731CE4B5968622F8140AFD76763E7C8147EC73905791DA2F57F0496863D7B8ECC5A3F6121CE465DDBB854988B1452FE1201BA9328469E5202F2896AE20CECA190779562E360991AEE9191CA416EB845085030EF28C9089E0B5ADFCB1606E19EDE339856C1C441AB56D6E7453DD51B40F011B1F9F388C53130EB23362A87085276E420AF59B08DC2C3D8283ECB466E1D7723B05012E931CA4C9EA15BECED42A07F1DAD7F0B5CC24076910EAC4575B98EDE620AE3BFC05221207B1C5F05730931CA4EE54C7DFA172CF41FE30F1D79820E220EB3AFE1E0671905BFC4DA2BFD8B9EFB534B62E8EE3CFB3FE1839E0F013153218615051868E8DD8BB24F68358505E1573FF17F1A6C7D453420E6BEDB53FB7F09D3E7B6D4F7B907205ACDCE69407590033A103D541CA5970136AE90DE23E82A18903AD41165360E9665067901D7035D45418C47F4C80ADB4C2208FE0EC5C5D9034785B5416642701DE0A11554162DBE06E735251905C1EFC0D280A720509C6F504C94282E0504B901864486B09928110F34A820410A2A323C8EB2AA428AA08128218FB771A826420C7996F7E10370B414ECD0FB207492E0E8C0F1287284BC6076940948A0DC2CC860DC24B607890DC0C84099B1DE400D2AC478D0ED284380B460719813833260739AC409E88B941DC00026D181BE4A002896E3D4383B825C8E49819C4BB8450D766066940AA292383C420569ADE734D0A3202B9F23EBD35850D7382C4B6215894DE580486D64C09525B85646F3B1C6E02A81B12C4C942B41C114D00C09F6604C99D41B48088960B00F0C28C2003906D3DE29C64F1D6BA114136600E1382BC4AC01CD7F283245330485C7E90064CF2203EC8028CB2293DC8F5348CB23A293CC8050C33253B481CA6F99FE820271D9826243948EE02C64925050789C340277283D4B661A029B141722598282E36C8288C14F28506713B30932B34C8000C55931964641586DA95196400A67A2532486415A68A8B0C1287B1F26B02834CEEC35CAEC020CF61B017F282F8010C369D1317A406A3A5C5059981D1A623C282B81D986DFD40569079986E4A5690104C57DD9514245A82F152AEA020A750E05250900634189713E4181A144EA50449A6A042B62C24C80894B888CA08D285168F32822C438DB88420FE31D428B40504C94191A0C63F48129A0C7936082F69F6411CE8D2E61EA40C5DA69336082FD9960DC2CBA50DC24B75CF06E165A56683F032D4B2417829DA20CCDCD920BCAC1CDA20BC5CDA20CC0CDB20BC04111B849792CF33481D5AC5790671A15562D706E1653DCA31C81AF43AE618C43B825AFB230C83D038F44A25ED42395E1A7629292FD51ABF20656896E117C45D87664BEC82D00034DB74ED481B2F0D7641DA506DCEE116C44D41B5716E41E80CAA655C6E41E2D0ED8E5B90EB6DA8F61065168436A15B8D5B902E743BE31684C6A05A815D907BA89668730B12816E256E41D62EA1DADC1AB320B404DDC2DC82AC0D41B57B6E4168BE0ACDF2516E412803D522EC829C43B573764168069A8DF30B32390DC5E6F905A15328F6CCE717C43B82621EBF20944C41AF16C32054EB40AD3AC72054AB82131B84CA052835C833089557A1539469108AA4A051C8E31A8446A1D128710DE2A4EC9B3AAB203B50699C6B10670C2AED720DF207544AB94C839C40A71B621A641D3A15990679059D8232AB20F6042911CF20ED6DE8D4E019C47F804E89419E41BA506A885806F14250AACE33480D4ADDFB3C8334A054995806C941A9479F67903FA0D34A8D5806F1B7ED57135641C6A153A9C534C899BDA3B30A721D40A536310D720C959E11D320CD7568F430C835C84B6894AD11D72071953D1CE21AA41E68EC31496C839C409FCC21F10D528436D5FB26F10D120DA04CA54D4F2423B53726DD379ADE1A8320D7502654A68F0EDBC5620A4FCC3E2B0E7B7D0E12872A95BD28BDE3778F66B3F88EA93E07595138709BBBBB0DF6F103C5FE068976A00AB9B5C80C7E66A1BF41E6617D215BEF6F9009585F98A0FE06C9C37A2A31DEDF207F6EC17A6A85FA1B641CD617F6FA1C240DEBA914F5394808D6538B7D0EE2C07A2A447D0EB208EB89B1937E073987F5449CFA1D640FD66795C9BE071985F549A14BFD0E32B80EEB9323EA7B9043589F5472FD0F5286F5D1F612710A62358853102BEF7108720DEBBD4A8D380409C37A6F8A5804D9C117EC0DC49E213CAC1393202F00C01A8B71093203C04AB4894B100056224C5C82F800AC10B1094237B02A754641466D8F6A841805D9B13D5E12A720CFA1DD6B227B863072B6C62BC815740B92C42B480DAAAD4E12B3206568B6EF10B7200E341B2176417267D0AB489C82D8698490C731C84B68B51E258E419C2DE834E711A32076E633D522A641C2D02870886B909100FA4CB7896D107A803A8505621C246D5F40780571C66C0F5641280B5D8E89799030540945B90719B45BCBF00AE287A0C70DF10F42D7B607AF20C994BD5EB10A4253D0E12C2A24C87560CF0F564168000AE4494E90DD00C69B214E41EC9C48884405496E9BDEC397158486ECFD9C579003DB835710FF99BD7FB00A4287FB30559A3805B113D20D921924B70E13151A243408750B26F618274641EC0794F5572438881BC030A541921C8422304B688D6407A1060C527846243D482B0F636CED91FC20E4ACC010993A991084EA1518E1F901991184C209C897BD26322508C5215DE1788DF804B1EF87A52522A382D03D040B7672645A107F00528D85EB445C82D873A4133F20E212C4DE47B2CB44C426882DB21D2146416C91C415991DC48F5745F5B823C38310ED142046F58ECC0F42A715085178491A82D0641622545E928E20547F10D1A34C5A82D0DA1F606FAB4C7A82100D83B98924690AE274C15B98485190BDE331B036FD9AF404714643E02E466A82C4F201F87BA524C84139558508738B0A82AC4DED438E74CDF020F5850988B2BD533739C8D41CC4C9867D5383C4320948B4EE1819A4998658E103F382C4E620D856CCB020AD34843BF24C0AB2948278A5736382F80305182071533723C8CB151822BB6B4010B7087354A7A2D283ECA560944B577490E671158649C50407B95A410FCD9D1C1C38ED763C7DD3095657F7F17715563B9DD54E50416F144EA506F1F77EE7E452F32E36BC73947F2895525F662BBD9599CD5C0EEF84C3E7B1D85584DEF1D02B4B3283E406FEABC92527B6F4D669EC70B2EE44E9FBBC59F4CC9EC8200DF44EF545937E511E3D742E3048BB8A2FED4F64F12FAD8FD0AF2A25D04B5D7941C6A7D1092A2BD9C7C6C652B395CBE53C1AC1BFD26944E917793DEE81ED5D7141C88939F4A526FE85C24D8B7E55AC825EAB3806FCA072F1CFCD76E99735B3E8BD210382F833F8872ACB1EFD32FF16BFC382FC20F43F7C6D28140A65F0238F87D4035DFC16AB49F941BA63F8607F2575B9D0F4A2F496E74517F0AD7C997AC1ABE0F738961F84C21397B7B7A1A3F869ED2F87D74BE3D41BA3F84DF22D3E417AEFE0024FEDC7A9572EF0BB0C9B1C84064BF8A4F2BC2C618FAE01A383D055011FC407A97776F06F3D4CA5F3F89909CFE820D4C05BFB4775167B14548B2D22F27D3FD77E71BF9ECD56F0B55284CC0E42F755E41B9344FF4D90F5A319FC586A89BE34186BC76F6F8F4A78A733741B3F20D3835077384ABDF6886F85C2E1F9984BD4CEE2078E93F47DADFA6E2C16DB3DE1FA7191BFFAE2DDD5DDDDD552B1112F361AC5EEDD5539B9461F248BF89E429858F82288127F66F08D54846C90FE390FF0A509EA271B84DC2FA7816FC906E9B7AB0C3EAABC261BA4FF0EBA25BC93AE930DC282E7165756070EFFDF5E1D903014C54010BCE625FE2D57C58703662D0CB033400404888000111020022220400404883E0111100101222040040488800011102077A39AEEB23BAA6937A3AAF2DEA8A6F74CBD6DEAC94F352540CA40FE26DCF7B62377377A0000000049454E44AE426082,1494271918,1494271918);
/*!40000 ALTER TABLE `file_storageblob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_transaction`
--

DROP TABLE IF EXISTS `file_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_transaction`
--

LOCK TABLES `file_transaction` WRITE;
/*!40000 ALTER TABLE `file_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_transaction_comment`
--

DROP TABLE IF EXISTS `file_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_transaction_comment`
--

LOCK TABLES `file_transaction_comment` WRITE;
/*!40000 ALTER TABLE `file_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_transformedfile`
--

DROP TABLE IF EXISTS `file_transformedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_transformedfile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `originalPHID` varbinary(64) NOT NULL,
  `transform` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `transformedPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `originalPHID` (`originalPHID`,`transform`),
  KEY `transformedPHID` (`transformedPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_transformedfile`
--

LOCK TABLES `file_transformedfile` WRITE;
/*!40000 ALTER TABLE `file_transformedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_transformedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `macro_transaction`
--

DROP TABLE IF EXISTS `macro_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `macro_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `macro_transaction`
--

LOCK TABLES `macro_transaction` WRITE;
/*!40000 ALTER TABLE `macro_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `macro_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `macro_transaction_comment`
--

DROP TABLE IF EXISTS `macro_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `macro_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `macro_transaction_comment`
--

LOCK TABLES `macro_transaction_comment` WRITE;
/*!40000 ALTER TABLE `macro_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `macro_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_flag`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_flag` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_flag`;

--
-- Table structure for table `flag`
--

DROP TABLE IF EXISTS `flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ownerPHID` varbinary(64) NOT NULL,
  `type` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `reasonPHID` varbinary(64) NOT NULL,
  `color` int(10) unsigned NOT NULL,
  `note` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ownerPHID` (`ownerPHID`,`type`,`objectPHID`),
  KEY `objectPHID` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flag`
--

LOCK TABLES `flag` WRITE;
/*!40000 ALTER TABLE `flag` DISABLE KEYS */;
/*!40000 ALTER TABLE `flag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_harbormaster`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_harbormaster` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_harbormaster`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_build`
--

DROP TABLE IF EXISTS `harbormaster_build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_build` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `buildablePHID` varbinary(64) NOT NULL,
  `buildPlanPHID` varbinary(64) NOT NULL,
  `buildStatus` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `buildGeneration` int(10) unsigned NOT NULL DEFAULT '0',
  `planAutoKey` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `buildParameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `initiatorPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_planautokey` (`buildablePHID`,`planAutoKey`),
  KEY `key_buildable` (`buildablePHID`),
  KEY `key_plan` (`buildPlanPHID`),
  KEY `key_status` (`buildStatus`),
  KEY `key_initiator` (`initiatorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_build`
--

LOCK TABLES `harbormaster_build` WRITE;
/*!40000 ALTER TABLE `harbormaster_build` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_build` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildable`
--

DROP TABLE IF EXISTS `harbormaster_buildable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `buildablePHID` varbinary(64) NOT NULL,
  `containerPHID` varbinary(64) DEFAULT NULL,
  `buildableStatus` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isManualBuildable` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_buildable` (`buildablePHID`),
  KEY `key_container` (`containerPHID`),
  KEY `key_manual` (`isManualBuildable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildable`
--

LOCK TABLES `harbormaster_buildable` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildable` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildabletransaction`
--

DROP TABLE IF EXISTS `harbormaster_buildabletransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildabletransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildabletransaction`
--

LOCK TABLES `harbormaster_buildabletransaction` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildabletransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildabletransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildartifact`
--

DROP TABLE IF EXISTS `harbormaster_buildartifact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildartifact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `artifactType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `artifactIndex` binary(12) NOT NULL,
  `artifactKey` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `artifactData` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `buildTargetPHID` varbinary(64) NOT NULL,
  `isReleased` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_artifact` (`artifactType`,`artifactIndex`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_garbagecollect` (`artifactType`,`dateCreated`),
  KEY `key_target` (`buildTargetPHID`,`artifactType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildartifact`
--

LOCK TABLES `harbormaster_buildartifact` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildartifact` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildartifact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildcommand`
--

DROP TABLE IF EXISTS `harbormaster_buildcommand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildcommand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) NOT NULL,
  `targetPHID` varbinary(64) NOT NULL,
  `command` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_target` (`targetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildcommand`
--

LOCK TABLES `harbormaster_buildcommand` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildcommand` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildcommand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildlintmessage`
--

DROP TABLE IF EXISTS `harbormaster_buildlintmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildlintmessage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `buildTargetPHID` varbinary(64) NOT NULL,
  `path` longtext COLLATE utf8mb4_bin NOT NULL,
  `line` int(10) unsigned DEFAULT NULL,
  `characterOffset` int(10) unsigned DEFAULT NULL,
  `code` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `severity` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_target` (`buildTargetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildlintmessage`
--

LOCK TABLES `harbormaster_buildlintmessage` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildlintmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildlintmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildlog`
--

DROP TABLE IF EXISTS `harbormaster_buildlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `logSource` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `logType` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `live` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `buildTargetPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_buildtarget` (`buildTargetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildlog`
--

LOCK TABLES `harbormaster_buildlog` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildlogchunk`
--

DROP TABLE IF EXISTS `harbormaster_buildlogchunk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildlogchunk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logID` int(10) unsigned NOT NULL,
  `encoding` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `size` int(10) unsigned DEFAULT NULL,
  `chunk` longblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_log` (`logID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildlogchunk`
--

LOCK TABLES `harbormaster_buildlogchunk` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildlogchunk` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildlogchunk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildmessage`
--

DROP TABLE IF EXISTS `harbormaster_buildmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildmessage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) NOT NULL,
  `buildTargetPHID` varbinary(64) NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `isConsumed` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_buildtarget` (`buildTargetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildmessage`
--

LOCK TABLES `harbormaster_buildmessage` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildplan`
--

DROP TABLE IF EXISTS `harbormaster_buildplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildplan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `planStatus` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `planAutoKey` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_planautokey` (`planAutoKey`),
  KEY `key_status` (`planStatus`),
  KEY `key_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildplan`
--

LOCK TABLES `harbormaster_buildplan` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildplanname_ngrams`
--

DROP TABLE IF EXISTS `harbormaster_buildplanname_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildplanname_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildplanname_ngrams`
--

LOCK TABLES `harbormaster_buildplanname_ngrams` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildplanname_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildplanname_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildplantransaction`
--

DROP TABLE IF EXISTS `harbormaster_buildplantransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildplantransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildplantransaction`
--

LOCK TABLES `harbormaster_buildplantransaction` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildplantransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildplantransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildstep`
--

DROP TABLE IF EXISTS `harbormaster_buildstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildstep` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `buildPlanPHID` varbinary(64) NOT NULL,
  `className` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `stepAutoKey` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_stepautokey` (`buildPlanPHID`,`stepAutoKey`),
  KEY `key_plan` (`buildPlanPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildstep`
--

LOCK TABLES `harbormaster_buildstep` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildstep` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildstep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildsteptransaction`
--

DROP TABLE IF EXISTS `harbormaster_buildsteptransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildsteptransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildsteptransaction`
--

LOCK TABLES `harbormaster_buildsteptransaction` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildsteptransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildsteptransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildtarget`
--

DROP TABLE IF EXISTS `harbormaster_buildtarget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildtarget` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `buildPHID` varbinary(64) NOT NULL,
  `buildStepPHID` varbinary(64) NOT NULL,
  `className` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `variables` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `targetStatus` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateStarted` int(10) unsigned DEFAULT NULL,
  `dateCompleted` int(10) unsigned DEFAULT NULL,
  `buildGeneration` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_build` (`buildPHID`,`buildStepPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildtarget`
--

LOCK TABLES `harbormaster_buildtarget` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildtarget` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildtarget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildtransaction`
--

DROP TABLE IF EXISTS `harbormaster_buildtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildtransaction`
--

LOCK TABLES `harbormaster_buildtransaction` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_buildunitmessage`
--

DROP TABLE IF EXISTS `harbormaster_buildunitmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_buildunitmessage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `buildTargetPHID` varbinary(64) NOT NULL,
  `engine` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `result` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `duration` double DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_target` (`buildTargetPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_buildunitmessage`
--

LOCK TABLES `harbormaster_buildunitmessage` WRITE;
/*!40000 ALTER TABLE `harbormaster_buildunitmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_buildunitmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_object`
--

DROP TABLE IF EXISTS `harbormaster_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_object` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_object`
--

LOCK TABLES `harbormaster_object` WRITE;
/*!40000 ALTER TABLE `harbormaster_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harbormaster_scratchtable`
--

DROP TABLE IF EXISTS `harbormaster_scratchtable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harbormaster_scratchtable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `bigData` longtext COLLATE utf8mb4_bin,
  `nonmutableData` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harbormaster_scratchtable`
--

LOCK TABLES `harbormaster_scratchtable` WRITE;
/*!40000 ALTER TABLE `harbormaster_scratchtable` DISABLE KEYS */;
/*!40000 ALTER TABLE `harbormaster_scratchtable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lisk_counter`
--

DROP TABLE IF EXISTS `lisk_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lisk_counter` (
  `counterName` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `counterValue` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`counterName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lisk_counter`
--

LOCK TABLES `lisk_counter` WRITE;
/*!40000 ALTER TABLE `lisk_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `lisk_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_herald`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_herald` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_herald`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_action`
--

DROP TABLE IF EXISTS `herald_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ruleID` int(10) unsigned NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `target` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ruleID` (`ruleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_action`
--

LOCK TABLES `herald_action` WRITE;
/*!40000 ALTER TABLE `herald_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_condition`
--

DROP TABLE IF EXISTS `herald_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_condition` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ruleID` int(10) unsigned NOT NULL,
  `fieldName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `fieldCondition` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `value` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ruleID` (`ruleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_condition`
--

LOCK TABLES `herald_condition` WRITE;
/*!40000 ALTER TABLE `herald_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_rule`
--

DROP TABLE IF EXISTS `herald_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `contentType` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `mustMatchAll` tinyint(1) NOT NULL,
  `configVersion` int(10) unsigned NOT NULL DEFAULT '1',
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `repetitionPolicy` int(10) unsigned DEFAULT NULL,
  `ruleType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `isDisabled` int(10) unsigned NOT NULL DEFAULT '0',
  `triggerObjectPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_trigger` (`triggerObjectPHID`),
  KEY `key_author` (`authorPHID`),
  KEY `key_ruletype` (`ruleType`),
  KEY `key_name` (`name`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_rule`
--

LOCK TABLES `herald_rule` WRITE;
/*!40000 ALTER TABLE `herald_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_ruleapplied`
--

DROP TABLE IF EXISTS `herald_ruleapplied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_ruleapplied` (
  `ruleID` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  PRIMARY KEY (`ruleID`,`phid`),
  KEY `phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_ruleapplied`
--

LOCK TABLES `herald_ruleapplied` WRITE;
/*!40000 ALTER TABLE `herald_ruleapplied` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_ruleapplied` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_ruletransaction`
--

DROP TABLE IF EXISTS `herald_ruletransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_ruletransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_ruletransaction`
--

LOCK TABLES `herald_ruletransaction` WRITE;
/*!40000 ALTER TABLE `herald_ruletransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_ruletransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_ruletransaction_comment`
--

DROP TABLE IF EXISTS `herald_ruletransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_ruletransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_ruletransaction_comment`
--

LOCK TABLES `herald_ruletransaction_comment` WRITE;
/*!40000 ALTER TABLE `herald_ruletransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_ruletransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_savedheader`
--

DROP TABLE IF EXISTS `herald_savedheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_savedheader` (
  `phid` varbinary(64) NOT NULL,
  `header` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_savedheader`
--

LOCK TABLES `herald_savedheader` WRITE;
/*!40000 ALTER TABLE `herald_savedheader` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_savedheader` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herald_transcript`
--

DROP TABLE IF EXISTS `herald_transcript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herald_transcript` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `host` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `duration` double NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `dryRun` tinyint(1) NOT NULL,
  `objectTranscript` longblob NOT NULL,
  `ruleTranscripts` longblob NOT NULL,
  `conditionTranscripts` longblob NOT NULL,
  `applyTranscripts` longblob NOT NULL,
  `garbageCollected` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `objectPHID` (`objectPHID`),
  KEY `garbageCollected` (`garbageCollected`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herald_transcript`
--

LOCK TABLES `herald_transcript` WRITE;
/*!40000 ALTER TABLE `herald_transcript` DISABLE KEYS */;
/*!40000 ALTER TABLE `herald_transcript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_maniphest`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_maniphest` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_maniphest`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_customfieldnumericindex`
--

DROP TABLE IF EXISTS `maniphest_customfieldnumericindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_customfieldnumericindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`),
  KEY `key_find` (`indexKey`,`indexValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_customfieldnumericindex`
--

LOCK TABLES `maniphest_customfieldnumericindex` WRITE;
/*!40000 ALTER TABLE `maniphest_customfieldnumericindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_customfieldnumericindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_customfieldstorage`
--

DROP TABLE IF EXISTS `maniphest_customfieldstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_customfieldstorage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_customfieldstorage`
--

LOCK TABLES `maniphest_customfieldstorage` WRITE;
/*!40000 ALTER TABLE `maniphest_customfieldstorage` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_customfieldstorage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_customfieldstringindex`
--

DROP TABLE IF EXISTS `maniphest_customfieldstringindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_customfieldstringindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`(64)),
  KEY `key_find` (`indexKey`,`indexValue`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_customfieldstringindex`
--

LOCK TABLES `maniphest_customfieldstringindex` WRITE;
/*!40000 ALTER TABLE `maniphest_customfieldstringindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_customfieldstringindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_nameindex`
--

DROP TABLE IF EXISTS `maniphest_nameindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_nameindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indexedObjectPHID` varbinary(64) NOT NULL,
  `indexedObjectName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`indexedObjectPHID`),
  KEY `key_name` (`indexedObjectName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_nameindex`
--

LOCK TABLES `maniphest_nameindex` WRITE;
/*!40000 ALTER TABLE `maniphest_nameindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_nameindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_task`
--

DROP TABLE IF EXISTS `maniphest_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_task` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `ownerPHID` varbinary(64) DEFAULT NULL,
  `status` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `priority` int(10) unsigned NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `originalTitle` longtext COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `ownerOrdering` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `originalEmailSource` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `subpriority` double NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `points` double DEFAULT NULL,
  `bridgedObjectPHID` varbinary(64) DEFAULT NULL,
  `subtype` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `key_bridgedobject` (`bridgedObjectPHID`),
  KEY `priority` (`priority`,`status`),
  KEY `status` (`status`),
  KEY `ownerPHID` (`ownerPHID`,`status`),
  KEY `authorPHID` (`authorPHID`,`status`),
  KEY `ownerOrdering` (`ownerOrdering`),
  KEY `priority_2` (`priority`,`subpriority`),
  KEY `key_dateCreated` (`dateCreated`),
  KEY `key_dateModified` (`dateModified`),
  KEY `key_title` (`title`(64)),
  KEY `key_space` (`spacePHID`),
  KEY `key_subtype` (`subtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_task`
--

LOCK TABLES `maniphest_task` WRITE;
/*!40000 ALTER TABLE `maniphest_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_transaction`
--

DROP TABLE IF EXISTS `maniphest_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_transaction`
--

LOCK TABLES `maniphest_transaction` WRITE;
/*!40000 ALTER TABLE `maniphest_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maniphest_transaction_comment`
--

DROP TABLE IF EXISTS `maniphest_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maniphest_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maniphest_transaction_comment`
--

LOCK TABLES `maniphest_transaction_comment` WRITE;
/*!40000 ALTER TABLE `maniphest_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `maniphest_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_meta_data`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_meta_data` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_meta_data`;

--
-- Table structure for table `hoststate`
--

DROP TABLE IF EXISTS `hoststate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hoststate` (
  `stateKey` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `stateValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`stateKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoststate`
--

LOCK TABLES `hoststate` WRITE;
/*!40000 ALTER TABLE `hoststate` DISABLE KEYS */;
/*!40000 ALTER TABLE `hoststate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch_status`
--

DROP TABLE IF EXISTS `patch_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patch_status` (
  `patch` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `applied` int(10) unsigned NOT NULL,
  `duration` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`patch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch_status`
--

LOCK TABLES `patch_status` WRITE;
/*!40000 ALTER TABLE `patch_status` DISABLE KEYS */;
INSERT INTO `patch_status` VALUES ('phabricator:000.project.sql',1466802850,NULL),('phabricator:0000.legacy.sql',1466802850,NULL),('phabricator:001.maniphest_projects.sql',1466802850,NULL),('phabricator:002.oauth.sql',1466802850,NULL),('phabricator:003.more_oauth.sql',1466802851,NULL),('phabricator:004.daemonrepos.sql',1466802851,NULL),('phabricator:005.workers.sql',1466802851,NULL),('phabricator:006.repository.sql',1466802851,NULL),('phabricator:007.daemonlog.sql',1466802851,NULL),('phabricator:008.repoopt.sql',1466802851,NULL),('phabricator:009.repo_summary.sql',1466802851,NULL),('phabricator:010.herald.sql',1466802851,NULL),('phabricator:011.badcommit.sql',1466802851,NULL),('phabricator:012.dropphidtype.sql',1466802851,NULL),('phabricator:013.commitdetail.sql',1466802851,NULL),('phabricator:014.shortcuts.sql',1466802851,NULL),('phabricator:015.preferences.sql',1466802851,NULL),('phabricator:016.userrealnameindex.sql',1466802851,NULL),('phabricator:017.sessionkeys.sql',1466802851,NULL),('phabricator:018.owners.sql',1466802851,NULL),('phabricator:019.arcprojects.sql',1466802851,NULL),('phabricator:020.pathcapital.sql',1466802851,NULL),('phabricator:021.xhpastview.sql',1466802851,NULL),('phabricator:022.differentialcommit.sql',1466802851,NULL),('phabricator:023.dxkeys.sql',1466802851,NULL),('phabricator:024.mlistkeys.sql',1466802851,NULL),('phabricator:025.commentopt.sql',1466802851,NULL),('phabricator:026.diffpropkey.sql',1466802851,NULL),('phabricator:027.metamtakeys.sql',1466802851,NULL),('phabricator:028.systemagent.sql',1466802851,NULL),('phabricator:029.cursors.sql',1466802851,NULL),('phabricator:030.imagemacro.sql',1466802851,NULL),('phabricator:031.workerrace.sql',1466802851,NULL),('phabricator:032.viewtime.sql',1466802851,NULL),('phabricator:033.privtest.sql',1466802851,NULL),('phabricator:034.savedheader.sql',1466802851,NULL),('phabricator:035.proxyimage.sql',1466802851,NULL),('phabricator:036.mailkey.sql',1466802851,NULL),('phabricator:037.setuptest.sql',1466802851,NULL),('phabricator:038.admin.sql',1466802851,NULL),('phabricator:039.userlog.sql',1466802851,NULL),('phabricator:040.transform.sql',1466802851,NULL),('phabricator:041.heraldrepetition.sql',1466802851,NULL),('phabricator:042.commentmetadata.sql',1466802852,NULL),('phabricator:043.pastebin.sql',1466802852,NULL),('phabricator:044.countdown.sql',1466802852,NULL),('phabricator:045.timezone.sql',1466802852,NULL),('phabricator:046.conduittoken.sql',1466802852,NULL),('phabricator:047.projectstatus.sql',1466802852,NULL),('phabricator:048.relationshipkeys.sql',1466802852,NULL),('phabricator:049.projectowner.sql',1466802852,NULL),('phabricator:050.taskdenormal.sql',1466802852,NULL),('phabricator:051.projectfilter.sql',1466802852,NULL),('phabricator:052.pastelanguage.sql',1466802852,NULL),('phabricator:053.feed.sql',1466802852,NULL),('phabricator:054.subscribers.sql',1466802852,NULL),('phabricator:055.add_author_to_files.sql',1466802852,NULL),('phabricator:056.slowvote.sql',1466802852,NULL),('phabricator:057.parsecache.sql',1466802852,NULL),('phabricator:058.missingkeys.sql',1466802852,NULL),('phabricator:059.engines.php',1466802852,NULL),('phabricator:060.phriction.sql',1466802852,NULL),('phabricator:061.phrictioncontent.sql',1466802852,NULL),('phabricator:062.phrictionmenu.sql',1466802852,NULL),('phabricator:063.pasteforks.sql',1466802852,NULL),('phabricator:064.subprojects.sql',1466802852,NULL),('phabricator:065.sshkeys.sql',1466802852,NULL),('phabricator:066.phrictioncontent.sql',1466802852,NULL),('phabricator:067.preferences.sql',1466802852,NULL),('phabricator:068.maniphestauxiliarystorage.sql',1466802852,NULL),('phabricator:069.heraldxscript.sql',1466802852,NULL),('phabricator:070.differentialaux.sql',1466802852,NULL),('phabricator:071.contentsource.sql',1466802852,NULL),('phabricator:072.blamerevert.sql',1466802852,NULL),('phabricator:073.reposymbols.sql',1466802852,NULL),('phabricator:074.affectedpath.sql',1466802852,NULL),('phabricator:075.revisionhash.sql',1466802852,NULL),('phabricator:076.indexedlanguages.sql',1466802852,NULL),('phabricator:077.originalemail.sql',1466802852,NULL),('phabricator:078.nametoken.sql',1466802852,NULL),('phabricator:079.nametokenindex.php',1466802852,NULL),('phabricator:080.filekeys.sql',1466802852,NULL),('phabricator:081.filekeys.php',1466802852,NULL),('phabricator:082.xactionkey.sql',1466802852,NULL),('phabricator:083.dxviewtime.sql',1466802852,NULL),('phabricator:084.pasteauthorkey.sql',1466802852,NULL),('phabricator:085.packagecommitrelationship.sql',1466802852,NULL),('phabricator:086.formeraffil.sql',1466802852,NULL),('phabricator:087.phrictiondelete.sql',1466802853,NULL),('phabricator:088.audit.sql',1466802853,NULL),('phabricator:089.projectwiki.sql',1466802853,NULL),('phabricator:090.forceuniqueprojectnames.php',1466802853,NULL),('phabricator:091.uniqueslugkey.sql',1466802853,NULL),('phabricator:092.dropgithubnotification.sql',1466802853,NULL),('phabricator:093.gitremotes.php',1466802853,NULL),('phabricator:094.phrictioncolumn.sql',1466802853,NULL),('phabricator:095.directory.sql',1466802853,NULL),('phabricator:096.filename.sql',1466802853,NULL),('phabricator:097.heraldruletypes.sql',1466802853,NULL),('phabricator:098.heraldruletypemigration.php',1466802853,NULL),('phabricator:099.drydock.sql',1466802853,NULL),('phabricator:100.projectxaction.sql',1466802853,NULL),('phabricator:101.heraldruleapplied.sql',1466802853,NULL),('phabricator:102.heraldcleanup.php',1466802853,NULL),('phabricator:103.heraldedithistory.sql',1466802853,NULL),('phabricator:104.searchkey.sql',1466802853,NULL),('phabricator:105.mimetype.sql',1466802853,NULL),('phabricator:106.chatlog.sql',1466802853,NULL),('phabricator:107.oauthserver.sql',1466802853,NULL),('phabricator:108.oauthscope.sql',1466802853,NULL),('phabricator:109.oauthclientphidkey.sql',1466802853,NULL),('phabricator:110.commitaudit.sql',1466802853,NULL),('phabricator:111.commitauditmigration.php',1466802853,NULL),('phabricator:112.oauthaccesscoderedirecturi.sql',1466802853,NULL),('phabricator:113.lastreviewer.sql',1466802853,NULL),('phabricator:114.auditrequest.sql',1466802853,NULL),('phabricator:115.prepareutf8.sql',1466802853,NULL),('phabricator:116.utf8-backup-first-expect-wait.sql',1466802855,NULL),('phabricator:117.repositorydescription.php',1466802855,NULL),('phabricator:118.auditinline.sql',1466802855,NULL),('phabricator:119.filehash.sql',1466802855,NULL),('phabricator:120.noop.sql',1466802855,NULL),('phabricator:121.drydocklog.sql',1466802855,NULL),('phabricator:122.flag.sql',1466802855,NULL),('phabricator:123.heraldrulelog.sql',1466802855,NULL),('phabricator:124.subpriority.sql',1466802855,NULL),('phabricator:125.ipv6.sql',1466802855,NULL),('phabricator:126.edges.sql',1466802855,NULL),('phabricator:127.userkeybody.sql',1466802855,NULL),('phabricator:128.phabricatorcom.sql',1466802855,NULL),('phabricator:129.savedquery.sql',1466802855,NULL),('phabricator:130.denormalrevisionquery.sql',1466802855,NULL),('phabricator:131.migraterevisionquery.php',1466802855,NULL),('phabricator:132.phame.sql',1466802855,NULL),('phabricator:133.imagemacro.sql',1466802855,NULL),('phabricator:134.emptysearch.sql',1466802855,NULL),('phabricator:135.datecommitted.sql',1466802855,NULL),('phabricator:136.sex.sql',1466802855,NULL),('phabricator:137.auditmetadata.sql',1466802855,NULL),('phabricator:138.notification.sql',1466802855,NULL),('phabricator:20121209.pholioxactions.sql',1466802856,NULL),('phabricator:20121209.xmacroadd.sql',1466802856,NULL),('phabricator:20121209.xmacromigrate.php',1466802856,NULL),('phabricator:20121209.xmacromigratekey.sql',1466802856,NULL),('phabricator:20121220.generalcache.sql',1466802856,NULL),('phabricator:20121226.config.sql',1466802856,NULL),('phabricator:20130101.confxaction.sql',1466802856,NULL),('phabricator:20130102.metamtareceivedmailmessageidhash.sql',1466802856,NULL),('phabricator:20130103.filemetadata.sql',1466802856,NULL),('phabricator:20130111.conpherence.sql',1466802856,NULL),('phabricator:20130127.altheraldtranscript.sql',1466802856,NULL),('phabricator:20130131.conpherencepics.sql',1466802857,NULL),('phabricator:20130201.revisionunsubscribed.php',1466802856,NULL),('phabricator:20130201.revisionunsubscribed.sql',1466802857,NULL),('phabricator:20130214.chatlogchannel.sql',1466802857,NULL),('phabricator:20130214.chatlogchannelid.sql',1466802857,NULL),('phabricator:20130214.token.sql',1466802857,NULL),('phabricator:20130215.phabricatorfileaddttl.sql',1466802857,NULL),('phabricator:20130217.cachettl.sql',1466802857,NULL),('phabricator:20130218.longdaemon.sql',1466802857,NULL),('phabricator:20130218.updatechannelid.php',1466802857,NULL),('phabricator:20130219.commitsummary.sql',1466802857,NULL),('phabricator:20130219.commitsummarymig.php',1466802857,NULL),('phabricator:20130222.dropchannel.sql',1466802857,NULL),('phabricator:20130226.commitkey.sql',1466802857,NULL),('phabricator:20130304.lintauthor.sql',1466802857,NULL),('phabricator:20130310.xactionmeta.sql',1466802857,NULL),('phabricator:20130317.phrictionedge.sql',1466802857,NULL),('phabricator:20130319.conpherence.sql',1466802857,NULL),('phabricator:20130319.phabricatorfileexplicitupload.sql',1466802857,NULL),('phabricator:20130320.phlux.sql',1466802857,NULL),('phabricator:20130321.token.sql',1466802857,NULL),('phabricator:20130322.phortune.sql',1466802857,NULL),('phabricator:20130323.phortunepayment.sql',1466802857,NULL),('phabricator:20130324.phortuneproduct.sql',1466802857,NULL),('phabricator:20130330.phrequent.sql',1466802857,NULL),('phabricator:20130403.conpherencecache.sql',1466802857,NULL),('phabricator:20130403.conpherencecachemig.php',1466802857,NULL),('phabricator:20130409.commitdrev.php',1466802857,NULL),('phabricator:20130417.externalaccount.sql',1466802857,NULL),('phabricator:20130423.conpherenceindices.sql',1466802857,NULL),('phabricator:20130423.phortunepaymentrevised.sql',1466802857,NULL),('phabricator:20130423.updateexternalaccount.sql',1466802857,NULL),('phabricator:20130426.search_savedquery.sql',1466802857,NULL),('phabricator:20130502.countdownrevamp1.sql',1466802857,NULL),('phabricator:20130502.countdownrevamp2.php',1466802857,NULL),('phabricator:20130502.countdownrevamp3.sql',1466802857,NULL),('phabricator:20130507.releephrqmailkey.sql',1466802857,NULL),('phabricator:20130507.releephrqmailkeypop.php',1466802857,NULL),('phabricator:20130507.releephrqsimplifycols.sql',1466802857,NULL),('phabricator:20130508.releephtransactions.sql',1466802857,NULL),('phabricator:20130508.releephtransactionsmig.php',1466802857,NULL),('phabricator:20130508.search_namedquery.sql',1466802857,NULL),('phabricator:20130513.receviedmailstatus.sql',1466802857,NULL),('phabricator:20130519.diviner.sql',1466802857,NULL),('phabricator:20130521.dropconphimages.sql',1466802857,NULL),('phabricator:20130523.maniphest_owners.sql',1466802857,NULL),('phabricator:20130524.repoxactions.sql',1466802857,NULL),('phabricator:20130529.macroauthor.sql',1466802857,NULL),('phabricator:20130529.macroauthormig.php',1466802857,NULL),('phabricator:20130530.macrodatekey.sql',1466802857,NULL),('phabricator:20130530.pastekeys.sql',1466802857,NULL),('phabricator:20130530.sessionhash.php',1466802857,NULL),('phabricator:20130531.filekeys.sql',1466802857,NULL),('phabricator:20130602.morediviner.sql',1466802858,NULL),('phabricator:20130602.namedqueries.sql',1466802858,NULL),('phabricator:20130606.userxactions.sql',1466802858,NULL),('phabricator:20130607.xaccount.sql',1466802858,NULL),('phabricator:20130611.migrateoauth.php',1466802858,NULL),('phabricator:20130611.nukeldap.php',1466802858,NULL),('phabricator:20130613.authdb.sql',1466802858,NULL),('phabricator:20130619.authconf.php',1466802858,NULL),('phabricator:20130620.diffxactions.sql',1466802858,NULL),('phabricator:20130621.diffcommentphid.sql',1466802858,NULL),('phabricator:20130621.diffcommentphidmig.php',1466802858,NULL),('phabricator:20130621.diffcommentunphid.sql',1466802858,NULL),('phabricator:20130622.doorkeeper.sql',1466802858,NULL),('phabricator:20130628.legalpadv0.sql',1466802858,NULL),('phabricator:20130701.conduitlog.sql',1466802858,NULL),('phabricator:20130703.legalpaddocdenorm.php',1466802858,NULL),('phabricator:20130703.legalpaddocdenorm.sql',1466802858,NULL),('phabricator:20130709.droptimeline.sql',1466802858,NULL),('phabricator:20130709.legalpadsignature.sql',1466802858,NULL),('phabricator:20130711.pholioimageobsolete.php',1466802858,NULL),('phabricator:20130711.pholioimageobsolete.sql',1466802858,NULL),('phabricator:20130711.pholioimageobsolete2.sql',1466802858,NULL),('phabricator:20130711.trimrealnames.php',1466802858,NULL),('phabricator:20130714.votexactions.sql',1466802858,NULL),('phabricator:20130715.votecomments.php',1466802858,NULL),('phabricator:20130715.voteedges.sql',1466802858,NULL),('phabricator:20130716.archivememberlessprojects.php',1466802858,NULL),('phabricator:20130722.pholioreplace.sql',1466802858,NULL),('phabricator:20130723.taskstarttime.sql',1466802858,NULL),('phabricator:20130726.ponderxactions.sql',1466802858,NULL),('phabricator:20130727.ponderquestionstatus.sql',1466802858,NULL),('phabricator:20130728.ponderunique.php',1466802858,NULL),('phabricator:20130728.ponderuniquekey.sql',1466802858,NULL),('phabricator:20130728.ponderxcomment.php',1466802858,NULL),('phabricator:20130731.releephcutpointidentifier.sql',1466802858,NULL),('phabricator:20130731.releephproject.sql',1466802858,NULL),('phabricator:20130731.releephrepoid.sql',1466802858,NULL),('phabricator:20130801.pastexactions.php',1466802858,NULL),('phabricator:20130801.pastexactions.sql',1466802858,NULL),('phabricator:20130802.heraldphid.sql',1466802858,NULL),('phabricator:20130802.heraldphids.php',1466802858,NULL),('phabricator:20130802.heraldphidukey.sql',1466802858,NULL),('phabricator:20130802.heraldxactions.sql',1466802858,NULL),('phabricator:20130805.pasteedges.sql',1466802858,NULL),('phabricator:20130805.pastemailkey.sql',1466802858,NULL),('phabricator:20130805.pastemailkeypop.php',1466802858,NULL),('phabricator:20130814.usercustom.sql',1466802858,NULL),('phabricator:20130820.file-mailkey-populate.php',1466802859,NULL),('phabricator:20130820.filemailkey.sql',1466802859,NULL),('phabricator:20130820.filexactions.sql',1466802859,NULL),('phabricator:20130820.releephxactions.sql',1466802858,NULL),('phabricator:20130826.divinernode.sql',1466802859,NULL),('phabricator:20130912.maniphest.1.touch.sql',1466802859,NULL),('phabricator:20130912.maniphest.2.created.sql',1466802859,NULL),('phabricator:20130912.maniphest.3.nameindex.sql',1466802859,NULL),('phabricator:20130912.maniphest.4.fillindex.php',1466802859,NULL),('phabricator:20130913.maniphest.1.migratesearch.php',1466802859,NULL),('phabricator:20130914.usercustom.sql',1466802859,NULL),('phabricator:20130915.maniphestcustom.sql',1466802859,NULL),('phabricator:20130915.maniphestmigrate.php',1466802859,NULL),('phabricator:20130915.maniphestqdrop.sql',1466802859,NULL),('phabricator:20130919.mfieldconf.php',1466802859,NULL),('phabricator:20130920.repokeyspolicy.sql',1466802859,NULL),('phabricator:20130921.mtransactions.sql',1466802859,NULL),('phabricator:20130921.xmigratemaniphest.php',1466802859,NULL),('phabricator:20130923.mrename.sql',1466802859,NULL),('phabricator:20130924.mdraftkey.sql',1466802859,NULL),('phabricator:20130925.mpolicy.sql',1466802859,NULL),('phabricator:20130925.xpolicy.sql',1466802859,NULL),('phabricator:20130926.dcustom.sql',1466802859,NULL),('phabricator:20130926.dinkeys.sql',1466802859,NULL),('phabricator:20130926.dinline.php',1466802859,NULL),('phabricator:20130927.audiomacro.sql',1466802859,NULL),('phabricator:20130929.filepolicy.sql',1466802859,NULL),('phabricator:20131004.dxedgekey.sql',1466802859,NULL),('phabricator:20131004.dxreviewers.php',1466802859,NULL),('phabricator:20131006.hdisable.sql',1466802859,NULL),('phabricator:20131010.pstorage.sql',1466802859,NULL),('phabricator:20131015.cpolicy.sql',1466802859,NULL),('phabricator:20131020.col1.sql',1466802859,NULL),('phabricator:20131020.harbormaster.sql',1466802859,NULL),('phabricator:20131020.pcustom.sql',1466802859,NULL),('phabricator:20131020.pxaction.sql',1466802859,NULL),('phabricator:20131020.pxactionmig.php',1466802859,NULL),('phabricator:20131025.repopush.sql',1466802859,NULL),('phabricator:20131026.commitstatus.sql',1466802859,NULL),('phabricator:20131030.repostatusmessage.sql',1466802859,NULL),('phabricator:20131031.vcspassword.sql',1466802859,NULL),('phabricator:20131105.buildstep.sql',1466802859,NULL),('phabricator:20131106.diffphid.1.col.sql',1466802859,NULL),('phabricator:20131106.diffphid.2.mig.php',1466802859,NULL),('phabricator:20131106.diffphid.3.key.sql',1466802859,NULL),('phabricator:20131106.nuance-v0.sql',1466802859,NULL),('phabricator:20131107.buildlog.sql',1466802859,NULL),('phabricator:20131112.userverified.1.col.sql',1466802859,NULL),('phabricator:20131112.userverified.2.mig.php',1466802859,NULL),('phabricator:20131118.ownerorder.php',1466802859,NULL),('phabricator:20131119.passphrase.sql',1466802859,NULL),('phabricator:20131120.nuancesourcetype.sql',1466802860,NULL),('phabricator:20131121.passphraseedge.sql',1466802860,NULL),('phabricator:20131121.repocredentials.1.col.sql',1466802860,NULL),('phabricator:20131121.repocredentials.2.mig.php',1466802860,NULL),('phabricator:20131122.repomirror.sql',1466802860,NULL),('phabricator:20131123.drydockblueprintpolicy.sql',1466802860,NULL),('phabricator:20131129.drydockresourceblueprint.sql',1466802860,NULL),('phabricator:20131204.pushlog.sql',1466802860,NULL),('phabricator:20131205.buildsteporder.sql',1466802860,NULL),('phabricator:20131205.buildstepordermig.php',1466802860,NULL),('phabricator:20131205.buildtargets.sql',1466802860,NULL),('phabricator:20131206.phragment.sql',1466802860,NULL),('phabricator:20131206.phragmentnull.sql',1466802860,NULL),('phabricator:20131208.phragmentsnapshot.sql',1466802860,NULL),('phabricator:20131211.phragmentedges.sql',1466802860,NULL),('phabricator:20131217.pushlogphid.1.col.sql',1466802860,NULL),('phabricator:20131217.pushlogphid.2.mig.php',1466802860,NULL),('phabricator:20131217.pushlogphid.3.key.sql',1466802860,NULL),('phabricator:20131219.pxdrop.sql',1466802860,NULL),('phabricator:20131224.harbormanual.sql',1466802860,NULL),('phabricator:20131227.heraldobject.sql',1466802860,NULL),('phabricator:20131231.dropshortcut.sql',1466802860,NULL),('phabricator:20131302.maniphestvalue.sql',1466802857,NULL),('phabricator:20140104.harbormastercmd.sql',1466802860,NULL),('phabricator:20140106.macromailkey.1.sql',1466802860,NULL),('phabricator:20140106.macromailkey.2.php',1466802860,NULL),('phabricator:20140108.ddbpname.1.sql',1466802860,NULL),('phabricator:20140108.ddbpname.2.php',1466802860,NULL),('phabricator:20140109.ddxactions.sql',1466802860,NULL),('phabricator:20140109.projectcolumnsdates.sql',1466802860,NULL),('phabricator:20140113.legalpadsig.1.sql',1466802860,NULL),('phabricator:20140113.legalpadsig.2.php',1466802860,NULL),('phabricator:20140115.auth.1.id.sql',1466802860,NULL),('phabricator:20140115.auth.2.expires.sql',1466802860,NULL),('phabricator:20140115.auth.3.unlimit.php',1466802860,NULL),('phabricator:20140115.legalpadsigkey.sql',1466802860,NULL),('phabricator:20140116.reporefcursor.sql',1466802860,NULL),('phabricator:20140126.diff.1.parentrevisionid.sql',1466802860,NULL),('phabricator:20140126.diff.2.repositoryphid.sql',1466802860,NULL),('phabricator:20140130.dash.1.board.sql',1466802860,NULL),('phabricator:20140130.dash.2.panel.sql',1466802860,NULL),('phabricator:20140130.dash.3.boardxaction.sql',1466802860,NULL),('phabricator:20140130.dash.4.panelxaction.sql',1466802860,NULL),('phabricator:20140130.mail.1.retry.sql',1466802860,NULL),('phabricator:20140130.mail.2.next.sql',1466802860,NULL),('phabricator:20140201.gc.1.mailsent.sql',1466802860,NULL),('phabricator:20140201.gc.2.mailreceived.sql',1466802860,NULL),('phabricator:20140205.cal.1.rename.sql',1466802860,NULL),('phabricator:20140205.cal.2.phid-col.sql',1466802860,NULL),('phabricator:20140205.cal.3.phid-mig.php',1466802860,NULL),('phabricator:20140205.cal.4.phid-key.sql',1466802860,NULL),('phabricator:20140210.herald.rule-condition-mig.php',1466802860,NULL),('phabricator:20140210.projcfield.1.blurb.php',1466802860,NULL),('phabricator:20140210.projcfield.2.piccol.sql',1466802860,NULL),('phabricator:20140210.projcfield.3.picmig.sql',1466802860,NULL),('phabricator:20140210.projcfield.4.memmig.sql',1466802860,NULL),('phabricator:20140210.projcfield.5.dropprofile.sql',1466802860,NULL),('phabricator:20140211.dx.1.nullablechangesetid.sql',1466802860,NULL),('phabricator:20140211.dx.2.migcommenttext.php',1466802860,NULL),('phabricator:20140211.dx.3.migsubscriptions.sql',1466802860,NULL),('phabricator:20140211.dx.999.drop.relationships.sql',1466802860,NULL),('phabricator:20140212.dx.1.armageddon.php',1466802860,NULL),('phabricator:20140214.clean.1.legacycommentid.sql',1466802860,NULL),('phabricator:20140214.clean.2.dropcomment.sql',1466802860,NULL),('phabricator:20140214.clean.3.dropinline.sql',1466802860,NULL),('phabricator:20140218.differentialdraft.sql',1466802860,NULL),('phabricator:20140218.passwords.1.extend.sql',1466802860,NULL),('phabricator:20140218.passwords.2.prefix.sql',1466802860,NULL),('phabricator:20140218.passwords.3.vcsextend.sql',1466802860,NULL),('phabricator:20140218.passwords.4.vcs.php',1466802860,NULL),('phabricator:20140223.bigutf8scratch.sql',1466802860,NULL),('phabricator:20140224.dxclean.1.datecommitted.sql',1466802860,NULL),('phabricator:20140226.dxcustom.1.fielddata.php',1466802860,NULL),('phabricator:20140226.dxcustom.99.drop.sql',1466802860,NULL),('phabricator:20140228.dxcomment.1.sql',1466802860,NULL),('phabricator:20140305.diviner.1.slugcol.sql',1466802861,NULL),('phabricator:20140305.diviner.2.slugkey.sql',1466802861,NULL),('phabricator:20140311.mdroplegacy.sql',1466802861,NULL),('phabricator:20140314.projectcolumn.1.statuscol.sql',1466802861,NULL),('phabricator:20140314.projectcolumn.2.statuskey.sql',1466802861,NULL),('phabricator:20140317.mupdatedkey.sql',1466802861,NULL),('phabricator:20140321.harbor.1.bxaction.sql',1466802861,NULL),('phabricator:20140321.mstatus.1.col.sql',1466802861,NULL),('phabricator:20140321.mstatus.2.mig.php',1466802861,NULL),('phabricator:20140323.harbor.1.renames.php',1466802861,NULL),('phabricator:20140323.harbor.2.message.sql',1466802861,NULL),('phabricator:20140325.push.1.event.sql',1466802861,NULL),('phabricator:20140325.push.2.eventphid.sql',1466802861,NULL),('phabricator:20140325.push.3.groups.php',1466802861,NULL),('phabricator:20140325.push.4.prune.sql',1466802861,NULL),('phabricator:20140326.project.1.colxaction.sql',1466802861,NULL),('phabricator:20140328.releeph.1.productxaction.sql',1466802861,NULL),('phabricator:20140330.flagtext.sql',1466802861,NULL),('phabricator:20140402.actionlog.sql',1466802861,NULL),('phabricator:20140410.accountsecret.1.sql',1466802861,NULL),('phabricator:20140410.accountsecret.2.php',1466802861,NULL),('phabricator:20140416.harbor.1.sql',1466802861,NULL),('phabricator:20140420.rel.1.objectphid.sql',1466802861,NULL),('phabricator:20140420.rel.2.objectmig.php',1466802861,NULL),('phabricator:20140421.slowvotecolumnsisclosed.sql',1466802861,NULL),('phabricator:20140423.session.1.hisec.sql',1466802861,NULL),('phabricator:20140427.mfactor.1.sql',1466802861,NULL),('phabricator:20140430.auth.1.partial.sql',1466802861,NULL),('phabricator:20140430.dash.1.paneltype.sql',1466802861,NULL),('phabricator:20140430.dash.2.edge.sql',1466802861,NULL),('phabricator:20140501.passphraselockcredential.sql',1466802861,NULL),('phabricator:20140501.remove.1.dlog.sql',1466802861,NULL),('phabricator:20140507.smstable.sql',1466802861,NULL),('phabricator:20140509.coverage.1.sql',1466802861,NULL),('phabricator:20140509.dashboardlayoutconfig.sql',1466802861,NULL),('phabricator:20140512.dparents.1.sql',1466802861,NULL),('phabricator:20140514.harbormasterbuildabletransaction.sql',1466802861,NULL),('phabricator:20140514.pholiomockclose.sql',1466802861,NULL),('phabricator:20140515.trust-emails.sql',1466802861,NULL),('phabricator:20140517.dxbinarycache.sql',1466802861,NULL),('phabricator:20140518.dxmorebinarycache.sql',1466802861,NULL),('phabricator:20140519.dashboardinstall.sql',1466802861,NULL),('phabricator:20140520.authtemptoken.sql',1466802861,NULL),('phabricator:20140521.projectslug.1.create.sql',1466802861,NULL),('phabricator:20140521.projectslug.2.mig.php',1466802861,NULL),('phabricator:20140522.projecticon.sql',1466802861,NULL),('phabricator:20140524.auth.mfa.cache.sql',1466802861,NULL),('phabricator:20140525.hunkmodern.sql',1466802861,NULL),('phabricator:20140615.pholioedit.1.sql',1466802861,NULL),('phabricator:20140615.pholioedit.2.sql',1466802861,NULL),('phabricator:20140617.daemon.explicit-argv.sql',1466802861,NULL),('phabricator:20140617.daemonlog.sql',1466802861,NULL),('phabricator:20140624.projcolor.1.sql',1466802861,NULL),('phabricator:20140624.projcolor.2.sql',1466802861,NULL),('phabricator:20140629.dasharchive.1.sql',1466802861,NULL),('phabricator:20140629.legalsig.1.sql',1466802861,NULL),('phabricator:20140629.legalsig.2.php',1466802861,NULL),('phabricator:20140701.legalexemption.1.sql',1466802861,NULL),('phabricator:20140701.legalexemption.2.sql',1466802861,NULL),('phabricator:20140703.legalcorp.1.sql',1466802861,NULL),('phabricator:20140703.legalcorp.2.sql',1466802861,NULL),('phabricator:20140703.legalcorp.3.sql',1466802861,NULL),('phabricator:20140703.legalcorp.4.sql',1466802861,NULL),('phabricator:20140703.legalcorp.5.sql',1466802861,NULL),('phabricator:20140704.harbormasterstep.1.sql',1466802861,NULL),('phabricator:20140704.harbormasterstep.2.sql',1466802861,NULL),('phabricator:20140704.legalpreamble.1.sql',1466802861,NULL),('phabricator:20140706.harbormasterdepend.1.php',1466802861,NULL),('phabricator:20140706.pedge.1.sql',1466802861,NULL),('phabricator:20140711.pnames.1.sql',1466802861,NULL),('phabricator:20140711.pnames.2.php',1466802861,NULL),('phabricator:20140711.workerpriority.sql',1466802862,NULL),('phabricator:20140712.projcoluniq.sql',1466802862,NULL),('phabricator:20140721.phortune.1.cart.sql',1466802862,NULL),('phabricator:20140721.phortune.2.purchase.sql',1466802862,NULL),('phabricator:20140721.phortune.3.charge.sql',1466802862,NULL),('phabricator:20140721.phortune.4.cartstatus.sql',1466802862,NULL),('phabricator:20140721.phortune.5.cstatusdefault.sql',1466802862,NULL),('phabricator:20140721.phortune.6.onetimecharge.sql',1466802862,NULL),('phabricator:20140721.phortune.7.nullmethod.sql',1466802862,NULL),('phabricator:20140722.appname.php',1466802862,NULL),('phabricator:20140722.audit.1.xactions.sql',1466802862,NULL),('phabricator:20140722.audit.2.comments.sql',1466802862,NULL),('phabricator:20140722.audit.3.miginlines.php',1466802862,NULL),('phabricator:20140722.audit.4.migtext.php',1466802862,NULL),('phabricator:20140722.renameauth.php',1466802862,NULL),('phabricator:20140723.apprenamexaction.sql',1466802862,NULL),('phabricator:20140725.audit.1.migxactions.php',1466802862,NULL),('phabricator:20140731.audit.1.subscribers.php',1466802862,NULL),('phabricator:20140731.cancdn.php',1466802862,NULL),('phabricator:20140731.harbormasterstepdesc.sql',1466802862,NULL),('phabricator:20140805.boardcol.1.sql',1466802862,NULL),('phabricator:20140805.boardcol.2.php',1466802862,NULL),('phabricator:20140807.harbormastertargettime.sql',1466802862,NULL),('phabricator:20140808.boardprop.1.sql',1466802862,NULL),('phabricator:20140808.boardprop.2.sql',1466802862,NULL),('phabricator:20140808.boardprop.3.php',1466802862,NULL),('phabricator:20140811.blob.1.sql',1466802862,NULL),('phabricator:20140811.blob.2.sql',1466802862,NULL),('phabricator:20140812.projkey.1.sql',1466802862,NULL),('phabricator:20140812.projkey.2.sql',1466802862,NULL),('phabricator:20140814.passphrasecredentialconduit.sql',1466802862,NULL),('phabricator:20140815.cancdncase.php',1466802862,NULL),('phabricator:20140818.harbormasterindex.1.sql',1466802862,NULL),('phabricator:20140821.harbormasterbuildgen.1.sql',1466802862,NULL),('phabricator:20140822.daemonenvhash.sql',1466802862,NULL),('phabricator:20140902.almanacdevice.1.sql',1466802862,NULL),('phabricator:20140904.macroattach.php',1466802862,NULL),('phabricator:20140911.fund.1.initiative.sql',1466802862,NULL),('phabricator:20140911.fund.2.xaction.sql',1466802862,NULL),('phabricator:20140911.fund.3.edge.sql',1466802862,NULL),('phabricator:20140911.fund.4.backer.sql',1466802862,NULL),('phabricator:20140911.fund.5.backxaction.sql',1466802862,NULL),('phabricator:20140914.betaproto.php',1466802862,NULL),('phabricator:20140917.project.canlock.sql',1466802862,NULL),('phabricator:20140918.schema.1.dropaudit.sql',1466802862,NULL),('phabricator:20140918.schema.2.dropauditinline.sql',1466802862,NULL),('phabricator:20140918.schema.3.wipecache.sql',1466802862,NULL),('phabricator:20140918.schema.4.cachetype.sql',1466802862,NULL),('phabricator:20140918.schema.5.slowvote.sql',1466802862,NULL),('phabricator:20140919.schema.01.calstatus.sql',1466802862,NULL),('phabricator:20140919.schema.02.calname.sql',1466802862,NULL),('phabricator:20140919.schema.03.dropaux.sql',1466802862,NULL),('phabricator:20140919.schema.04.droptaskproj.sql',1466802862,NULL),('phabricator:20140926.schema.01.droprelev.sql',1466802862,NULL),('phabricator:20140926.schema.02.droprelreqev.sql',1466802862,NULL),('phabricator:20140926.schema.03.dropldapinfo.sql',1466802862,NULL),('phabricator:20140926.schema.04.dropoauthinfo.sql',1466802862,NULL),('phabricator:20140926.schema.05.dropprojaffil.sql',1466802862,NULL),('phabricator:20140926.schema.06.dropsubproject.sql',1466802862,NULL),('phabricator:20140926.schema.07.droppondcom.sql',1466802862,NULL),('phabricator:20140927.schema.01.dropsearchq.sql',1466802862,NULL),('phabricator:20140927.schema.02.pholio1.sql',1466802862,NULL),('phabricator:20140927.schema.03.pholio2.sql',1466802862,NULL),('phabricator:20140927.schema.04.pholio3.sql',1466802862,NULL),('phabricator:20140927.schema.05.phragment1.sql',1466802862,NULL),('phabricator:20140927.schema.06.releeph1.sql',1466802862,NULL),('phabricator:20141001.schema.01.version.sql',1466802862,NULL),('phabricator:20141001.schema.02.taskmail.sql',1466802862,NULL),('phabricator:20141002.schema.01.liskcounter.sql',1466802862,NULL),('phabricator:20141002.schema.02.draftnull.sql',1466802862,NULL),('phabricator:20141004.currency.01.sql',1466802862,NULL),('phabricator:20141004.currency.02.sql',1466802862,NULL),('phabricator:20141004.currency.03.sql',1466802862,NULL),('phabricator:20141004.currency.04.sql',1466802862,NULL),('phabricator:20141004.currency.05.sql',1466802862,NULL),('phabricator:20141004.currency.06.sql',1466802862,NULL),('phabricator:20141004.harborliskcounter.sql',1466802862,NULL),('phabricator:20141005.phortuneproduct.sql',1466802862,NULL),('phabricator:20141006.phortunecart.sql',1466802862,NULL),('phabricator:20141006.phortunemerchant.sql',1466802863,NULL),('phabricator:20141006.phortunemerchantx.sql',1466802863,NULL),('phabricator:20141007.fundmerchant.sql',1466802863,NULL),('phabricator:20141007.fundrisks.sql',1466802863,NULL),('phabricator:20141007.fundtotal.sql',1466802863,NULL),('phabricator:20141007.phortunecartmerchant.sql',1466802863,NULL),('phabricator:20141007.phortunecharge.sql',1466802863,NULL),('phabricator:20141007.phortunepayment.sql',1466802863,NULL),('phabricator:20141007.phortuneprovider.sql',1466802863,NULL),('phabricator:20141007.phortuneproviderx.sql',1466802863,NULL),('phabricator:20141008.phortunemerchdesc.sql',1466802863,NULL),('phabricator:20141008.phortuneprovdis.sql',1466802863,NULL),('phabricator:20141008.phortunerefund.sql',1466802863,NULL),('phabricator:20141010.fundmailkey.sql',1466802863,NULL),('phabricator:20141011.phortunemerchedit.sql',1466802863,NULL),('phabricator:20141012.phortunecartxaction.sql',1466802863,NULL),('phabricator:20141013.phortunecartkey.sql',1466802863,NULL),('phabricator:20141016.almanac.device.sql',1466802863,NULL),('phabricator:20141016.almanac.dxaction.sql',1466802863,NULL),('phabricator:20141016.almanac.interface.sql',1466802863,NULL),('phabricator:20141016.almanac.network.sql',1466802863,NULL),('phabricator:20141016.almanac.nxaction.sql',1466802863,NULL),('phabricator:20141016.almanac.service.sql',1466802863,NULL),('phabricator:20141016.almanac.sxaction.sql',1466802863,NULL),('phabricator:20141017.almanac.binding.sql',1466802863,NULL),('phabricator:20141017.almanac.bxaction.sql',1466802863,NULL),('phabricator:20141025.phriction.1.xaction.sql',1466802863,NULL),('phabricator:20141025.phriction.2.xaction.sql',1466802863,NULL),('phabricator:20141025.phriction.mailkey.sql',1466802863,NULL),('phabricator:20141103.almanac.1.delprop.sql',1466802863,NULL),('phabricator:20141103.almanac.2.addprop.sql',1466802863,NULL),('phabricator:20141104.almanac.3.edge.sql',1466802863,NULL),('phabricator:20141105.ssh.1.rename.sql',1466802863,NULL),('phabricator:20141106.dropold.sql',1466802863,NULL),('phabricator:20141106.uniqdrafts.php',1466802863,NULL),('phabricator:20141107.phriction.policy.1.sql',1466802863,NULL),('phabricator:20141107.phriction.policy.2.php',1466802863,NULL),('phabricator:20141107.phriction.popkeys.php',1466802863,NULL),('phabricator:20141107.ssh.1.colname.sql',1466802863,NULL),('phabricator:20141107.ssh.2.keyhash.sql',1466802863,NULL),('phabricator:20141107.ssh.3.keyindex.sql',1466802863,NULL),('phabricator:20141107.ssh.4.keymig.php',1466802863,NULL),('phabricator:20141107.ssh.5.indexnull.sql',1466802863,NULL),('phabricator:20141107.ssh.6.indexkey.sql',1466802863,NULL),('phabricator:20141107.ssh.7.colnull.sql',1466802863,NULL),('phabricator:20141113.auditdupes.php',1466802863,NULL),('phabricator:20141118.diffxaction.sql',1466802863,NULL),('phabricator:20141119.commitpedge.sql',1466802863,NULL),('phabricator:20141119.differential.diff.policy.sql',1466802863,NULL),('phabricator:20141119.sshtrust.sql',1466802863,NULL),('phabricator:20141123.taskpriority.1.sql',1466802863,NULL),('phabricator:20141123.taskpriority.2.sql',1466802863,NULL),('phabricator:20141210.maniphestsubscribersmig.1.sql',1466802863,NULL),('phabricator:20141210.maniphestsubscribersmig.2.sql',1466802863,NULL),('phabricator:20141210.reposervice.sql',1466802863,NULL),('phabricator:20141212.conduittoken.sql',1466802863,NULL),('phabricator:20141215.almanacservicetype.sql',1466802863,NULL),('phabricator:20141217.almanacdevicelock.sql',1466802864,NULL),('phabricator:20141217.almanaclock.sql',1466802864,NULL),('phabricator:20141218.maniphestcctxn.php',1466802864,NULL),('phabricator:20141222.maniphestprojtxn.php',1466802864,NULL),('phabricator:20141223.daemonloguser.sql',1466802864,NULL),('phabricator:20141223.daemonobjectphid.sql',1466802864,NULL),('phabricator:20141230.pasteeditpolicycolumn.sql',1466802864,NULL),('phabricator:20141230.pasteeditpolicyexisting.sql',1466802864,NULL),('phabricator:20150102.policyname.php',1466802864,NULL),('phabricator:20150102.tasksubscriber.sql',1466802864,NULL),('phabricator:20150105.conpsearch.sql',1466802864,NULL),('phabricator:20150114.oauthserver.client.policy.sql',1466802864,NULL),('phabricator:20150115.applicationemails.sql',1466802864,NULL),('phabricator:20150115.trigger.1.sql',1466802864,NULL),('phabricator:20150115.trigger.2.sql',1466802864,NULL),('phabricator:20150116.maniphestapplicationemails.php',1466802864,NULL),('phabricator:20150120.maniphestdefaultauthor.php',1466802864,NULL),('phabricator:20150124.subs.1.sql',1466802864,NULL),('phabricator:20150129.pastefileapplicationemails.php',1466802864,NULL),('phabricator:20150130.phortune.1.subphid.sql',1466802864,NULL),('phabricator:20150130.phortune.2.subkey.sql',1466802864,NULL),('phabricator:20150131.phortune.1.defaultpayment.sql',1466802864,NULL),('phabricator:20150205.authprovider.autologin.sql',1466802864,NULL),('phabricator:20150205.daemonenv.sql',1466802864,NULL),('phabricator:20150209.invite.sql',1466802864,NULL),('phabricator:20150209.oauthclient.trust.sql',1466802864,NULL),('phabricator:20150210.invitephid.sql',1466802864,NULL),('phabricator:20150212.legalpad.session.1.sql',1466802864,NULL),('phabricator:20150212.legalpad.session.2.sql',1466802864,NULL),('phabricator:20150219.scratch.nonmutable.sql',1466802864,NULL),('phabricator:20150223.daemon.1.id.sql',1466802864,NULL),('phabricator:20150223.daemon.2.idlegacy.sql',1466802864,NULL),('phabricator:20150223.daemon.3.idkey.sql',1466802864,NULL),('phabricator:20150312.filechunk.1.sql',1466802864,NULL),('phabricator:20150312.filechunk.2.sql',1466802864,NULL),('phabricator:20150312.filechunk.3.sql',1466802864,NULL),('phabricator:20150317.conpherence.isroom.1.sql',1466802864,NULL),('phabricator:20150317.conpherence.isroom.2.sql',1466802864,NULL),('phabricator:20150317.conpherence.policy.sql',1466802864,NULL),('phabricator:20150410.nukeruleedit.sql',1466802864,NULL),('phabricator:20150420.invoice.1.sql',1466802864,NULL),('phabricator:20150420.invoice.2.sql',1466802864,NULL),('phabricator:20150425.isclosed.sql',1466802864,NULL),('phabricator:20150427.calendar.1.edge.sql',1466802864,NULL),('phabricator:20150427.calendar.1.xaction.sql',1466802864,NULL),('phabricator:20150427.calendar.2.xaction.sql',1466802864,NULL),('phabricator:20150428.calendar.1.iscancelled.sql',1466802864,NULL),('phabricator:20150428.calendar.1.name.sql',1466802864,NULL),('phabricator:20150429.calendar.1.invitee.sql',1466802864,NULL),('phabricator:20150430.calendar.1.policies.sql',1466802864,NULL),('phabricator:20150430.multimeter.1.sql',1466802864,NULL),('phabricator:20150430.multimeter.2.host.sql',1466802864,NULL),('phabricator:20150430.multimeter.3.viewer.sql',1466802864,NULL),('phabricator:20150430.multimeter.4.context.sql',1466802864,NULL),('phabricator:20150430.multimeter.5.label.sql',1466802864,NULL),('phabricator:20150501.calendar.1.reply.sql',1466802864,NULL),('phabricator:20150501.calendar.2.reply.php',1466802864,NULL),('phabricator:20150501.conpherencepics.sql',1466802865,NULL),('phabricator:20150503.repositorysymbols.1.sql',1466802865,NULL),('phabricator:20150503.repositorysymbols.2.php',1466802865,NULL),('phabricator:20150503.repositorysymbols.3.sql',1466802865,NULL),('phabricator:20150504.symbolsproject.1.php',1466802865,NULL),('phabricator:20150504.symbolsproject.2.sql',1466802865,NULL),('phabricator:20150506.calendarunnamedevents.1.php',1466802865,NULL),('phabricator:20150507.calendar.1.isallday.sql',1466802865,NULL),('phabricator:20150513.user.cache.1.sql',1466802865,NULL),('phabricator:20150514.calendar.status.sql',1466802865,NULL),('phabricator:20150514.phame.blog.xaction.sql',1466802865,NULL),('phabricator:20150514.user.cache.2.sql',1466802865,NULL),('phabricator:20150515.phame.post.xaction.sql',1466802865,NULL),('phabricator:20150515.project.mailkey.1.sql',1466802865,NULL),('phabricator:20150515.project.mailkey.2.php',1466802865,NULL),('phabricator:20150519.calendar.calendaricon.sql',1466802865,NULL),('phabricator:20150521.releephrepository.sql',1466802865,NULL),('phabricator:20150525.diff.hidden.1.sql',1466802865,NULL),('phabricator:20150526.owners.mailkey.1.sql',1466802865,NULL),('phabricator:20150526.owners.mailkey.2.php',1466802865,NULL),('phabricator:20150526.owners.xaction.sql',1466802865,NULL),('phabricator:20150527.calendar.recurringevents.sql',1466802865,NULL),('phabricator:20150601.spaces.1.namespace.sql',1466802865,NULL),('phabricator:20150601.spaces.2.xaction.sql',1466802865,NULL),('phabricator:20150602.mlist.1.sql',1466802865,NULL),('phabricator:20150602.mlist.2.php',1466802865,NULL),('phabricator:20150604.spaces.1.sql',1466802865,NULL),('phabricator:20150605.diviner.edges.sql',1466802865,NULL),('phabricator:20150605.diviner.editPolicy.sql',1466802865,NULL),('phabricator:20150605.diviner.xaction.sql',1466802865,NULL),('phabricator:20150606.mlist.1.php',1466802865,NULL),('phabricator:20150609.inline.sql',1466802865,NULL),('phabricator:20150609.spaces.1.pholio.sql',1466802865,NULL),('phabricator:20150609.spaces.2.maniphest.sql',1466802865,NULL),('phabricator:20150610.spaces.1.desc.sql',1466802865,NULL),('phabricator:20150610.spaces.2.edge.sql',1466802865,NULL),('phabricator:20150610.spaces.3.archive.sql',1466802865,NULL),('phabricator:20150611.spaces.1.mailxaction.sql',1466802865,NULL),('phabricator:20150611.spaces.2.appmail.sql',1466802865,NULL),('phabricator:20150616.divinerrepository.sql',1466802865,NULL),('phabricator:20150617.harbor.1.lint.sql',1466802865,NULL),('phabricator:20150617.harbor.2.unit.sql',1466802865,NULL),('phabricator:20150618.harbor.1.planauto.sql',1466802866,NULL),('phabricator:20150618.harbor.2.stepauto.sql',1466802866,NULL),('phabricator:20150618.harbor.3.buildauto.sql',1466802866,NULL),('phabricator:20150619.conpherencerooms.1.sql',1466802866,NULL),('phabricator:20150619.conpherencerooms.2.sql',1466802866,NULL),('phabricator:20150619.conpherencerooms.3.sql',1466802866,NULL),('phabricator:20150621.phrase.1.sql',1466802866,NULL),('phabricator:20150621.phrase.2.sql',1466802866,NULL),('phabricator:20150622.bulk.1.job.sql',1466802866,NULL),('phabricator:20150622.bulk.2.task.sql',1466802866,NULL),('phabricator:20150622.bulk.3.xaction.sql',1466802866,NULL),('phabricator:20150622.bulk.4.edge.sql',1466802866,NULL),('phabricator:20150622.metamta.1.phid-col.sql',1466802866,NULL),('phabricator:20150622.metamta.2.phid-mig.php',1466802866,NULL),('phabricator:20150622.metamta.3.phid-key.sql',1466802866,NULL),('phabricator:20150622.metamta.4.actor-phid-col.sql',1466802866,NULL),('phabricator:20150622.metamta.5.actor-phid-mig.php',1466802866,NULL),('phabricator:20150622.metamta.6.actor-phid-key.sql',1466802866,NULL),('phabricator:20150624.spaces.1.repo.sql',1466802866,NULL),('phabricator:20150626.spaces.1.calendar.sql',1466802866,NULL),('phabricator:20150630.herald.1.sql',1466802866,NULL),('phabricator:20150630.herald.2.sql',1466802866,NULL),('phabricator:20150701.herald.1.sql',1466802866,NULL),('phabricator:20150701.herald.2.sql',1466802866,NULL),('phabricator:20150702.spaces.1.slowvote.sql',1466802866,NULL),('phabricator:20150706.herald.1.sql',1466802866,NULL),('phabricator:20150707.herald.1.sql',1466802866,NULL),('phabricator:20150708.arcanistproject.sql',1466802866,NULL),('phabricator:20150708.herald.1.sql',1466802866,NULL),('phabricator:20150708.herald.2.sql',1466802866,NULL),('phabricator:20150708.herald.3.sql',1466802866,NULL),('phabricator:20150712.badges.1.sql',1466802866,NULL),('phabricator:20150714.spaces.countdown.1.sql',1466802866,NULL),('phabricator:20150717.herald.1.sql',1466802866,NULL),('phabricator:20150719.countdown.1.sql',1466802866,NULL),('phabricator:20150719.countdown.2.sql',1466802866,NULL),('phabricator:20150719.countdown.3.sql',1466802866,NULL),('phabricator:20150721.phurl.1.url.sql',1466802866,NULL),('phabricator:20150721.phurl.2.xaction.sql',1466802866,NULL),('phabricator:20150721.phurl.3.xactioncomment.sql',1466802866,NULL),('phabricator:20150721.phurl.4.url.sql',1466802866,NULL),('phabricator:20150721.phurl.5.edge.sql',1466802866,NULL),('phabricator:20150721.phurl.6.alias.sql',1466802866,NULL),('phabricator:20150721.phurl.7.authorphid.sql',1466802866,NULL),('phabricator:20150722.dashboard.1.sql',1466802866,NULL),('phabricator:20150722.dashboard.2.sql',1466802866,NULL),('phabricator:20150723.countdown.1.sql',1466802866,NULL),('phabricator:20150724.badges.comments.1.sql',1466802866,NULL),('phabricator:20150724.countdown.comments.1.sql',1466802866,NULL),('phabricator:20150725.badges.mailkey.1.sql',1466802866,NULL),('phabricator:20150725.badges.mailkey.2.php',1466802866,NULL),('phabricator:20150725.badges.viewpolicy.3.sql',1466802866,NULL),('phabricator:20150725.countdown.mailkey.1.sql',1466802866,NULL),('phabricator:20150725.countdown.mailkey.2.php',1466802866,NULL),('phabricator:20150725.slowvote.mailkey.1.sql',1466802866,NULL),('phabricator:20150725.slowvote.mailkey.2.php',1466802866,NULL),('phabricator:20150727.heraldaction.1.sql',1466802866,NULL),('phabricator:20150730.herald.1.sql',1466802866,NULL),('phabricator:20150730.herald.2.sql',1466802866,NULL),('phabricator:20150730.herald.3.sql',1466802866,NULL),('phabricator:20150730.herald.4.sql',1466802866,NULL),('phabricator:20150730.herald.5.sql',1466802866,NULL),('phabricator:20150730.herald.6.sql',1466802866,NULL),('phabricator:20150730.herald.7.sql',1466802866,NULL),('phabricator:20150803.herald.1.sql',1466802866,NULL),('phabricator:20150803.herald.2.sql',1466802866,NULL),('phabricator:20150804.ponder.answer.mailkey.1.sql',1466802866,NULL),('phabricator:20150804.ponder.answer.mailkey.2.php',1466802866,NULL),('phabricator:20150804.ponder.question.1.sql',1466802867,NULL),('phabricator:20150804.ponder.question.2.sql',1466802867,NULL),('phabricator:20150804.ponder.question.3.sql',1466802867,NULL),('phabricator:20150804.ponder.spaces.4.sql',1466802867,NULL),('phabricator:20150805.paste.status.1.sql',1466802867,NULL),('phabricator:20150805.paste.status.2.sql',1466802867,NULL),('phabricator:20150806.ponder.answer.1.sql',1466802867,NULL),('phabricator:20150806.ponder.editpolicy.2.sql',1466802867,NULL),('phabricator:20150806.ponder.status.1.sql',1466802867,NULL),('phabricator:20150806.ponder.status.2.sql',1466802867,NULL),('phabricator:20150806.ponder.status.3.sql',1466802867,NULL),('phabricator:20150808.ponder.vote.1.sql',1466802867,NULL),('phabricator:20150808.ponder.vote.2.sql',1466802867,NULL),('phabricator:20150812.ponder.answer.1.sql',1466802867,NULL),('phabricator:20150812.ponder.answer.2.sql',1466802867,NULL),('phabricator:20150814.harbormater.artifact.phid.sql',1466802867,NULL),('phabricator:20150815.owners.status.1.sql',1466802867,NULL),('phabricator:20150815.owners.status.2.sql',1466802867,NULL),('phabricator:20150823.nuance.queue.1.sql',1466802867,NULL),('phabricator:20150823.nuance.queue.2.sql',1466802867,NULL),('phabricator:20150823.nuance.queue.3.sql',1466802867,NULL),('phabricator:20150823.nuance.queue.4.sql',1466802867,NULL),('phabricator:20150828.ponder.wiki.1.sql',1466802867,NULL),('phabricator:20150829.ponder.dupe.1.sql',1466802867,NULL),('phabricator:20150904.herald.1.sql',1466802867,NULL),('phabricator:20150906.mailinglist.sql',1466802867,NULL),('phabricator:20150910.owners.custom.1.sql',1466802867,NULL),('phabricator:20150916.drydock.slotlocks.1.sql',1466802867,NULL),('phabricator:20150922.drydock.commands.1.sql',1466802867,NULL),('phabricator:20150923.drydock.resourceid.1.sql',1466802867,NULL),('phabricator:20150923.drydock.resourceid.2.sql',1466802867,NULL),('phabricator:20150923.drydock.resourceid.3.sql',1466802867,NULL),('phabricator:20150923.drydock.taskid.1.sql',1466802867,NULL),('phabricator:20150924.drydock.disable.1.sql',1466802867,NULL),('phabricator:20150924.drydock.status.1.sql',1466802867,NULL),('phabricator:20150928.drydock.rexpire.1.sql',1466802867,NULL),('phabricator:20150930.drydock.log.1.sql',1466802867,NULL),('phabricator:20151001.drydock.rname.1.sql',1466802867,NULL),('phabricator:20151002.dashboard.status.1.sql',1466802867,NULL),('phabricator:20151002.harbormaster.bparam.1.sql',1466802867,NULL),('phabricator:20151009.drydock.auth.1.sql',1466802867,NULL),('phabricator:20151010.drydock.auth.2.sql',1466802867,NULL),('phabricator:20151013.drydock.op.1.sql',1466802867,NULL),('phabricator:20151023.harborpolicy.1.sql',1466802867,NULL),('phabricator:20151023.harborpolicy.2.php',1466802867,NULL),('phabricator:20151023.patchduration.sql',1466802867,16373),('phabricator:20151030.harbormaster.initiator.sql',1466802867,21600),('phabricator:20151106.editengine.1.table.sql',1466802867,9430),('phabricator:20151106.editengine.2.xactions.sql',1466802867,7174),('phabricator:20151106.phame.post.mailkey.1.sql',1466802867,19922),('phabricator:20151106.phame.post.mailkey.2.php',1466802867,1343),('phabricator:20151107.phame.blog.mailkey.1.sql',1466802867,17107),('phabricator:20151107.phame.blog.mailkey.2.php',1466802867,1049),('phabricator:20151108.phame.blog.joinpolicy.sql',1466802867,16781),('phabricator:20151108.xhpast.stderr.sql',1466802867,23962),('phabricator:20151109.phame.post.comments.1.sql',1466802867,8796),('phabricator:20151109.repository.coverage.1.sql',1466802867,1058),('phabricator:20151109.xhpast.db.1.sql',1466802867,1587),('phabricator:20151109.xhpast.db.2.sql',1466802867,561),('phabricator:20151110.daemonenvhash.sql',1466802867,36237),('phabricator:20151111.phame.blog.archive.1.sql',1466802867,16500),('phabricator:20151111.phame.blog.archive.2.sql',1466802867,479),('phabricator:20151112.herald.edge.sql',1466802867,14091),('phabricator:20151116.owners.edge.sql',1466802867,11769),('phabricator:20151128.phame.blog.picture.1.sql',1466802867,15526),('phabricator:20151130.phurl.mailkey.1.sql',1466802868,10082),('phabricator:20151130.phurl.mailkey.2.php',1466802868,1190),('phabricator:20151202.versioneddraft.1.sql',1466802868,8290),('phabricator:20151207.editengine.1.sql',1466802868,76502),('phabricator:20151210.land.1.refphid.sql',1466802868,15998),('phabricator:20151210.land.2.refphid.php',1466802868,751),('phabricator:20151215.phame.1.autotitle.sql',1466802868,20074),('phabricator:20151218.key.1.keyphid.sql',1466802868,15772),('phabricator:20151218.key.2.keyphid.php',1466802868,454),('phabricator:20151219.proj.01.prislug.sql',1466802868,22082),('phabricator:20151219.proj.02.prislugkey.sql',1466802868,15591),('phabricator:20151219.proj.03.copyslug.sql',1466802868,581),('phabricator:20151219.proj.04.dropslugkey.sql',1466802868,8692),('phabricator:20151219.proj.05.dropslug.sql',1466802868,21494),('phabricator:20151219.proj.06.defaultpolicy.php',1466802868,1250),('phabricator:20151219.proj.07.viewnull.sql',1466802868,14942),('phabricator:20151219.proj.08.editnull.sql',1466802868,11831),('phabricator:20151219.proj.09.joinnull.sql',1466802868,10583),('phabricator:20151219.proj.10.subcolumns.sql',1466802868,201986),('phabricator:20151219.proj.11.subprojectphids.sql',1466802868,23604),('phabricator:20151221.search.1.version.sql',1466802868,9540),('phabricator:20151221.search.2.ownersngrams.sql',1466802868,7522),('phabricator:20151221.search.3.reindex.php',1466802868,415),('phabricator:20151223.proj.01.paths.sql',1466802868,22569),('phabricator:20151223.proj.02.depths.sql',1466802868,25408),('phabricator:20151223.proj.03.pathkey.sql',1466802868,13193),('phabricator:20151223.proj.04.keycol.sql',1466802868,27276),('phabricator:20151223.proj.05.updatekeys.php',1466802868,451),('phabricator:20151223.proj.06.uniq.sql',1466802868,11754),('phabricator:20151226.reop.1.sql',1466802868,19139),('phabricator:20151227.proj.01.materialize.sql',1466802868,535),('phabricator:20151231.proj.01.icon.php',1466802868,1991),('phabricator:20160102.badges.award.sql',1466802868,10113),('phabricator:20160110.repo.01.slug.sql',1466802868,32438),('phabricator:20160110.repo.02.slug.php',1466802868,459),('phabricator:20160111.repo.01.slugx.sql',1466802868,627),('phabricator:20160112.repo.01.uri.sql',1466802868,8500),('phabricator:20160112.repo.02.uri.index.php',1466802868,64),('phabricator:20160113.propanel.1.storage.sql',1466802868,6858),('phabricator:20160113.propanel.2.xaction.sql',1466802868,7710),('phabricator:20160119.project.1.silence.sql',1466802868,579),('phabricator:20160122.project.1.boarddefault.php',1466802868,904),('phabricator:20160124.people.1.icon.sql',1466802868,12728),('phabricator:20160124.people.2.icondefault.sql',1466802868,477),('phabricator:20160128.repo.1.pull.sql',1466802868,9886),('phabricator:20160201.revision.properties.1.sql',1494270725,49899),('phabricator:20160201.revision.properties.2.sql',1494270725,1657),('phabricator:20160202.board.1.proxy.sql',1466802868,17041),('phabricator:20160202.ipv6.1.sql',1466802868,22960),('phabricator:20160202.ipv6.2.php',1466802868,1991),('phabricator:20160206.cover.1.sql',1466802868,29137),('phabricator:20160208.task.1.sql',1466802868,32546),('phabricator:20160208.task.2.sql',1466802868,33818),('phabricator:20160208.task.3.sql',1466802868,34881),('phabricator:20160212.proj.1.sql',1466802868,28365),('phabricator:20160212.proj.2.sql',1466802868,504),('phabricator:20160215.owners.policy.1.sql',1466802868,18780),('phabricator:20160215.owners.policy.2.sql',1466802868,17029),('phabricator:20160215.owners.policy.3.sql',1466802868,432),('phabricator:20160215.owners.policy.4.sql',1466802868,361),('phabricator:20160218.callsigns.1.sql',1466802869,12331),('phabricator:20160221.almanac.1.devicen.sql',1466802869,9432),('phabricator:20160221.almanac.2.devicei.php',1466802869,1470),('phabricator:20160221.almanac.3.servicen.sql',1466802869,7845),('phabricator:20160221.almanac.4.servicei.php',1466802869,916),('phabricator:20160221.almanac.5.networkn.sql',1466802869,8044),('phabricator:20160221.almanac.6.networki.php',1466802869,903),('phabricator:20160221.almanac.7.namespacen.sql',1466802869,7463),('phabricator:20160221.almanac.8.namespace.sql',1466802869,7462),('phabricator:20160221.almanac.9.namespacex.sql',1466802869,7400),('phabricator:20160222.almanac.1.properties.php',1466802869,1750),('phabricator:20160223.almanac.1.bound.sql',1466802869,16093),('phabricator:20160223.almanac.2.lockbind.sql',1466802869,447),('phabricator:20160223.almanac.3.devicelock.sql',1466802869,19320),('phabricator:20160223.almanac.4.servicelock.sql',1466802869,23933),('phabricator:20160223.paste.fileedges.php',1466802869,654),('phabricator:20160225.almanac.1.disablebinding.sql',1466802869,24011),('phabricator:20160225.almanac.2.stype.sql',1466802869,7243),('phabricator:20160225.almanac.3.stype.php',1466802869,464),('phabricator:20160227.harbormaster.1.plann.sql',1466802869,7447),('phabricator:20160227.harbormaster.2.plani.php',1466802869,367),('phabricator:20160303.drydock.1.bluen.sql',1466802869,6561),('phabricator:20160303.drydock.2.bluei.php',1466802869,323),('phabricator:20160303.drydock.3.edge.sql',1466802869,12513),('phabricator:20160308.nuance.01.disabled.sql',1466802869,14286),('phabricator:20160308.nuance.02.cursordata.sql',1466802869,14221),('phabricator:20160308.nuance.03.sourcen.sql',1466802869,7121),('phabricator:20160308.nuance.04.sourcei.php',1466802869,1214),('phabricator:20160308.nuance.05.sourcename.sql',1466802869,10244),('phabricator:20160308.nuance.06.label.sql',1466802869,18965),('phabricator:20160308.nuance.07.itemtype.sql',1466802869,25794),('phabricator:20160308.nuance.08.itemkey.sql',1466802869,21958),('phabricator:20160308.nuance.09.itemcontainer.sql',1466802869,22612),('phabricator:20160308.nuance.10.itemkeyu.sql',1466802869,552),('phabricator:20160308.nuance.11.requestor.sql',1466802869,14556),('phabricator:20160308.nuance.12.queue.sql',1466802869,19884),('phabricator:20160316.lfs.01.token.resource.sql',1466802869,13284),('phabricator:20160316.lfs.02.token.user.sql',1466802869,15555),('phabricator:20160316.lfs.03.token.properties.sql',1466802869,16563),('phabricator:20160316.lfs.04.token.default.sql',1466802869,581),('phabricator:20160317.lfs.01.ref.sql',1466802869,8120),('phabricator:20160321.nuance.01.taskbridge.sql',1466802869,28702),('phabricator:20160322.nuance.01.itemcommand.sql',1466802869,11727),('phabricator:20160323.badgemigrate.sql',1466802869,873),('phabricator:20160329.nuance.01.requestor.sql',1466802869,1313),('phabricator:20160329.nuance.02.requestorsource.sql',1466802869,1704),('phabricator:20160329.nuance.03.requestorxaction.sql',1466802869,1686),('phabricator:20160329.nuance.04.requestorcomment.sql',1466802869,1374),('phabricator:20160330.badges.migratequality.sql',1466802869,9959),('phabricator:20160330.badges.qualityxaction.mig.sql',1466802869,2022),('phabricator:20160331.fund.comments.1.sql',1466802869,6337),('phabricator:20160404.oauth.1.xaction.sql',1466802869,6577),('phabricator:20160405.oauth.2.disable.sql',1466802869,15800),('phabricator:20160406.badges.ngrams.php',1466802869,678),('phabricator:20160406.badges.ngrams.sql',1466802869,8117),('phabricator:20160406.columns.1.php',1466802869,543),('phabricator:20160411.repo.1.version.sql',1466802869,7060),('phabricator:20160418.repouri.1.sql',1466802869,6372),('phabricator:20160418.repouri.2.sql',1466802869,13856),('phabricator:20160418.repoversion.1.sql',1466802869,15751),('phabricator:20160419.pushlog.1.sql',1466802869,25118),('phabricator:20160424.locks.1.sql',1466802869,15525),('phabricator:20160426.searchedge.sql',1466802869,15875),('phabricator:20160428.repo.1.urixaction.sql',1466802869,7234),('phabricator:20160503.repo.01.lpath.sql',1466802869,23546),('phabricator:20160503.repo.02.lpathkey.sql',1466802869,12838),('phabricator:20160503.repo.03.lpathmigrate.php',1466802869,473),('phabricator:20160503.repo.04.mirrormigrate.php',1466802869,540),('phabricator:20160503.repo.05.urimigrate.php',1466802869,355),('phabricator:20160510.repo.01.uriindex.php',1466802869,4261),('phabricator:20160513.owners.01.autoreview.sql',1466802869,17537),('phabricator:20160513.owners.02.autoreviewnone.sql',1466802869,514),('phabricator:20160516.owners.01.dominion.sql',1466802869,16006),('phabricator:20160516.owners.02.dominionstrong.sql',1466802869,563),('phabricator:20160517.oauth.01.edge.sql',1466802869,13998),('phabricator:20160518.ssh.01.activecol.sql',1466802869,15647),('phabricator:20160518.ssh.02.activeval.sql',1466802869,485),('phabricator:20160518.ssh.03.activekey.sql',1466802869,10420),('phabricator:20160519.ssh.01.xaction.sql',1466802869,9024),('phabricator:20160531.pref.01.xaction.sql',1466802869,7837),('phabricator:20160531.pref.02.datecreatecol.sql',1466802869,11848),('phabricator:20160531.pref.03.datemodcol.sql',1466802869,13814),('phabricator:20160531.pref.04.datecreateval.sql',1466802869,429),('phabricator:20160531.pref.05.datemodval.sql',1466802869,305),('phabricator:20160531.pref.06.phidcol.sql',1466802869,12896),('phabricator:20160531.pref.07.phidval.php',1466802869,679),('phabricator:20160601.user.01.cache.sql',1466802869,9294),('phabricator:20160601.user.02.copyprefs.php',1466802869,1552),('phabricator:20160601.user.03.removetime.sql',1466802869,18764),('phabricator:20160601.user.04.removetranslation.sql',1466802869,20404),('phabricator:20160601.user.05.removesex.sql',1466802869,23968),('phabricator:20160603.user.01.removedcenabled.sql',1466802869,25907),('phabricator:20160603.user.02.removedctab.sql',1466802869,20792),('phabricator:20160603.user.03.removedcvisible.sql',1466802869,22140),('phabricator:20160604.user.01.stringmailprefs.php',1466802869,683),('phabricator:20160604.user.02.removeimagecache.sql',1466802870,22776),('phabricator:20160605.user.01.prefnulluser.sql',1466802870,12931),('phabricator:20160605.user.02.prefbuiltin.sql',1466802870,13598),('phabricator:20160605.user.03.builtinunique.sql',1466802870,12068),('phabricator:20160616.phame.blog.header.1.sql',1466802870,21493),('phabricator:20160616.repo.01.oldref.sql',1466802870,9001),('phabricator:20160617.harbormaster.01.arelease.sql',1466802870,16927),('phabricator:20160618.phame.blog.subtitle.sql',1466802870,28832),('phabricator:20160620.phame.blog.parentdomain.2.sql',1466802870,32443),('phabricator:20160620.phame.blog.parentsite.1.sql',1466802870,35279),('phabricator:20160623.phame.blog.fulldomain.1.sql',1466802870,37279),('phabricator:20160623.phame.blog.fulldomain.2.sql',1466802870,500),('phabricator:20160623.phame.blog.fulldomain.3.sql',1466802870,589),('phabricator:20160706.phame.blog.parentdomain.2.sql',1494270725,45843),('phabricator:20160706.phame.blog.parentsite.1.sql',1494270725,46013),('phabricator:20160707.calendar.01.stub.sql',1494270725,42144),('phabricator:20160711.files.01.builtin.sql',1494270725,65112),('phabricator:20160711.files.02.builtinkey.sql',1494270725,27811),('phabricator:20160713.event.01.host.sql',1494270725,63878),('phabricator:20160715.event.01.alldayfrom.sql',1494270726,42088),('phabricator:20160715.event.02.alldayto.sql',1494270726,46478),('phabricator:20160715.event.03.allday.php',1494270726,299),('phabricator:20160720.calendar.invitetxn.php',1494270726,9656),('phabricator:20160721.pack.01.pub.sql',1494270726,18084),('phabricator:20160721.pack.02.pubxaction.sql',1494270726,18584),('phabricator:20160721.pack.03.edge.sql',1494270726,39124),('phabricator:20160721.pack.04.pkg.sql',1494270726,20689),('phabricator:20160721.pack.05.pkgxaction.sql',1494270726,18256),('phabricator:20160721.pack.06.version.sql',1494270726,18566),('phabricator:20160721.pack.07.versionxaction.sql',1494270726,18169),('phabricator:20160722.pack.01.pubngrams.sql',1494270726,18245),('phabricator:20160722.pack.02.pkgngrams.sql',1494270726,17888),('phabricator:20160722.pack.03.versionngrams.sql',1494270726,17871),('phabricator:20160810.commit.01.summarylength.sql',1494270726,41142),('phabricator:20160824.connectionlog.sql',1494270726,10097),('phabricator:20160824.repohint.01.hint.sql',1494270726,17710),('phabricator:20160824.repohint.02.movebad.php',1494270726,2230),('phabricator:20160824.repohint.03.nukebad.sql',1494270726,9514),('phabricator:20160825.ponder.sql',1494270726,1290),('phabricator:20160829.pastebin.01.language.sql',1494270726,45036),('phabricator:20160829.pastebin.02.language.sql',1494270726,1241),('phabricator:20160913.conpherence.topic.1.sql',1494270726,49102),('phabricator:20160919.repo.messagecount.sql',1494270726,43962),('phabricator:20160919.repo.messagedefault.sql',1494270726,9673),('phabricator:20160921.fileexternalrequest.sql',1494270727,16299),('phabricator:20160927.phurl.ngrams.php',1494270727,3834),('phabricator:20160927.phurl.ngrams.sql',1494270727,17203),('phabricator:20160928.repo.messagecount.sql',1494270727,1111),('phabricator:20160928.tokentoken.sql',1494270727,18142),('phabricator:20161003.cal.01.utcepoch.sql',1494270727,134356),('phabricator:20161003.cal.02.parameters.sql',1494270727,44873),('phabricator:20161004.cal.01.noepoch.php',1494270727,19848),('phabricator:20161005.cal.01.rrules.php',1494270727,740),('phabricator:20161005.cal.02.export.sql',1494270727,20252),('phabricator:20161005.cal.03.exportxaction.sql',1494270727,25556),('phabricator:20161005.conpherence.image.1.sql',1494270727,49282),('phabricator:20161005.conpherence.image.2.php',1494270727,5481),('phabricator:20161011.conpherence.ngrams.php',1494270727,734),('phabricator:20161011.conpherence.ngrams.sql',1494270727,18996),('phabricator:20161012.cal.01.import.sql',1494270727,22030),('phabricator:20161012.cal.02.importxaction.sql',1494270727,21841),('phabricator:20161012.cal.03.eventimport.sql',1494270727,250842),('phabricator:20161013.cal.01.importlog.sql',1494270728,21394),('phabricator:20161016.conpherence.imagephids.sql',1494270728,44063),('phabricator:20161025.phortune.contact.1.sql',1494270728,43249),('phabricator:20161025.phortune.merchant.image.1.sql',1494270728,43756),('phabricator:20161026.calendar.01.importtriggers.sql',1494270728,85942),('phabricator:20161027.calendar.01.externalinvitee.sql',1494270728,17807),('phabricator:20161029.phortune.invoice.1.sql',1494270728,88773),('phabricator:20161031.calendar.01.seriesparent.sql',1494270728,42328),('phabricator:20161031.calendar.02.notifylog.sql',1494270728,17192),('phabricator:20161101.calendar.01.noholiday.sql',1494270728,9617),('phabricator:20161101.calendar.02.removecolumns.sql',1494270728,273133),('phabricator:20161104.calendar.01.availability.sql',1494270728,40605),('phabricator:20161104.calendar.02.availdefault.sql',1494270728,1438),('phabricator:20161115.phamepost.01.subtitle.sql',1494270729,54066),('phabricator:20161115.phamepost.02.header.sql',1494270729,44884),('phabricator:20161121.cluster.01.hoststate.sql',1494270729,20035),('phabricator:20161124.search.01.stopwords.sql',1494270729,30439),('phabricator:20161125.search.01.stemmed.sql',1494270729,13283),('phabricator:20161130.search.01.manual.sql',1494270729,23244),('phabricator:20161130.search.02.rebuild.php',1494270729,11281),('phabricator:20161210.dashboards.01.author.sql',1494270729,45203),('phabricator:20161210.dashboards.02.author.php',1494270729,5201),('phabricator:20161211.menu.01.itemkey.sql',1494270729,48498),('phabricator:20161211.menu.02.itemprops.sql',1494270729,45050),('phabricator:20161211.menu.03.order.sql',1494270729,47355),('phabricator:20161212.dashboardpanel.01.author.sql',1494270729,39920),('phabricator:20161212.dashboardpanel.02.author.php',1494270729,3375),('phabricator:20161212.dashboards.01.icon.sql',1494270729,53113),('phabricator:20161213.diff.01.hunks.php',1494270729,2613),('phabricator:20161216.dashboard.ngram.01.sql',1494270729,33175),('phabricator:20161216.dashboard.ngram.02.php',1494270729,1374),('phabricator:20170106.menu.01.customphd.sql',1494270729,48638),('phabricator:20170109.diff.01.commit.sql',1494270729,59639),('phabricator:20170119.menuitem.motivator.01.php',1494270729,3942),('phabricator:20170131.dashboard.personal.01.php',1494270729,3267),('phabricator:20170301.subtype.01.col.sql',1494270730,44303),('phabricator:20170301.subtype.02.default.sql',1494270730,1363),('phabricator:20170301.subtype.03.taskcol.sql',1494270730,45568),('phabricator:20170301.subtype.04.taskdefault.sql',1494270730,1628),('phabricator:20170303.people.01.avatar.sql',1494270730,91889),('phabricator:20170313.reviewers.01.sql',1494270730,18330),('phabricator:20170316.rawfiles.01.php',1494270730,3575),('phabricator:20170320.reviewers.01.lastaction.sql',1494270730,43755),('phabricator:20170320.reviewers.02.lastcomment.sql',1494270730,48611),('phabricator:20170320.reviewers.03.migrate.php',1494270730,6410),('phabricator:20170322.reviewers.04.actor.sql',1494270730,44520),('phabricator:20170328.reviewers.01.void.sql',1494270730,52608),('phabricator:20170406.hmac.01.keystore.sql',1494270730,18473),('phabricator:daemonstatus.sql',1466802856,NULL),('phabricator:daemonstatuskey.sql',1466802856,NULL),('phabricator:daemontaskarchive.sql',1466802856,NULL),('phabricator:db.almanac',1466802850,NULL),('phabricator:db.audit',1466802850,NULL),('phabricator:db.auth',1466802850,NULL),('phabricator:db.badges',1466802850,NULL),('phabricator:db.cache',1466802850,NULL),('phabricator:db.calendar',1466802850,NULL),('phabricator:db.chatlog',1466802850,NULL),('phabricator:db.conduit',1466802850,NULL),('phabricator:db.config',1466802850,NULL),('phabricator:db.conpherence',1466802850,NULL),('phabricator:db.countdown',1466802850,NULL),('phabricator:db.daemon',1466802850,NULL),('phabricator:db.dashboard',1466802850,NULL),('phabricator:db.differential',1466802850,NULL),('phabricator:db.diviner',1466802850,NULL),('phabricator:db.doorkeeper',1466802850,NULL),('phabricator:db.draft',1466802850,NULL),('phabricator:db.drydock',1466802850,NULL),('phabricator:db.fact',1466802850,NULL),('phabricator:db.feed',1466802850,NULL),('phabricator:db.file',1466802850,NULL),('phabricator:db.flag',1466802850,NULL),('phabricator:db.fund',1466802850,NULL),('phabricator:db.harbormaster',1466802850,NULL),('phabricator:db.herald',1466802850,NULL),('phabricator:db.legalpad',1466802850,NULL),('phabricator:db.maniphest',1466802850,NULL),('phabricator:db.meta_data',1466802850,NULL),('phabricator:db.metamta',1466802850,NULL),('phabricator:db.multimeter',1466802850,NULL),('phabricator:db.nuance',1466802850,NULL),('phabricator:db.oauth_server',1466802850,NULL),('phabricator:db.owners',1466802850,NULL),('phabricator:db.packages',1494270725,1152),('phabricator:db.passphrase',1466802850,NULL),('phabricator:db.pastebin',1466802850,NULL),('phabricator:db.phame',1466802850,NULL),('phabricator:db.phlux',1466802850,NULL),('phabricator:db.pholio',1466802850,NULL),('phabricator:db.phortune',1466802850,NULL),('phabricator:db.phragment',1466802850,NULL),('phabricator:db.phrequent',1466802850,NULL),('phabricator:db.phriction',1466802850,NULL),('phabricator:db.phurl',1466802850,NULL),('phabricator:db.policy',1466802850,NULL),('phabricator:db.ponder',1466802850,NULL),('phabricator:db.project',1466802850,NULL),('phabricator:db.releeph',1466802850,NULL),('phabricator:db.repository',1466802850,NULL),('phabricator:db.search',1466802850,NULL),('phabricator:db.slowvote',1466802850,NULL),('phabricator:db.spaces',1466802850,NULL),('phabricator:db.system',1466802850,NULL),('phabricator:db.timeline',1466802850,NULL),('phabricator:db.token',1466802850,NULL),('phabricator:db.user',1466802850,NULL),('phabricator:db.worker',1466802850,NULL),('phabricator:db.xhpast',1466802850,NULL),('phabricator:db.xhpastview',1466802850,NULL),('phabricator:db.xhprof',1466802850,NULL),('phabricator:differentialbookmarks.sql',1466802856,NULL),('phabricator:draft-metadata.sql',1466802856,NULL),('phabricator:dropfileproxyimage.sql',1466802856,NULL),('phabricator:drydockresoucetype.sql',1466802856,NULL),('phabricator:drydocktaskid.sql',1466802856,NULL),('phabricator:edgetype.sql',1466802856,NULL),('phabricator:emailtable.sql',1466802855,NULL),('phabricator:emailtableport.sql',1466802855,NULL),('phabricator:emailtableremove.sql',1466802855,NULL),('phabricator:fact-raw.sql',1466802856,NULL),('phabricator:harbormasterobject.sql',1466802856,NULL),('phabricator:holidays.sql',1466802855,NULL),('phabricator:ldapinfo.sql',1466802855,NULL),('phabricator:legalpad-mailkey-populate.php',1466802858,NULL),('phabricator:legalpad-mailkey.sql',1466802858,NULL),('phabricator:liskcounters-task.sql',1466802856,NULL),('phabricator:liskcounters.php',1466802856,NULL),('phabricator:liskcounters.sql',1466802856,NULL),('phabricator:maniphestxcache.sql',1466802856,NULL),('phabricator:markupcache.sql',1466802856,NULL),('phabricator:migrate-differential-dependencies.php',1466802856,NULL),('phabricator:migrate-maniphest-dependencies.php',1466802856,NULL),('phabricator:migrate-maniphest-revisions.php',1466802856,NULL),('phabricator:migrate-project-edges.php',1466802856,NULL),('phabricator:owners-exclude.sql',1466802856,NULL),('phabricator:pastepolicy.sql',1466802856,NULL),('phabricator:phameblog.sql',1466802856,NULL),('phabricator:phamedomain.sql',1466802856,NULL),('phabricator:phameoneblog.sql',1466802856,NULL),('phabricator:phamepolicy.sql',1466802856,NULL),('phabricator:phiddrop.sql',1466802855,NULL),('phabricator:pholio.sql',1466802856,NULL),('phabricator:policy-project.sql',1466802856,NULL),('phabricator:ponder-comments.sql',1466802856,NULL),('phabricator:ponder-mailkey-populate.php',1466802856,NULL),('phabricator:ponder-mailkey.sql',1466802856,NULL),('phabricator:ponder.sql',1466802856,NULL),('phabricator:releeph.sql',1466802857,NULL),('phabricator:repository-lint.sql',1466802856,NULL),('phabricator:statustxt.sql',1466802856,NULL),('phabricator:symbolcontexts.sql',1466802856,NULL),('phabricator:testdatabase.sql',1466802855,NULL),('phabricator:threadtopic.sql',1466802855,NULL),('phabricator:userstatus.sql',1466802855,NULL),('phabricator:usertranslation.sql',1466802855,NULL),('phabricator:xhprof.sql',1466802856,NULL);
/*!40000 ALTER TABLE `patch_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_metamta`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_metamta` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_metamta`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metamta_applicationemail`
--

DROP TABLE IF EXISTS `metamta_applicationemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metamta_applicationemail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `applicationPHID` varbinary(64) NOT NULL,
  `address` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `configData` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_address` (`address`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_application` (`applicationPHID`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metamta_applicationemail`
--

LOCK TABLES `metamta_applicationemail` WRITE;
/*!40000 ALTER TABLE `metamta_applicationemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `metamta_applicationemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metamta_applicationemailtransaction`
--

DROP TABLE IF EXISTS `metamta_applicationemailtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metamta_applicationemailtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metamta_applicationemailtransaction`
--

LOCK TABLES `metamta_applicationemailtransaction` WRITE;
/*!40000 ALTER TABLE `metamta_applicationemailtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `metamta_applicationemailtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metamta_mail`
--

DROP TABLE IF EXISTS `metamta_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metamta_mail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `actorPHID` varbinary(64) DEFAULT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `message` longtext COLLATE utf8mb4_bin,
  `relatedPHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `relatedPHID` (`relatedPHID`),
  KEY `key_created` (`dateCreated`),
  KEY `key_actorPHID` (`actorPHID`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metamta_mail`
--

LOCK TABLES `metamta_mail` WRITE;
/*!40000 ALTER TABLE `metamta_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `metamta_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metamta_receivedmail`
--

DROP TABLE IF EXISTS `metamta_receivedmail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metamta_receivedmail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `headers` longtext COLLATE utf8mb4_bin NOT NULL,
  `bodies` longtext COLLATE utf8mb4_bin NOT NULL,
  `attachments` longtext COLLATE utf8mb4_bin NOT NULL,
  `relatedPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_bin,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `messageIDHash` binary(12) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relatedPHID` (`relatedPHID`),
  KEY `authorPHID` (`authorPHID`),
  KEY `key_messageIDHash` (`messageIDHash`),
  KEY `key_created` (`dateCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metamta_receivedmail`
--

LOCK TABLES `metamta_receivedmail` WRITE;
/*!40000 ALTER TABLE `metamta_receivedmail` DISABLE KEYS */;
/*!40000 ALTER TABLE `metamta_receivedmail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `providerShortName` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `providerSMSID` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `toNumber` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `fromNumber` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_bin NOT NULL,
  `sendStatus` varchar(16) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_provider` (`providerSMSID`,`providerShortName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_oauth_server`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_oauth_server` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_oauth_server`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_server_oauthclientauthorization`
--

DROP TABLE IF EXISTS `oauth_server_oauthclientauthorization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_server_oauthclientauthorization` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `userPHID` varbinary(64) NOT NULL,
  `clientPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `scope` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `userPHID` (`userPHID`,`clientPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_server_oauthclientauthorization`
--

LOCK TABLES `oauth_server_oauthclientauthorization` WRITE;
/*!40000 ALTER TABLE `oauth_server_oauthclientauthorization` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_server_oauthclientauthorization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_server_oauthserveraccesstoken`
--

DROP TABLE IF EXISTS `oauth_server_oauthserveraccesstoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_server_oauthserveraccesstoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `userPHID` varbinary(64) NOT NULL,
  `clientPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_server_oauthserveraccesstoken`
--

LOCK TABLES `oauth_server_oauthserveraccesstoken` WRITE;
/*!40000 ALTER TABLE `oauth_server_oauthserveraccesstoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_server_oauthserveraccesstoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_server_oauthserverauthorizationcode`
--

DROP TABLE IF EXISTS `oauth_server_oauthserverauthorizationcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_server_oauthserverauthorizationcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `clientPHID` varbinary(64) NOT NULL,
  `clientSecret` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `userPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `redirectURI` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_server_oauthserverauthorizationcode`
--

LOCK TABLES `oauth_server_oauthserverauthorizationcode` WRITE;
/*!40000 ALTER TABLE `oauth_server_oauthserverauthorizationcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_server_oauthserverauthorizationcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_server_oauthserverclient`
--

DROP TABLE IF EXISTS `oauth_server_oauthserverclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_server_oauthserverclient` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `secret` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `redirectURI` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `isTrusted` tinyint(1) NOT NULL DEFAULT '0',
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `creatorPHID` (`creatorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_server_oauthserverclient`
--

LOCK TABLES `oauth_server_oauthserverclient` WRITE;
/*!40000 ALTER TABLE `oauth_server_oauthserverclient` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_server_oauthserverclient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_server_transaction`
--

DROP TABLE IF EXISTS `oauth_server_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_server_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_server_transaction`
--

LOCK TABLES `oauth_server_transaction` WRITE;
/*!40000 ALTER TABLE `oauth_server_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_server_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_owners`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_owners` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_owners`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_customfieldnumericindex`
--

DROP TABLE IF EXISTS `owners_customfieldnumericindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_customfieldnumericindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`),
  KEY `key_find` (`indexKey`,`indexValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_customfieldnumericindex`
--

LOCK TABLES `owners_customfieldnumericindex` WRITE;
/*!40000 ALTER TABLE `owners_customfieldnumericindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_customfieldnumericindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_customfieldstorage`
--

DROP TABLE IF EXISTS `owners_customfieldstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_customfieldstorage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_customfieldstorage`
--

LOCK TABLES `owners_customfieldstorage` WRITE;
/*!40000 ALTER TABLE `owners_customfieldstorage` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_customfieldstorage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_customfieldstringindex`
--

DROP TABLE IF EXISTS `owners_customfieldstringindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_customfieldstringindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`(64)),
  KEY `key_find` (`indexKey`,`indexValue`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_customfieldstringindex`
--

LOCK TABLES `owners_customfieldstringindex` WRITE;
/*!40000 ALTER TABLE `owners_customfieldstringindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_customfieldstringindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_name_ngrams`
--

DROP TABLE IF EXISTS `owners_name_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_name_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_name_ngrams`
--

LOCK TABLES `owners_name_ngrams` WRITE;
/*!40000 ALTER TABLE `owners_name_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_name_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_owner`
--

DROP TABLE IF EXISTS `owners_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_owner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `packageID` int(10) unsigned NOT NULL,
  `userPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `packageID` (`packageID`,`userPHID`),
  KEY `userPHID` (`userPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_owner`
--

LOCK TABLES `owners_owner` WRITE;
/*!40000 ALTER TABLE `owners_owner` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_package`
--

DROP TABLE IF EXISTS `owners_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_package` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `originalName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `primaryOwnerPHID` varbinary(64) DEFAULT NULL,
  `auditingEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `mailKey` binary(20) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `autoReview` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dominion` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_package`
--

LOCK TABLES `owners_package` WRITE;
/*!40000 ALTER TABLE `owners_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_packagetransaction`
--

DROP TABLE IF EXISTS `owners_packagetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_packagetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_packagetransaction`
--

LOCK TABLES `owners_packagetransaction` WRITE;
/*!40000 ALTER TABLE `owners_packagetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_packagetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners_path`
--

DROP TABLE IF EXISTS `owners_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners_path` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `packageID` int(10) unsigned NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `excluded` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `packageID` (`packageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners_path`
--

LOCK TABLES `owners_path` WRITE;
/*!40000 ALTER TABLE `owners_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_pastebin`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_pastebin` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_pastebin`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pastebin_paste`
--

DROP TABLE IF EXISTS `pastebin_paste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pastebin_paste` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `filePHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `language` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `parentPHID` varbinary(64) DEFAULT NULL,
  `viewPolicy` varbinary(64) DEFAULT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `parentPHID` (`parentPHID`),
  KEY `authorPHID` (`authorPHID`),
  KEY `key_dateCreated` (`dateCreated`),
  KEY `key_language` (`language`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pastebin_paste`
--

LOCK TABLES `pastebin_paste` WRITE;
/*!40000 ALTER TABLE `pastebin_paste` DISABLE KEYS */;
/*!40000 ALTER TABLE `pastebin_paste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pastebin_pastetransaction`
--

DROP TABLE IF EXISTS `pastebin_pastetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pastebin_pastetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pastebin_pastetransaction`
--

LOCK TABLES `pastebin_pastetransaction` WRITE;
/*!40000 ALTER TABLE `pastebin_pastetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pastebin_pastetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pastebin_pastetransaction_comment`
--

DROP TABLE IF EXISTS `pastebin_pastetransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pastebin_pastetransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `lineNumber` int(10) unsigned DEFAULT NULL,
  `lineLength` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pastebin_pastetransaction_comment`
--

LOCK TABLES `pastebin_pastetransaction_comment` WRITE;
/*!40000 ALTER TABLE `pastebin_pastetransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `pastebin_pastetransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phame`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phame` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phame`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phame_blog`
--

DROP TABLE IF EXISTS `phame_blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phame_blog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `domain` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `configData` longtext COLLATE utf8mb4_bin NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `viewPolicy` varbinary(64) DEFAULT NULL,
  `editPolicy` varbinary(64) DEFAULT NULL,
  `mailKey` binary(20) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `headerImagePHID` varbinary(64) DEFAULT NULL,
  `subtitle` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `parentDomain` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `parentSite` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `domainFullURI` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phame_blog`
--

LOCK TABLES `phame_blog` WRITE;
/*!40000 ALTER TABLE `phame_blog` DISABLE KEYS */;
/*!40000 ALTER TABLE `phame_blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phame_blogtransaction`
--

DROP TABLE IF EXISTS `phame_blogtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phame_blogtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phame_blogtransaction`
--

LOCK TABLES `phame_blogtransaction` WRITE;
/*!40000 ALTER TABLE `phame_blogtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phame_blogtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phame_post`
--

DROP TABLE IF EXISTS `phame_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phame_post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `bloggerPHID` varbinary(64) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `phameTitle` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_bin,
  `visibility` int(10) unsigned NOT NULL DEFAULT '0',
  `configData` longtext COLLATE utf8mb4_bin,
  `datePublished` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `blogPHID` varbinary(64) DEFAULT NULL,
  `mailKey` binary(20) NOT NULL,
  `subtitle` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `headerImagePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `bloggerPosts` (`bloggerPHID`,`visibility`,`datePublished`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phame_post`
--

LOCK TABLES `phame_post` WRITE;
/*!40000 ALTER TABLE `phame_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `phame_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phame_posttransaction`
--

DROP TABLE IF EXISTS `phame_posttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phame_posttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phame_posttransaction`
--

LOCK TABLES `phame_posttransaction` WRITE;
/*!40000 ALTER TABLE `phame_posttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phame_posttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phame_posttransaction_comment`
--

DROP TABLE IF EXISTS `phame_posttransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phame_posttransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phame_posttransaction_comment`
--

LOCK TABLES `phame_posttransaction_comment` WRITE;
/*!40000 ALTER TABLE `phame_posttransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `phame_posttransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phriction`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phriction` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phriction`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phriction_content`
--

DROP TABLE IF EXISTS `phriction_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phriction_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `documentID` int(10) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_bin,
  `changeType` int(10) unsigned NOT NULL DEFAULT '0',
  `changeRef` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `documentID` (`documentID`,`version`),
  KEY `authorPHID` (`authorPHID`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phriction_content`
--

LOCK TABLES `phriction_content` WRITE;
/*!40000 ALTER TABLE `phriction_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `phriction_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phriction_document`
--

DROP TABLE IF EXISTS `phriction_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phriction_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `slug` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `contentID` int(10) unsigned DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `depth` (`depth`,`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phriction_document`
--

LOCK TABLES `phriction_document` WRITE;
/*!40000 ALTER TABLE `phriction_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `phriction_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phriction_transaction`
--

DROP TABLE IF EXISTS `phriction_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phriction_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phriction_transaction`
--

LOCK TABLES `phriction_transaction` WRITE;
/*!40000 ALTER TABLE `phriction_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phriction_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phriction_transaction_comment`
--

DROP TABLE IF EXISTS `phriction_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phriction_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phriction_transaction_comment`
--

LOCK TABLES `phriction_transaction_comment` WRITE;
/*!40000 ALTER TABLE `phriction_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `phriction_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_project`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_project` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_project`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `joinPolicy` varbinary(64) NOT NULL,
  `isMembershipLocked` tinyint(1) NOT NULL DEFAULT '0',
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `icon` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `color` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `primarySlug` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `parentProjectPHID` varbinary(64) DEFAULT NULL,
  `hasWorkboard` tinyint(1) NOT NULL,
  `hasMilestones` tinyint(1) NOT NULL,
  `hasSubprojects` tinyint(1) NOT NULL,
  `milestoneNumber` int(10) unsigned DEFAULT NULL,
  `projectPath` varbinary(64) NOT NULL,
  `projectDepth` int(10) unsigned NOT NULL,
  `projectPathKey` binary(4) NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_pathkey` (`projectPathKey`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_primaryslug` (`primarySlug`),
  UNIQUE KEY `key_milestone` (`parentProjectPHID`,`milestoneNumber`),
  KEY `key_icon` (`icon`),
  KEY `key_color` (`color`),
  KEY `key_path` (`projectPath`,`projectDepth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_column`
--

DROP TABLE IF EXISTS `project_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_column` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  `projectPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `proxyPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_proxy` (`projectPHID`,`proxyPHID`),
  KEY `key_status` (`projectPHID`,`status`,`sequence`),
  KEY `key_sequence` (`projectPHID`,`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_column`
--

LOCK TABLES `project_column` WRITE;
/*!40000 ALTER TABLE `project_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_columnposition`
--

DROP TABLE IF EXISTS `project_columnposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_columnposition` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boardPHID` varbinary(64) NOT NULL,
  `columnPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `boardPHID` (`boardPHID`,`columnPHID`,`objectPHID`),
  KEY `objectPHID` (`objectPHID`,`boardPHID`),
  KEY `boardPHID_2` (`boardPHID`,`columnPHID`,`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_columnposition`
--

LOCK TABLES `project_columnposition` WRITE;
/*!40000 ALTER TABLE `project_columnposition` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_columnposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_columntransaction`
--

DROP TABLE IF EXISTS `project_columntransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_columntransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_columntransaction`
--

LOCK TABLES `project_columntransaction` WRITE;
/*!40000 ALTER TABLE `project_columntransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_columntransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_customfieldnumericindex`
--

DROP TABLE IF EXISTS `project_customfieldnumericindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_customfieldnumericindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`),
  KEY `key_find` (`indexKey`,`indexValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_customfieldnumericindex`
--

LOCK TABLES `project_customfieldnumericindex` WRITE;
/*!40000 ALTER TABLE `project_customfieldnumericindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_customfieldnumericindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_customfieldstorage`
--

DROP TABLE IF EXISTS `project_customfieldstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_customfieldstorage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_customfieldstorage`
--

LOCK TABLES `project_customfieldstorage` WRITE;
/*!40000 ALTER TABLE `project_customfieldstorage` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_customfieldstorage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_customfieldstringindex`
--

DROP TABLE IF EXISTS `project_customfieldstringindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_customfieldstringindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`(64)),
  KEY `key_find` (`indexKey`,`indexValue`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_customfieldstringindex`
--

LOCK TABLES `project_customfieldstringindex` WRITE;
/*!40000 ALTER TABLE `project_customfieldstringindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_customfieldstringindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_datasourcetoken`
--

DROP TABLE IF EXISTS `project_datasourcetoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_datasourcetoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectID` int(10) unsigned NOT NULL,
  `token` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`,`projectID`),
  KEY `projectID` (`projectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_datasourcetoken`
--

LOCK TABLES `project_datasourcetoken` WRITE;
/*!40000 ALTER TABLE `project_datasourcetoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_datasourcetoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_slug`
--

DROP TABLE IF EXISTS `project_slug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_slug` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectPHID` varbinary(64) NOT NULL,
  `slug` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_slug` (`slug`),
  KEY `key_projectPHID` (`projectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_slug`
--

LOCK TABLES `project_slug` WRITE;
/*!40000 ALTER TABLE `project_slug` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_slug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_transaction`
--

DROP TABLE IF EXISTS `project_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_transaction`
--

LOCK TABLES `project_transaction` WRITE;
/*!40000 ALTER TABLE `project_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_repository`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_repository` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_repository`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository`
--

DROP TABLE IF EXISTS `repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `callsign` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `versionControlSystem` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `uuid` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `pushPolicy` varbinary(64) NOT NULL,
  `credentialPHID` varbinary(64) DEFAULT NULL,
  `almanacServicePHID` varbinary(64) DEFAULT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `repositorySlug` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `localPath` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `callsign` (`callsign`),
  UNIQUE KEY `key_slug` (`repositorySlug`),
  UNIQUE KEY `key_local` (`localPath`),
  KEY `key_vcs` (`versionControlSystem`),
  KEY `key_name` (`name`(128)),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository`
--

LOCK TABLES `repository` WRITE;
/*!40000 ALTER TABLE `repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_auditrequest`
--

DROP TABLE IF EXISTS `repository_auditrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_auditrequest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `auditorPHID` varbinary(64) NOT NULL,
  `commitPHID` varbinary(64) NOT NULL,
  `auditStatus` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `auditReasons` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_unique` (`commitPHID`,`auditorPHID`),
  KEY `commitPHID` (`commitPHID`),
  KEY `auditorPHID` (`auditorPHID`,`auditStatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_auditrequest`
--

LOCK TABLES `repository_auditrequest` WRITE;
/*!40000 ALTER TABLE `repository_auditrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_auditrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_branch`
--

DROP TABLE IF EXISTS `repository_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryID` int(10) unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `lintCommit` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `repositoryID` (`repositoryID`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_branch`
--

LOCK TABLES `repository_branch` WRITE;
/*!40000 ALTER TABLE `repository_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_commit`
--

DROP TABLE IF EXISTS `repository_commit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_commit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryID` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `commitIdentifier` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `auditStatus` int(10) unsigned NOT NULL,
  `summary` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `importStatus` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `key_commit_identity` (`commitIdentifier`,`repositoryID`),
  KEY `repositoryID_2` (`repositoryID`,`epoch`),
  KEY `authorPHID` (`authorPHID`,`auditStatus`,`epoch`),
  KEY `repositoryID` (`repositoryID`,`importStatus`),
  KEY `key_epoch` (`epoch`),
  KEY `key_author` (`authorPHID`,`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_commit`
--

LOCK TABLES `repository_commit` WRITE;
/*!40000 ALTER TABLE `repository_commit` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_commit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_commitdata`
--

DROP TABLE IF EXISTS `repository_commitdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_commitdata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `commitID` int(10) unsigned NOT NULL,
  `authorName` longtext COLLATE utf8mb4_bin NOT NULL,
  `commitMessage` longtext COLLATE utf8mb4_bin NOT NULL,
  `commitDetails` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `commitID` (`commitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_commitdata`
--

LOCK TABLES `repository_commitdata` WRITE;
/*!40000 ALTER TABLE `repository_commitdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_commitdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_commithint`
--

DROP TABLE IF EXISTS `repository_commithint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_commithint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryPHID` varbinary(64) NOT NULL,
  `oldCommitIdentifier` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `newCommitIdentifier` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `hintType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_old` (`repositoryPHID`,`oldCommitIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_commithint`
--

LOCK TABLES `repository_commithint` WRITE;
/*!40000 ALTER TABLE `repository_commithint` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_commithint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_coverage`
--

DROP TABLE IF EXISTS `repository_coverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_coverage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branchID` int(10) unsigned NOT NULL,
  `commitID` int(10) unsigned NOT NULL,
  `pathID` int(10) unsigned NOT NULL,
  `coverage` longblob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_path` (`branchID`,`pathID`,`commitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_coverage`
--

LOCK TABLES `repository_coverage` WRITE;
/*!40000 ALTER TABLE `repository_coverage` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_coverage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_filesystem`
--

DROP TABLE IF EXISTS `repository_filesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_filesystem` (
  `repositoryID` int(10) unsigned NOT NULL,
  `parentID` int(10) unsigned NOT NULL,
  `svnCommit` int(10) unsigned NOT NULL,
  `pathID` int(10) unsigned NOT NULL,
  `existed` tinyint(1) NOT NULL,
  `fileType` int(10) unsigned NOT NULL,
  PRIMARY KEY (`repositoryID`,`parentID`,`pathID`,`svnCommit`),
  KEY `repositoryID` (`repositoryID`,`svnCommit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_filesystem`
--

LOCK TABLES `repository_filesystem` WRITE;
/*!40000 ALTER TABLE `repository_filesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_filesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_gitlfsref`
--

DROP TABLE IF EXISTS `repository_gitlfsref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_gitlfsref` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryPHID` varbinary(64) NOT NULL,
  `objectHash` binary(64) NOT NULL,
  `byteSize` bigint(20) unsigned NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `filePHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`repositoryPHID`,`objectHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_gitlfsref`
--

LOCK TABLES `repository_gitlfsref` WRITE;
/*!40000 ALTER TABLE `repository_gitlfsref` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_gitlfsref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_lintmessage`
--

DROP TABLE IF EXISTS `repository_lintmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_lintmessage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branchID` int(10) unsigned NOT NULL,
  `path` longtext COLLATE utf8mb4_bin NOT NULL,
  `line` int(10) unsigned NOT NULL,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `severity` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `branchID` (`branchID`,`path`(64)),
  KEY `branchID_2` (`branchID`,`code`,`path`(64)),
  KEY `key_author` (`authorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_lintmessage`
--

LOCK TABLES `repository_lintmessage` WRITE;
/*!40000 ALTER TABLE `repository_lintmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_lintmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_mirror`
--

DROP TABLE IF EXISTS `repository_mirror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_mirror` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `remoteURI` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `credentialPHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_repository` (`repositoryPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_mirror`
--

LOCK TABLES `repository_mirror` WRITE;
/*!40000 ALTER TABLE `repository_mirror` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_mirror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_oldref`
--

DROP TABLE IF EXISTS `repository_oldref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_oldref` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryPHID` varbinary(64) NOT NULL,
  `commitIdentifier` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_repository` (`repositoryPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_oldref`
--

LOCK TABLES `repository_oldref` WRITE;
/*!40000 ALTER TABLE `repository_oldref` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_oldref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_parents`
--

DROP TABLE IF EXISTS `repository_parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_parents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `childCommitID` int(10) unsigned NOT NULL,
  `parentCommitID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_child` (`childCommitID`,`parentCommitID`),
  KEY `key_parent` (`parentCommitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_parents`
--

LOCK TABLES `repository_parents` WRITE;
/*!40000 ALTER TABLE `repository_parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_path`
--

DROP TABLE IF EXISTS `repository_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_path` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` longtext COLLATE utf8mb4_bin NOT NULL,
  `pathHash` binary(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pathHash` (`pathHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_path`
--

LOCK TABLES `repository_path` WRITE;
/*!40000 ALTER TABLE `repository_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_pathchange`
--

DROP TABLE IF EXISTS `repository_pathchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_pathchange` (
  `repositoryID` int(10) unsigned NOT NULL,
  `pathID` int(10) unsigned NOT NULL,
  `commitID` int(10) unsigned NOT NULL,
  `targetPathID` int(10) unsigned DEFAULT NULL,
  `targetCommitID` int(10) unsigned DEFAULT NULL,
  `changeType` int(10) unsigned NOT NULL,
  `fileType` int(10) unsigned NOT NULL,
  `isDirect` tinyint(1) NOT NULL,
  `commitSequence` int(10) unsigned NOT NULL,
  PRIMARY KEY (`commitID`,`pathID`),
  KEY `repositoryID` (`repositoryID`,`pathID`,`commitSequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_pathchange`
--

LOCK TABLES `repository_pathchange` WRITE;
/*!40000 ALTER TABLE `repository_pathchange` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_pathchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_pullevent`
--

DROP TABLE IF EXISTS `repository_pullevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_pullevent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) DEFAULT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `pullerPHID` varbinary(64) DEFAULT NULL,
  `remoteAddress` varbinary(64) DEFAULT NULL,
  `remoteProtocol` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `resultType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `resultCode` int(10) unsigned NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_repository` (`repositoryPHID`),
  KEY `key_epoch` (`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_pullevent`
--

LOCK TABLES `repository_pullevent` WRITE;
/*!40000 ALTER TABLE `repository_pullevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_pullevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_pushevent`
--

DROP TABLE IF EXISTS `repository_pushevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_pushevent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `pusherPHID` varbinary(64) NOT NULL,
  `remoteAddress` varbinary(64) DEFAULT NULL,
  `remoteProtocol` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `rejectCode` int(10) unsigned NOT NULL,
  `rejectDetails` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_repository` (`repositoryPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_pushevent`
--

LOCK TABLES `repository_pushevent` WRITE;
/*!40000 ALTER TABLE `repository_pushevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_pushevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_pushlog`
--

DROP TABLE IF EXISTS `repository_pushlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_pushlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `pushEventPHID` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `pusherPHID` varbinary(64) NOT NULL,
  `refType` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `refNameHash` binary(12) DEFAULT NULL,
  `refNameRaw` longblob,
  `refNameEncoding` varchar(16) COLLATE utf8mb4_bin DEFAULT NULL,
  `refOld` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `refNew` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `mergeBase` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `changeFlags` int(10) unsigned NOT NULL,
  `devicePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_repository` (`repositoryPHID`),
  KEY `key_ref` (`repositoryPHID`,`refNew`),
  KEY `key_pusher` (`pusherPHID`),
  KEY `key_name` (`repositoryPHID`,`refNameHash`),
  KEY `key_event` (`pushEventPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_pushlog`
--

LOCK TABLES `repository_pushlog` WRITE;
/*!40000 ALTER TABLE `repository_pushlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_pushlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_refcursor`
--

DROP TABLE IF EXISTS `repository_refcursor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_refcursor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `refType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `refNameHash` binary(12) NOT NULL,
  `refNameRaw` longblob NOT NULL,
  `refNameEncoding` varchar(16) COLLATE utf8mb4_bin DEFAULT NULL,
  `commitIdentifier` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `isClosed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_cursor` (`repositoryPHID`,`refType`,`refNameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_refcursor`
--

LOCK TABLES `repository_refcursor` WRITE;
/*!40000 ALTER TABLE `repository_refcursor` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_refcursor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_statusmessage`
--

DROP TABLE IF EXISTS `repository_statusmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_statusmessage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryID` int(10) unsigned NOT NULL,
  `statusType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `statusCode` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `messageCount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `repositoryID` (`repositoryID`,`statusType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_statusmessage`
--

LOCK TABLES `repository_statusmessage` WRITE;
/*!40000 ALTER TABLE `repository_statusmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_statusmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_summary`
--

DROP TABLE IF EXISTS `repository_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_summary` (
  `repositoryID` int(10) unsigned NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `lastCommitID` int(10) unsigned NOT NULL,
  `epoch` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`repositoryID`),
  KEY `key_epoch` (`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_summary`
--

LOCK TABLES `repository_summary` WRITE;
/*!40000 ALTER TABLE `repository_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_symbol`
--

DROP TABLE IF EXISTS `repository_symbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_symbol` (
  `repositoryPHID` varbinary(64) NOT NULL,
  `symbolContext` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `symbolName` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `symbolType` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `symbolLanguage` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `pathID` int(10) unsigned NOT NULL,
  `lineNumber` int(10) unsigned NOT NULL,
  KEY `symbolName` (`symbolName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_symbol`
--

LOCK TABLES `repository_symbol` WRITE;
/*!40000 ALTER TABLE `repository_symbol` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_symbol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_transaction`
--

DROP TABLE IF EXISTS `repository_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_transaction`
--

LOCK TABLES `repository_transaction` WRITE;
/*!40000 ALTER TABLE `repository_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_uri`
--

DROP TABLE IF EXISTS `repository_uri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_uri` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `uri` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `builtinProtocol` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `builtinIdentifier` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `ioType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `displayType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `credentialPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_builtin` (`repositoryPHID`,`builtinProtocol`,`builtinIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_uri`
--

LOCK TABLES `repository_uri` WRITE;
/*!40000 ALTER TABLE `repository_uri` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_uri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_uriindex`
--

DROP TABLE IF EXISTS `repository_uriindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_uriindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryPHID` varbinary(64) NOT NULL,
  `repositoryURI` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_repository` (`repositoryPHID`),
  KEY `key_uri` (`repositoryURI`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_uriindex`
--

LOCK TABLES `repository_uriindex` WRITE;
/*!40000 ALTER TABLE `repository_uriindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_uriindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_uritransaction`
--

DROP TABLE IF EXISTS `repository_uritransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_uritransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_uritransaction`
--

LOCK TABLES `repository_uritransaction` WRITE;
/*!40000 ALTER TABLE `repository_uritransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_uritransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_vcspassword`
--

DROP TABLE IF EXISTS `repository_vcspassword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_vcspassword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `passwordHash` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`userPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_vcspassword`
--

LOCK TABLES `repository_vcspassword` WRITE;
/*!40000 ALTER TABLE `repository_vcspassword` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_vcspassword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository_workingcopyversion`
--

DROP TABLE IF EXISTS `repository_workingcopyversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repository_workingcopyversion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repositoryPHID` varbinary(64) NOT NULL,
  `devicePHID` varbinary(64) NOT NULL,
  `repositoryVersion` int(10) unsigned NOT NULL,
  `isWriting` tinyint(1) NOT NULL,
  `writeProperties` longtext COLLATE utf8mb4_bin,
  `lockOwner` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_workingcopy` (`repositoryPHID`,`devicePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository_workingcopyversion`
--

LOCK TABLES `repository_workingcopyversion` WRITE;
/*!40000 ALTER TABLE `repository_workingcopyversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_workingcopyversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_search`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_search` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_search`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_document`
--

DROP TABLE IF EXISTS `search_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_document` (
  `phid` varbinary(64) NOT NULL,
  `documentType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `documentTitle` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `documentCreated` int(10) unsigned NOT NULL,
  `documentModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`phid`),
  KEY `documentCreated` (`documentCreated`),
  KEY `key_type` (`documentType`,`documentCreated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_document`
--

LOCK TABLES `search_document` WRITE;
/*!40000 ALTER TABLE `search_document` DISABLE KEYS */;
INSERT INTO `search_document` VALUES (0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'USER','admin (admin)',1494270894,1494270894),(0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'USER','phab (phab)',1494271765,1494271766);
/*!40000 ALTER TABLE `search_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_documentfield`
--

DROP TABLE IF EXISTS `search_documentfield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_documentfield` (
  `phid` varbinary(64) NOT NULL,
  `phidType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `field` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `auxPHID` varbinary(64) DEFAULT NULL,
  `corpus` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `stemmedCorpus` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  KEY `phid` (`phid`),
  FULLTEXT KEY `key_corpus` (`corpus`,`stemmedCorpus`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_documentfield`
--

LOCK TABLES `search_documentfield` WRITE;
/*!40000 ALTER TABLE `search_documentfield` DISABLE KEYS */;
INSERT INTO `search_documentfield` VALUES (0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'USER','titl',NULL,'admin (admin)','admin'),(0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'USER','titl',NULL,'phab (phab)','phab');
/*!40000 ALTER TABLE `search_documentfield` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_documentrelationship`
--

DROP TABLE IF EXISTS `search_documentrelationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_documentrelationship` (
  `phid` varbinary(64) NOT NULL,
  `relatedPHID` varbinary(64) NOT NULL,
  `relation` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `relatedType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `relatedTime` int(10) unsigned NOT NULL,
  KEY `phid` (`phid`),
  KEY `relatedPHID` (`relatedPHID`,`relation`),
  KEY `relation` (`relation`,`relatedPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_documentrelationship`
--

LOCK TABLES `search_documentrelationship` WRITE;
/*!40000 ALTER TABLE `search_documentrelationship` DISABLE KEYS */;
INSERT INTO `search_documentrelationship` VALUES (0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'open','USER',1494270895),(0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'open','USER',1494271766);
/*!40000 ALTER TABLE `search_documentrelationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_editengineconfiguration`
--

DROP TABLE IF EXISTS `search_editengineconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_editengineconfiguration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `engineKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `builtinKey` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDisabled` tinyint(1) NOT NULL DEFAULT '0',
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isEdit` tinyint(1) NOT NULL,
  `createOrder` int(10) unsigned NOT NULL,
  `editOrder` int(10) unsigned NOT NULL,
  `subtype` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_engine` (`engineKey`,`builtinKey`),
  KEY `key_default` (`engineKey`,`isDefault`,`isDisabled`),
  KEY `key_edit` (`engineKey`,`isEdit`,`isDisabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_editengineconfiguration`
--

LOCK TABLES `search_editengineconfiguration` WRITE;
/*!40000 ALTER TABLE `search_editengineconfiguration` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_editengineconfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_editengineconfigurationtransaction`
--

DROP TABLE IF EXISTS `search_editengineconfigurationtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_editengineconfigurationtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_editengineconfigurationtransaction`
--

LOCK TABLES `search_editengineconfigurationtransaction` WRITE;
/*!40000 ALTER TABLE `search_editengineconfigurationtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_editengineconfigurationtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_indexversion`
--

DROP TABLE IF EXISTS `search_indexversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_indexversion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `extensionKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `version` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_object` (`objectPHID`,`extensionKey`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_indexversion`
--

LOCK TABLES `search_indexversion` WRITE;
/*!40000 ALTER TABLE `search_indexversion` DISABLE KEYS */;
INSERT INTO `search_indexversion` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'fulltext','xzNP8QS9nb2d:none:none'),(2,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'fulltext','xzNP8QS9nb2d:none:none');
/*!40000 ALTER TABLE `search_indexversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_namedquery`
--

DROP TABLE IF EXISTS `search_namedquery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_namedquery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `engineClassName` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `queryName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `queryKey` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isBuiltin` tinyint(1) NOT NULL DEFAULT '0',
  `isDisabled` tinyint(1) NOT NULL DEFAULT '0',
  `sequence` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_userquery` (`userPHID`,`engineClassName`,`queryKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_namedquery`
--

LOCK TABLES `search_namedquery` WRITE;
/*!40000 ALTER TABLE `search_namedquery` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_namedquery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_profilepanelconfiguration`
--

DROP TABLE IF EXISTS `search_profilepanelconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_profilepanelconfiguration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `profilePHID` varbinary(64) NOT NULL,
  `menuItemKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `builtinKey` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `menuItemOrder` int(10) unsigned DEFAULT NULL,
  `visibility` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `menuItemProperties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `customPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_profile` (`profilePHID`,`menuItemOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_profilepanelconfiguration`
--

LOCK TABLES `search_profilepanelconfiguration` WRITE;
/*!40000 ALTER TABLE `search_profilepanelconfiguration` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_profilepanelconfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_profilepanelconfigurationtransaction`
--

DROP TABLE IF EXISTS `search_profilepanelconfigurationtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_profilepanelconfigurationtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_profilepanelconfigurationtransaction`
--

LOCK TABLES `search_profilepanelconfigurationtransaction` WRITE;
/*!40000 ALTER TABLE `search_profilepanelconfigurationtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_profilepanelconfigurationtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_savedquery`
--

DROP TABLE IF EXISTS `search_savedquery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_savedquery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `engineClassName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `queryKey` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_queryKey` (`queryKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_savedquery`
--

LOCK TABLES `search_savedquery` WRITE;
/*!40000 ALTER TABLE `search_savedquery` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_savedquery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stopwords`
--

DROP TABLE IF EXISTS `stopwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stopwords` (
  `value` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stopwords`
--

LOCK TABLES `stopwords` WRITE;
/*!40000 ALTER TABLE `stopwords` DISABLE KEYS */;
INSERT INTO `stopwords` VALUES ('the'),('be'),('and'),('of'),('a'),('in'),('to'),('have'),('it'),('I'),('that'),('for'),('you'),('he'),('with'),('on'),('do'),('say'),('this'),('they'),('at'),('but'),('we'),('his'),('from'),('not'),('by'),('or'),('as'),('what'),('go'),('their'),('can'),('who'),('get'),('if'),('would'),('all'),('my'),('will'),('up'),('there'),('so'),('its'),('us');
/*!40000 ALTER TABLE `stopwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_slowvote`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_slowvote` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_slowvote`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slowvote_choice`
--

DROP TABLE IF EXISTS `slowvote_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowvote_choice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pollID` int(10) unsigned NOT NULL,
  `optionID` int(10) unsigned NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pollID` (`pollID`),
  KEY `authorPHID` (`authorPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowvote_choice`
--

LOCK TABLES `slowvote_choice` WRITE;
/*!40000 ALTER TABLE `slowvote_choice` DISABLE KEYS */;
/*!40000 ALTER TABLE `slowvote_choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slowvote_option`
--

DROP TABLE IF EXISTS `slowvote_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowvote_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pollID` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pollID` (`pollID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowvote_option`
--

LOCK TABLES `slowvote_option` WRITE;
/*!40000 ALTER TABLE `slowvote_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `slowvote_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slowvote_poll`
--

DROP TABLE IF EXISTS `slowvote_poll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowvote_poll` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `responseVisibility` int(10) unsigned NOT NULL,
  `shuffle` int(10) unsigned NOT NULL,
  `method` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `isClosed` tinyint(1) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowvote_poll`
--

LOCK TABLES `slowvote_poll` WRITE;
/*!40000 ALTER TABLE `slowvote_poll` DISABLE KEYS */;
/*!40000 ALTER TABLE `slowvote_poll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slowvote_transaction`
--

DROP TABLE IF EXISTS `slowvote_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowvote_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowvote_transaction`
--

LOCK TABLES `slowvote_transaction` WRITE;
/*!40000 ALTER TABLE `slowvote_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `slowvote_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slowvote_transaction_comment`
--

DROP TABLE IF EXISTS `slowvote_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowvote_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowvote_transaction_comment`
--

LOCK TABLES `slowvote_transaction_comment` WRITE;
/*!40000 ALTER TABLE `slowvote_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `slowvote_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_user`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_user` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_user`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phabricator_session`
--

DROP TABLE IF EXISTS `phabricator_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phabricator_session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `sessionKey` binary(40) NOT NULL,
  `sessionStart` int(10) unsigned NOT NULL,
  `sessionExpires` int(10) unsigned NOT NULL,
  `highSecurityUntil` int(10) unsigned DEFAULT NULL,
  `isPartial` tinyint(1) NOT NULL DEFAULT '0',
  `signedLegalpadDocuments` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessionKey` (`sessionKey`),
  KEY `key_identity` (`userPHID`,`type`),
  KEY `key_expires` (`sessionExpires`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phabricator_session`
--

LOCK TABLES `phabricator_session` WRITE;
/*!40000 ALTER TABLE `phabricator_session` DISABLE KEYS */;
INSERT INTO `phabricator_session` VALUES (3,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'web',0x36333336646230303964396666336432313738363936306565646436316266336230323030386432,1494273474,1496865474,NULL,0,1),(6,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'web',0x38323964363136343238303163316138646164333433376561663161303533303062666239366363,1494366454,1496958454,NULL,0,1);
/*!40000 ALTER TABLE `phabricator_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `userName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `realName` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `passwordSalt` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `passwordHash` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `conduitCertificate` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `isSystemAgent` tinyint(1) NOT NULL DEFAULT '0',
  `isDisabled` tinyint(1) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `isEmailVerified` int(10) unsigned NOT NULL,
  `isApproved` int(10) unsigned NOT NULL,
  `accountSecret` binary(64) NOT NULL,
  `isEnrolledInMultiFactor` tinyint(1) NOT NULL DEFAULT '0',
  `availabilityCache` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `availabilityCacheTTL` int(10) unsigned DEFAULT NULL,
  `isMailingList` tinyint(1) NOT NULL,
  `defaultProfileImagePHID` varbinary(64) DEFAULT NULL,
  `defaultProfileImageVersion` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userName` (`userName`),
  UNIQUE KEY `phid` (`phid`),
  KEY `realName` (`realName`),
  KEY `key_approved` (`isApproved`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'admin','admin','e0ce350092a4d263759fd9a37bf8dae5','bcrypt:$2y$11$SDFMf3ctbbkjUV1kgTIAKeJcm3XLLWh/u3lJy/VfXO14inhxq3IFm',1494270894,1494270894,NULL,'7bouptcbu4fbvtpcb3dexid4j76hoqvjxp5itieirm3lmo5n5zabedrft7xr3lwymheun2qgla3jt6pdeep273qayovscxixwtwaphsv6wfbgfmwybnpfhjjnayvq5kl7n3rrhblkvhupfy6wrguivauf32bq334nz5edsfz5izub7ofnlbvvf3mnqlcq5lo4e33acbzrveoaubvmlhom3t7gntjh6bvybwimxjd4gyq3eazenvengq45s5jono',0,0,1,1,1,0x336F37693362637766777765346E6C6535357171746B6665693679766F79726569366F6F7A6C6B676D687866646A7A6B736E78626F72376C6733366274613337,0,'{\"until\":null,\"eventPHID\":null,\"availability\":null}',1494530094,0,0x504849442D46494C452D71766279747A63366667756F7A6A7A736E766669,'v1'),(2,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'phab','phab','9852b69a1e2085edcd40a3bd6dbf942b','bcrypt:$2y$11$lNkJi72/5zkHm1YR9ON6SeHoEip96MaJYJ.bG.czHNxgKw.UR1L/O',1494271765,1494273464,NULL,'uxu53io2egjwu6ya2exj4l2vlmqrdwjqwrxpls4wlo57r6aryetvgskla7p2vwt3fcogb63xylymnzv27knpitrjo6gmnujgyegr6lcrbpx3rijwcs76ebwfqmls7khucndod4drqe5y5nkov3panpvvgu2m5jy7x6b35onzwnyofnh5hv7a6si5pvgxax6srur7rxdfsmcyj5wal6hbzjj7m5csw6pppxtfl2evgtyqqso4z7pracgm2sf765q',0,0,0,1,1,0x6A71347478346D7371346F337036626C37613535776E743634617A346E6D7375786D6D6F6B6A6F36706D61757765646E3336326D6D6536616832726461733777,0,'{\"until\":null,\"eventPHID\":null,\"availability\":null}',1494530966,0,0x504849442D46494C452D64656E66796D65336D73646A6C6B657772646A72,'v1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authinvite`
--

DROP TABLE IF EXISTS `user_authinvite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authinvite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) NOT NULL,
  `emailAddress` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `verificationHash` binary(12) NOT NULL,
  `acceptedByPHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_address` (`emailAddress`),
  UNIQUE KEY `key_code` (`verificationHash`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authinvite`
--

LOCK TABLES `user_authinvite` WRITE;
/*!40000 ALTER TABLE `user_authinvite` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_authinvite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_cache`
--

DROP TABLE IF EXISTS `user_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `cacheIndex` binary(12) NOT NULL,
  `cacheKey` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `cacheData` longtext COLLATE utf8mb4_bin NOT NULL,
  `cacheType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_usercache` (`userPHID`,`cacheIndex`),
  KEY `key_cachekey` (`cacheIndex`),
  KEY `key_cachetype` (`cacheType`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_cache`
--

LOCK TABLES `user_cache` WRITE;
/*!40000 ALTER TABLE `user_cache` DISABLE KEYS */;
INSERT INTO `user_cache` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x444F2E6948624A493332596F,'user.preferences.v2','[]','preferences'),(2,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x53686C6A41314E5578556262,'user.message.count.v1','0','message.count'),(3,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x724F47533646683934346463,'user.notification.count.v1','0','notification.count'),(4,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x795F465058756A5439335533,'user.profile.image.uri.v1','fTEASpYBcTK8,http://phabricator.dev:7788/file/data/xx7h43jndnr44vkmdbn5/PHID-FILE-qvbytzc6fguozjzsnvfi/alphanumeric_lato-white_A.png-_335862-0%2C0%2C0%2C0.3.png','user.profile'),(5,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x795F465058756A5439335533,'user.profile.image.uri.v1','fTEASpYBcTK8,http://phabricator.dev:7788/file/data/7bictsdb254w753zplzl/PHID-FILE-denfyme3msdjlkewrdjr/alphanumeric_lato-white_P.png-_d39edb-0%2C0%2C0%2C0.3.png','user.profile'),(6,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x444F2E6948624A493332596F,'user.preferences.v2','[]','preferences'),(7,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x53686C6A41314E5578556262,'user.message.count.v1','0','message.count'),(8,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x724F47533646683934346463,'user.notification.count.v1','0','notification.count');
/*!40000 ALTER TABLE `user_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_configuredcustomfieldstorage`
--

DROP TABLE IF EXISTS `user_configuredcustomfieldstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_configuredcustomfieldstorage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_configuredcustomfieldstorage`
--

LOCK TABLES `user_configuredcustomfieldstorage` WRITE;
/*!40000 ALTER TABLE `user_configuredcustomfieldstorage` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_configuredcustomfieldstorage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_customfieldnumericindex`
--

DROP TABLE IF EXISTS `user_customfieldnumericindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_customfieldnumericindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`),
  KEY `key_find` (`indexKey`,`indexValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_customfieldnumericindex`
--

LOCK TABLES `user_customfieldnumericindex` WRITE;
/*!40000 ALTER TABLE `user_customfieldnumericindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_customfieldnumericindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_customfieldstringindex`
--

DROP TABLE IF EXISTS `user_customfieldstringindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_customfieldstringindex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `indexKey` binary(12) NOT NULL,
  `indexValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_join` (`objectPHID`,`indexKey`,`indexValue`(64)),
  KEY `key_find` (`indexKey`,`indexValue`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_customfieldstringindex`
--

LOCK TABLES `user_customfieldstringindex` WRITE;
/*!40000 ALTER TABLE `user_customfieldstringindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_customfieldstringindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_email`
--

DROP TABLE IF EXISTS `user_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `address` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isVerified` tinyint(1) NOT NULL DEFAULT '0',
  `isPrimary` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `userPHID` (`userPHID`,`isPrimary`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_email`
--

LOCK TABLES `user_email` WRITE;
/*!40000 ALTER TABLE `user_email` DISABLE KEYS */;
INSERT INTO `user_email` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'admin@admin',1,1,'zvovhm7vy2o24yjfhdpnwwtx',1494270894,1494270894),(2,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'phab@phab',1,1,'3yhhttrpvbj4ploxdlkebhxl',1494271765,1494271765);
/*!40000 ALTER TABLE `user_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_externalaccount`
--

DROP TABLE IF EXISTS `user_externalaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_externalaccount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `userPHID` varbinary(64) DEFAULT NULL,
  `accountType` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `accountDomain` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `accountSecret` longtext COLLATE utf8mb4_bin,
  `accountID` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `displayName` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `realName` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `emailVerified` tinyint(1) NOT NULL,
  `accountURI` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_details` (`accountType`,`accountDomain`,`accountID`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_user` (`userPHID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_externalaccount`
--

LOCK TABLES `user_externalaccount` WRITE;
/*!40000 ALTER TABLE `user_externalaccount` DISABLE KEYS */;
INSERT INTO `user_externalaccount` VALUES (1,0x504849442D585553522D6E7662636437716A726677617865693632767933,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'password','self','cfkxupeqxh44jwolooek42cyeexhc5ws','PHID-USER-wtlpjohxmdtz4blbgg5p',NULL,1494270894,1494366415,NULL,NULL,NULL,0,NULL,NULL,'[]'),(2,0x504849442D585553522D3373653562787A65797335373467776A6B766978,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'password','self','u3xifuxzfjfpxjdc5t2rzvey4mcyqtrg','PHID-USER-wx6crxpxwwgfj3nzc7nw',NULL,1494273474,1494366454,NULL,NULL,NULL,0,NULL,NULL,'[]');
/*!40000 ALTER TABLE `user_externalaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_log`
--

DROP TABLE IF EXISTS `user_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actorPHID` varbinary(64) DEFAULT NULL,
  `userPHID` varbinary(64) NOT NULL,
  `action` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `remoteAddr` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `session` binary(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actorPHID` (`actorPHID`,`dateCreated`),
  KEY `userPHID` (`userPHID`,`dateCreated`),
  KEY `action` (`action`,`dateCreated`),
  KEY `dateCreated` (`dateCreated`),
  KEY `remoteAddr` (`remoteAddr`,`dateCreated`),
  KEY `session` (`session`,`dateCreated`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_log`
--

LOCK TABLES `user_log` WRITE;
/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'create','null','\"admin@admin\"','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494270894,1494270894,'172.25.0.1',NULL),(2,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'change-password','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494270894,1494270894,'172.25.0.1',NULL),(3,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'admin','false','true','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494270894,1494270894,'172.25.0.1',NULL),(4,NULL,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494270894,1494270894,'172.25.0.1',0x62653963376635363632363964386431363163613163396262646231313238636166653562323336),(5,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-full','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494270894,1494270894,'172.25.0.1',0x62653963376635363632363964386431363163613163396262646231313238636166653562323336),(6,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'create','null','\"phab@phab\"','{\"host\":\"e0d430c085f5\",\"user_agent\":null}',1494271765,1494271765,'',NULL),(7,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'logout','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494271833,1494271833,'172.25.0.1',0x62653963376635363632363964386431363163613163396262646231313238636166653562323336),(8,NULL,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494271917,1494271917,'172.25.0.1',0x35333434613538383038636635393639353034666331616333353665303038646638316531346163),(9,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-full','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494271917,1494271917,'172.25.0.1',0x35333434613538383038636635393639353034666331616333353665303038646638316531346163),(10,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'logout','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273416,1494273416,'172.25.0.1',0x35333434613538383038636635393639353034666331616333353665303038646638316531346163),(11,NULL,'','login-fail','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273421,1494273421,'172.25.0.1',NULL),(12,NULL,'','login-fail','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273425,1494273425,'172.25.0.1',NULL),(13,NULL,'','login-fail','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273434,1494273434,'172.25.0.1',NULL),(14,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'edit','null','null','{\"host\":\"e0d430c085f5\",\"user_agent\":null}',1494273464,1494273464,'',NULL),(15,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'change-password','null','null','{\"host\":\"e0d430c085f5\",\"user_agent\":null}',1494273464,1494273464,'',NULL),(16,NULL,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273474,1494273474,'172.25.0.1',0x36333336646230303964396666336432313738363936306565646436316266336230323030386432),(17,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-full','null','null','{\"host\":\"c01da50e8e24\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494273474,1494273474,'172.25.0.1',0x36333336646230303964396666336432313738363936306565646436316266336230323030386432),(18,NULL,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366415,1494366415,'172.25.0.1',0x39396235376437383662363238373338636664656337366431396565376365343633623338316361),(19,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'login-full','null','null','{\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366415,1494366415,'172.25.0.1',0x39396235376437383662363238373338636664656337366431396565376365343633623338316361),(20,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'logout','null','null','{\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366420,1494366420,'172.25.0.1',0x39396235376437383662363238373338636664656337366431396565376365343633623338316361),(21,NULL,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366425,1494366425,'172.25.0.1',0x31343130376132373831316138333734313533353566653865346439656263666361636130643863),(22,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-full','null','null','{\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366425,1494366425,'172.25.0.1',0x31343130376132373831316138333734313533353566653865346439656263666361636130643863),(23,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'logout','null','null','{\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366431,1494366431,'172.25.0.1',0x31343130376132373831316138333734313533353566653865346439656263666361636130643863),(24,NULL,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-partial','null','null','{\"session_type\":\"web\",\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366454,1494366454,'172.25.0.1',0x38323964363136343238303163316138646164333433376561663161303533303062666239366363),(25,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'login-full','null','null','{\"host\":\"f84f5e4b7b8e\",\"user_agent\":\"Mozilla\\/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko\\/20100101 Firefox\\/53.0\"}',1494366454,1494366454,'172.25.0.1',0x38323964363136343238303163316138646164333433376561663161303533303062666239366363);
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_nametoken`
--

DROP TABLE IF EXISTS `user_nametoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_nametoken` (
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  KEY `token` (`token`(128)),
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_nametoken`
--

LOCK TABLES `user_nametoken` WRITE;
/*!40000 ALTER TABLE `user_nametoken` DISABLE KEYS */;
INSERT INTO `user_nametoken` VALUES ('admin',1),('phab',2);
/*!40000 ALTER TABLE `user_nametoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) DEFAULT NULL,
  `preferences` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `builtinKey` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_builtin` (`builtinKey`),
  UNIQUE KEY `key_user` (`userPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferencestransaction`
--

DROP TABLE IF EXISTS `user_preferencestransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preferencestransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferencestransaction`
--

LOCK TABLES `user_preferencestransaction` WRITE;
/*!40000 ALTER TABLE `user_preferencestransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preferencestransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `blurb` longtext COLLATE utf8mb4_bin NOT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `icon` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userPHID` (`userPHID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,0x504849442D555345522D77746C706A6F68786D64747A34626C6267673570,'','',NULL,1494270894,1494270894,'person'),(2,0x504849442D555345522D7778366372787078777767666A336E7A63376E77,'','',NULL,1494271766,1494271766,'person');
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_transaction`
--

DROP TABLE IF EXISTS `user_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_transaction`
--

LOCK TABLES `user_transaction` WRITE;
/*!40000 ALTER TABLE `user_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_worker`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_worker` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_worker`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lisk_counter`
--

DROP TABLE IF EXISTS `lisk_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lisk_counter` (
  `counterName` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `counterValue` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`counterName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lisk_counter`
--

LOCK TABLES `lisk_counter` WRITE;
/*!40000 ALTER TABLE `lisk_counter` DISABLE KEYS */;
INSERT INTO `lisk_counter` VALUES ('worker_activetask',11);
/*!40000 ALTER TABLE `lisk_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_activetask`
--

DROP TABLE IF EXISTS `worker_activetask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_activetask` (
  `id` int(10) unsigned NOT NULL,
  `taskClass` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `leaseOwner` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `leaseExpires` int(10) unsigned DEFAULT NULL,
  `failureCount` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  `failureTime` int(10) unsigned DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL,
  `objectPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dataID` (`dataID`),
  KEY `leaseExpires` (`leaseExpires`),
  KEY `leaseOwner` (`leaseOwner`(16)),
  KEY `key_failuretime` (`failureTime`),
  KEY `taskClass` (`taskClass`),
  KEY `leaseOwner_2` (`leaseOwner`,`priority`,`id`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_activetask`
--

LOCK TABLES `worker_activetask` WRITE;
/*!40000 ALTER TABLE `worker_activetask` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_activetask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_archivetask`
--

DROP TABLE IF EXISTS `worker_archivetask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_archivetask` (
  `id` int(10) unsigned NOT NULL,
  `taskClass` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `leaseOwner` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `leaseExpires` int(10) unsigned DEFAULT NULL,
  `failureCount` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned NOT NULL,
  `result` int(10) unsigned NOT NULL,
  `duration` bigint(20) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `priority` int(10) unsigned NOT NULL,
  `objectPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dateCreated` (`dateCreated`),
  KEY `leaseOwner` (`leaseOwner`,`priority`,`id`),
  KEY `key_object` (`objectPHID`),
  KEY `key_modified` (`dateModified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_archivetask`
--

LOCK TABLES `worker_archivetask` WRITE;
/*!40000 ALTER TABLE `worker_archivetask` DISABLE KEYS */;
INSERT INTO `worker_archivetask` VALUES (3,'PhabricatorSearchWorker','46:1494270894:c01da50e8e24:1',1494278094,0,1,0,341875,1494270895,1494270895,4000,NULL),(4,'PhabricatorSearchWorker','46:1494270895:c01da50e8e24:2',1494278095,0,2,0,3990,1494270895,1494270895,4000,NULL),(5,'PhabricatorSearchWorker','46:1494270895:c01da50e8e24:3',1494278095,0,3,0,4712,1494270895,1494270895,4000,NULL),(6,'PhabricatorSearchWorker','46:1494270895:c01da50e8e24:4',1494278095,0,4,0,2454,1494270895,1494270895,4000,NULL),(7,'PhabricatorSearchWorker','73:1494271766:c01da50e8e24:1',1494278966,0,5,0,524362,1494271766,1494271766,4000,NULL),(8,'PhabricatorSearchWorker','73:1494271766:c01da50e8e24:2',1494278966,0,6,0,3829,1494271766,1494271766,4000,NULL),(9,'PhabricatorApplicationTransactionPublishWorker','98:1494272240:c01da50e8e24:1',1494279440,0,7,0,49369,1494272240,1494272240,1000,0x504849442D415554482D796F7474637A6F6E6835723463716A6A6F657975),(10,'PhabricatorSearchWorker','119:1494273465:c01da50e8e24:1',1494280665,0,8,0,54817,1494273465,1494273465,4000,NULL),(11,'PhabricatorSearchWorker','119:1494273465:c01da50e8e24:2',1494280665,0,9,0,2254,1494273465,1494273465,4000,NULL);
/*!40000 ALTER TABLE `worker_archivetask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_bulkjob`
--

DROP TABLE IF EXISTS `worker_bulkjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_bulkjob` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `jobTypeKey` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_type` (`jobTypeKey`),
  KEY `key_author` (`authorPHID`),
  KEY `key_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_bulkjob`
--

LOCK TABLES `worker_bulkjob` WRITE;
/*!40000 ALTER TABLE `worker_bulkjob` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_bulkjob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_bulkjobtransaction`
--

DROP TABLE IF EXISTS `worker_bulkjobtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_bulkjobtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_bulkjobtransaction`
--

LOCK TABLES `worker_bulkjobtransaction` WRITE;
/*!40000 ALTER TABLE `worker_bulkjobtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_bulkjobtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_bulktask`
--

DROP TABLE IF EXISTS `worker_bulktask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_bulktask` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bulkJobPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_job` (`bulkJobPHID`,`status`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_bulktask`
--

LOCK TABLES `worker_bulktask` WRITE;
/*!40000 ALTER TABLE `worker_bulktask` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_bulktask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_taskdata`
--

DROP TABLE IF EXISTS `worker_taskdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_taskdata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_taskdata`
--

LOCK TABLES `worker_taskdata` WRITE;
/*!40000 ALTER TABLE `worker_taskdata` DISABLE KEYS */;
INSERT INTO `worker_taskdata` VALUES (1,'{\"documentPHID\":\"PHID-USER-wtlpjohxmdtz4blbgg5p\",\"parameters\":[]}'),(2,'{\"documentPHID\":\"PHID-USER-wtlpjohxmdtz4blbgg5p\",\"parameters\":[]}'),(3,'{\"documentPHID\":\"PHID-USER-wtlpjohxmdtz4blbgg5p\",\"parameters\":[]}'),(4,'{\"documentPHID\":\"PHID-USER-wtlpjohxmdtz4blbgg5p\",\"parameters\":[]}'),(5,'{\"documentPHID\":\"PHID-USER-wx6crxpxwwgfj3nzc7nw\",\"parameters\":[]}'),(6,'{\"documentPHID\":\"PHID-USER-wx6crxpxwwgfj3nzc7nw\",\"parameters\":[]}'),(7,'{\"objectPHID\":\"PHID-AUTH-yottczonh5r4cqjjoeyu\",\"actorPHID\":\"PHID-USER-wtlpjohxmdtz4blbgg5p\",\"xactionPHIDs\":[],\"state\":{\"parentMessageID\":null,\"disableEmail\":null,\"isNewObject\":false,\"heraldEmailPHIDs\":[],\"heraldForcedEmailPHIDs\":[],\"heraldHeader\":null,\"mailToPHIDs\":[],\"mailCCPHIDs\":[],\"feedNotifyPHIDs\":[],\"feedRelatedPHIDs\":[],\"excludeMailRecipientPHIDs\":[],\"custom\":[],\"custom.encoding\":[]}}'),(8,'{\"documentPHID\":\"PHID-USER-wx6crxpxwwgfj3nzc7nw\",\"parameters\":[]}'),(9,'{\"documentPHID\":\"PHID-USER-wx6crxpxwwgfj3nzc7nw\",\"parameters\":[]}');
/*!40000 ALTER TABLE `worker_taskdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_trigger`
--

DROP TABLE IF EXISTS `worker_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_trigger` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `triggerVersion` int(10) unsigned NOT NULL,
  `clockClass` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `clockProperties` longtext COLLATE utf8mb4_bin NOT NULL,
  `actionClass` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `actionProperties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_trigger` (`triggerVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_trigger`
--

LOCK TABLES `worker_trigger` WRITE;
/*!40000 ALTER TABLE `worker_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_triggerevent`
--

DROP TABLE IF EXISTS `worker_triggerevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_triggerevent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `triggerID` int(10) unsigned NOT NULL,
  `lastEventEpoch` int(10) unsigned DEFAULT NULL,
  `nextEventEpoch` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_trigger` (`triggerID`),
  KEY `key_next` (`nextEventEpoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_triggerevent`
--

LOCK TABLES `worker_triggerevent` WRITE;
/*!40000 ALTER TABLE `worker_triggerevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_triggerevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_xhpast`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_xhpast` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_xhpast`;

--
-- Table structure for table `xhpast_parsetree`
--

DROP TABLE IF EXISTS `xhpast_parsetree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xhpast_parsetree` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authorPHID` varbinary(64) DEFAULT NULL,
  `input` longtext COLLATE utf8mb4_bin NOT NULL,
  `returnCode` int(10) NOT NULL,
  `stdout` longtext COLLATE utf8mb4_bin NOT NULL,
  `stderr` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xhpast_parsetree`
--

LOCK TABLES `xhpast_parsetree` WRITE;
/*!40000 ALTER TABLE `xhpast_parsetree` DISABLE KEYS */;
/*!40000 ALTER TABLE `xhpast_parsetree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_cache`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_cache` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_cache`;

--
-- Table structure for table `cache_general`
--

DROP TABLE IF EXISTS `cache_general`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_general` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cacheKeyHash` binary(12) NOT NULL,
  `cacheKey` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `cacheFormat` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `cacheData` longblob NOT NULL,
  `cacheCreated` int(10) unsigned NOT NULL,
  `cacheExpires` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_cacheKeyHash` (`cacheKeyHash`),
  KEY `key_cacheCreated` (`cacheCreated`),
  KEY `key_ttl` (`cacheExpires`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_general`
--

LOCK TABLES `cache_general` WRITE;
/*!40000 ALTER TABLE `cache_general` DISABLE KEYS */;
INSERT INTO `cache_general` VALUES (1,0x4B33566E74537562384C4C32,'phabricator.setup.issue-keys','raw',0x5B2273656375726974792E73656375726974792E616C7465726E6174652D66696C652D646F6D61696E225D,1494366409,NULL),(2,0x57516171366E375F38666648,'phabricator:user.settings.globals.v1','raw',0x613A303A7B7D,1494436499,NULL),(14,0x426E546C724369423633594E,'phabricator:hmac.key(file.integrity)','raw',0x6166336566326334653138323763326130633661313938623162643536383665636361346161373162343166343631616237383735633863316633356531353936656664373335346362396437353837353966333365363634326362663962326464646431626362393264643435643936393164663434393934383237633161,1494270894,NULL);
/*!40000 ALTER TABLE `cache_general` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_markupcache`
--

DROP TABLE IF EXISTS `cache_markupcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_markupcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cacheKey` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `cacheData` longblob NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cacheKey` (`cacheKey`),
  KEY `dateCreated` (`dateCreated`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_markupcache`
--

LOCK TABLES `cache_markupcache` WRITE;
/*!40000 ALTER TABLE `cache_markupcache` DISABLE KEYS */;
INSERT INTO `cache_markupcache` VALUES (1,'DeGQA004TtV7:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3330343A223C703E57656C636F6D6520746F205068616272696361746F722C20686572652061726520736F6D65206C696E6B7320746F2067657420796F7520737461727465643A3C2F703E0A0A3C756C20636C6173733D2272656D61726B75702D6C697374223E0A3C6C6920636C6173733D2272656D61726B75702D6C6973742D6974656D223E01315A3C2F6C693E0A3C6C6920636C6173733D2272656D61726B75702D6C6973742D6974656D223E01325A3C2F6C693E0A3C6C6920636C6173733D2272656D61726B75702D6C6973742D6974656D223E01335A3C2F6C693E0A3C6C6920636C6173733D2272656D61726B75702D6C6973742D6974656D223E01345A3C2F6C693E0A3C6C6920636C6173733D2272656D61726B75702D6C6973742D6974656D223E01355A3C2F6C693E0A3C2F756C3E223B7D733A373A2273746F72616765223B613A353A7B733A333A2201315A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A38323A223C6120687265663D222F636F6E6669672F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B223E436F6E666967757265205068616272696361746F723C2F613E223B7D733A333A2201325A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A37383A223C6120687265663D222F6775696465732F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B223E517569636B2053746172742047756964653C2F613E223B7D733A333A2201335A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A38333A223C6120687265663D222F646966667573696F6E2F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B223E4372656174652061205265706F7369746F72793C2F613E223B7D733A333A2201345A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A38363A223C6120687265663D222F70656F706C652F696E766974652F73656E642F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B223E496E766974652050656F706C653C2F613E223B7D733A333A2201355A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3132323A223C6120687265663D2268747470733A2F2F747769747465722E636F6D2F7068616272696361746F722F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B222072656C3D226E6F7265666572726572223E466F6C6C6F77207573206F6E20547769747465723C2F613E223B7D7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"c01da50e8e24\"}',1494270894,1494270894),(2,'fo7P4TuH2YZr:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3234303A223C64697620636C6173733D2272656D61726B75702D6E6F7465223E3C7370616E20636C6173733D2272656D61726B75702D6E6F74652D776F7264223E4E4F54453A3C2F7370616E3E20416E7920757365722077686F2063616E2062726F77736520746F207468697320696E7374616C6C26233033393B73206C6F67696E20706167652077696C6C2062652061626C6520746F2072656769737465722061205068616272696361746F72206163636F756E742E20546F2072657374726963742077686F2063616E20726567697374657220616E206163636F756E742C20636F6E6669677572652001315A2E3C2F6469763E223B7D733A373A2273746F72616765223B613A313A7B733A333A2201315A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3130333A223C6120687265663D222F636F6E6669672F656469742F617574682E656D61696C2D646F6D61696E732F2220636C6173733D2272656D61726B75702D6C696E6B22207461726765743D225F626C616E6B223E617574682E656D61696C2D646F6D61696E733C2F613E223B7D7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"c01da50e8e24\"}',1494272043,1494272043),(3,'rVwVLSGl.Y9K:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3234303A223C64697620636C6173733D2272656D61726B75702D7761726E696E67223E4578616D696E6520746865207461626C652062656C6F7720666F7220696E666F726D6174696F6E206F6E20686F772070617373776F7264206861736865732077696C6C2062652073746F72656420696E207468652064617461626173652E3C2F6469763E0A0A0A0A3C64697620636C6173733D2272656D61726B75702D6E6F7465223E596F752063616E2073656C6563742061206D696E696D756D2070617373776F7264206C656E6774682062792073657474696E672001315A20696E20636F6E66696775726174696F6E2E3C2F6469763E223B7D733A373A2273746F72616765223B613A313A7B733A333A2201315A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A36383A223C747420636C6173733D2272656D61726B75702D6D6F6E6F737061636564223E6163636F756E742E6D696E696D756D2D70617373776F72642D6C656E6774683C2F74743E223B7D7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"c01da50e8e24\"}',1494272043,1494272043),(4,'rqtU.8gIqpL3:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A37303A223C703E436F70792D7061737465207468652041504920546F6B656E2062656C6F7720746F206772616E742061636365737320746F20796F7572206163636F756E742E3C2F703E223B7D733A373A2273746F72616765223B613A303A7B7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"f84f5e4b7b8e\"}',1494436259,1494436259),(5,'EMfA0EQ2YdP1:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3132393A223C703E546869732077696C6C20617574686F72697A65207468652072657175657374696E672073637269707420746F20616374206F6E20796F757220626568616C66207065726D616E656E746C792C206C696B6520676976696E67207468652073637269707420796F7572206163636F756E742070617373776F72642E3C2F703E223B7D733A373A2273746F72616765223B613A303A7B7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"f84f5e4b7b8e\"}',1494436259,1494436259),(6,'V6fOZ5b8jBkU:oneoff@16@7VwBk7PApozc',0x613A333A7B733A363A226F7574707574223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A37313A223C703E496620796F75206368616E676520796F7572206D696E642C20796F752063616E207265766F6B65207468697320746F6B656E206C6174657220696E2001315A2E3C2F703E223B7D733A373A2273746F72616765223B613A313A7B733A333A2201315A223B4F3A31343A2250687574696C5361666548544D4C223A313A7B733A32333A220050687574696C5361666548544D4C00636F6E74656E74223B733A3438363A223C7370616E20636C6173733D2272656D61726B75702D6E61762D73657175656E6365223E3C7370616E20636C6173733D22706875692D7461672D7669657720706875692D7461672D747970652D736861646520706875692D7461672D736861646520706875692D7461672D73686164652D6772657920706875692D7461672D69636F6E2D7669657720223E3C7370616E20636C6173733D22706875692D7461672D636F726520223E3C7370616E20636C6173733D2276697375616C2D6F6E6C7920706875692D69636F6E2D7669657720706875692D666F6E742D66612066612D7772656E63682220617269612D68696464656E3D2274727565223E3C2F7370616E3E53657474696E67733C2F7370616E3E3C2F7370616E3E3C7370616E20636C6173733D2272656D61726B75702D6E61762D73657175656E63652D6172726F77223E20E28692203C2F7370616E3E3C7370616E20636C6173733D22706875692D7461672D7669657720706875692D7461672D747970652D736861646520706875692D7461672D736861646520706875692D7461672D73686164652D6772657920223E3C7370616E20636C6173733D22706875692D7461672D636F726520223E436F6E647569742041504920546F6B656E733C2F7370616E3E3C2F7370616E3E3C2F7370616E3E223B7D7D733A383A226D65746164617461223B613A303A7B7D7D,'{\"host\":\"f84f5e4b7b8e\"}',1494436259,1494436259);
/*!40000 ALTER TABLE `cache_markupcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_fact`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_fact` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_fact`;

--
-- Table structure for table `fact_aggregate`
--

DROP TABLE IF EXISTS `fact_aggregate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fact_aggregate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `factType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `valueX` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `factType` (`factType`,`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fact_aggregate`
--

LOCK TABLES `fact_aggregate` WRITE;
/*!40000 ALTER TABLE `fact_aggregate` DISABLE KEYS */;
/*!40000 ALTER TABLE `fact_aggregate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fact_cursor`
--

DROP TABLE IF EXISTS `fact_cursor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fact_cursor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `position` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fact_cursor`
--

LOCK TABLES `fact_cursor` WRITE;
/*!40000 ALTER TABLE `fact_cursor` DISABLE KEYS */;
/*!40000 ALTER TABLE `fact_cursor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fact_raw`
--

DROP TABLE IF EXISTS `fact_raw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fact_raw` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `factType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `objectA` varbinary(64) NOT NULL,
  `valueX` bigint(20) NOT NULL,
  `valueY` bigint(20) NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `objectPHID` (`objectPHID`),
  KEY `factType` (`factType`,`epoch`),
  KEY `factType_2` (`factType`,`objectA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fact_raw`
--

LOCK TABLES `fact_raw` WRITE;
/*!40000 ALTER TABLE `fact_raw` DISABLE KEYS */;
/*!40000 ALTER TABLE `fact_raw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_ponder`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_ponder` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_ponder`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_answer`
--

DROP TABLE IF EXISTS `ponder_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_answer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionID` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `voteCount` int(10) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `key_oneanswerperquestion` (`questionID`,`authorPHID`),
  KEY `questionID` (`questionID`),
  KEY `authorPHID` (`authorPHID`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_answer`
--

LOCK TABLES `ponder_answer` WRITE;
/*!40000 ALTER TABLE `ponder_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_answertransaction`
--

DROP TABLE IF EXISTS `ponder_answertransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_answertransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_answertransaction`
--

LOCK TABLES `ponder_answertransaction` WRITE;
/*!40000 ALTER TABLE `ponder_answertransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_answertransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_answertransaction_comment`
--

DROP TABLE IF EXISTS `ponder_answertransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_answertransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_answertransaction_comment`
--

LOCK TABLES `ponder_answertransaction_comment` WRITE;
/*!40000 ALTER TABLE `ponder_answertransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_answertransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_question`
--

DROP TABLE IF EXISTS `ponder_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin,
  `answerCount` int(10) unsigned NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `answerWiki` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `authorPHID` (`authorPHID`),
  KEY `status` (`status`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_question`
--

LOCK TABLES `ponder_question` WRITE;
/*!40000 ALTER TABLE `ponder_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_questiontransaction`
--

DROP TABLE IF EXISTS `ponder_questiontransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_questiontransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_questiontransaction`
--

LOCK TABLES `ponder_questiontransaction` WRITE;
/*!40000 ALTER TABLE `ponder_questiontransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_questiontransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponder_questiontransaction_comment`
--

DROP TABLE IF EXISTS `ponder_questiontransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponder_questiontransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponder_questiontransaction_comment`
--

LOCK TABLES `ponder_questiontransaction_comment` WRITE;
/*!40000 ALTER TABLE `ponder_questiontransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponder_questiontransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_xhprof`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_xhprof` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_xhprof`;

--
-- Table structure for table `xhprof_sample`
--

DROP TABLE IF EXISTS `xhprof_sample`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xhprof_sample` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filePHID` varbinary(64) NOT NULL,
  `sampleRate` int(10) unsigned NOT NULL,
  `usTotal` bigint(20) unsigned NOT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `requestPath` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `userPHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filePHID` (`filePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xhprof_sample`
--

LOCK TABLES `xhprof_sample` WRITE;
/*!40000 ALTER TABLE `xhprof_sample` DISABLE KEYS */;
/*!40000 ALTER TABLE `xhprof_sample` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_pholio`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_pholio` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_pholio`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pholio_image`
--

DROP TABLE IF EXISTS `pholio_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pholio_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `mockID` int(10) unsigned DEFAULT NULL,
  `filePHID` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isObsolete` tinyint(1) NOT NULL DEFAULT '0',
  `replacesImagePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyPHID` (`phid`),
  KEY `mockID` (`mockID`,`isObsolete`,`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pholio_image`
--

LOCK TABLES `pholio_image` WRITE;
/*!40000 ALTER TABLE `pholio_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `pholio_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pholio_mock`
--

DROP TABLE IF EXISTS `pholio_mock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pholio_mock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `originalName` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `coverPHID` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `status` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  KEY `authorPHID` (`authorPHID`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pholio_mock`
--

LOCK TABLES `pholio_mock` WRITE;
/*!40000 ALTER TABLE `pholio_mock` DISABLE KEYS */;
/*!40000 ALTER TABLE `pholio_mock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pholio_transaction`
--

DROP TABLE IF EXISTS `pholio_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pholio_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pholio_transaction`
--

LOCK TABLES `pholio_transaction` WRITE;
/*!40000 ALTER TABLE `pholio_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pholio_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pholio_transaction_comment`
--

DROP TABLE IF EXISTS `pholio_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pholio_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `imageID` int(10) unsigned DEFAULT NULL,
  `x` int(10) unsigned DEFAULT NULL,
  `y` int(10) unsigned DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`),
  UNIQUE KEY `key_draft` (`authorPHID`,`imageID`,`transactionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pholio_transaction_comment`
--

LOCK TABLES `pholio_transaction_comment` WRITE;
/*!40000 ALTER TABLE `pholio_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `pholio_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_conpherence`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_conpherence` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_conpherence`;

--
-- Table structure for table `conpherence_index`
--

DROP TABLE IF EXISTS `conpherence_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `threadPHID` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) NOT NULL,
  `previousTransactionPHID` varbinary(64) DEFAULT NULL,
  `corpus` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_transaction` (`transactionPHID`),
  UNIQUE KEY `key_previous` (`previousTransactionPHID`),
  KEY `key_thread` (`threadPHID`),
  FULLTEXT KEY `key_corpus` (`corpus`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_index`
--

LOCK TABLES `conpherence_index` WRITE;
/*!40000 ALTER TABLE `conpherence_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conpherence_participant`
--

DROP TABLE IF EXISTS `conpherence_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_participant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `participantPHID` varbinary(64) NOT NULL,
  `conpherencePHID` varbinary(64) NOT NULL,
  `participationStatus` int(10) unsigned NOT NULL DEFAULT '0',
  `dateTouched` int(10) unsigned NOT NULL,
  `behindTransactionPHID` varbinary(64) NOT NULL,
  `seenMessageCount` bigint(20) unsigned NOT NULL,
  `settings` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `conpherencePHID` (`conpherencePHID`,`participantPHID`),
  KEY `unreadCount` (`participantPHID`,`participationStatus`),
  KEY `participationIndex` (`participantPHID`,`dateTouched`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_participant`
--

LOCK TABLES `conpherence_participant` WRITE;
/*!40000 ALTER TABLE `conpherence_participant` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conpherence_thread`
--

DROP TABLE IF EXISTS `conpherence_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_thread` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `messageCount` bigint(20) unsigned NOT NULL,
  `recentParticipantPHIDs` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `joinPolicy` varbinary(64) NOT NULL,
  `mailKey` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `topic` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_thread`
--

LOCK TABLES `conpherence_thread` WRITE;
/*!40000 ALTER TABLE `conpherence_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conpherence_threadtitle_ngrams`
--

DROP TABLE IF EXISTS `conpherence_threadtitle_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_threadtitle_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_threadtitle_ngrams`
--

LOCK TABLES `conpherence_threadtitle_ngrams` WRITE;
/*!40000 ALTER TABLE `conpherence_threadtitle_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_threadtitle_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conpherence_transaction`
--

DROP TABLE IF EXISTS `conpherence_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_transaction`
--

LOCK TABLES `conpherence_transaction` WRITE;
/*!40000 ALTER TABLE `conpherence_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conpherence_transaction_comment`
--

DROP TABLE IF EXISTS `conpherence_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conpherence_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `conpherencePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`),
  UNIQUE KEY `key_draft` (`authorPHID`,`conpherencePHID`,`transactionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conpherence_transaction_comment`
--

LOCK TABLES `conpherence_transaction_comment` WRITE;
/*!40000 ALTER TABLE `conpherence_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `conpherence_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_config`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_config` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_config`;

--
-- Table structure for table `config_entry`
--

DROP TABLE IF EXISTS `config_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `namespace` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `configKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `value` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_name` (`namespace`,`configKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_entry`
--

LOCK TABLES `config_entry` WRITE;
/*!40000 ALTER TABLE `config_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_manualactivity`
--

DROP TABLE IF EXISTS `config_manualactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_manualactivity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activityType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_type` (`activityType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_manualactivity`
--

LOCK TABLES `config_manualactivity` WRITE;
/*!40000 ALTER TABLE `config_manualactivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_manualactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_transaction`
--

DROP TABLE IF EXISTS `config_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_transaction`
--

LOCK TABLES `config_transaction` WRITE;
/*!40000 ALTER TABLE `config_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_token`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_token` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_token`;

--
-- Table structure for table `token_count`
--

DROP TABLE IF EXISTS `token_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token_count` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `tokenCount` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_objectPHID` (`objectPHID`),
  KEY `key_count` (`tokenCount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_count`
--

LOCK TABLES `token_count` WRITE;
/*!40000 ALTER TABLE `token_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_given`
--

DROP TABLE IF EXISTS `token_given`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token_given` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `tokenPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_all` (`objectPHID`,`authorPHID`),
  KEY `key_author` (`authorPHID`),
  KEY `key_token` (`tokenPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_given`
--

LOCK TABLES `token_given` WRITE;
/*!40000 ALTER TABLE `token_given` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_given` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_token`
--

DROP TABLE IF EXISTS `token_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `flavor` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `builtinKey` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `tokenImagePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_builtin` (`builtinKey`),
  KEY `key_creator` (`creatorPHID`,`dateModified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_token`
--

LOCK TABLES `token_token` WRITE;
/*!40000 ALTER TABLE `token_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_releeph`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_releeph` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_releeph`;

--
-- Table structure for table `releeph_branch`
--

DROP TABLE IF EXISTS `releeph_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `basename` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `releephProjectID` int(10) unsigned NOT NULL,
  `createdByUserPHID` varbinary(64) NOT NULL,
  `cutPointCommitPHID` varbinary(64) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `symbolicName` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `releephProjectID_2` (`releephProjectID`,`basename`),
  UNIQUE KEY `releephProjectID_name` (`releephProjectID`,`name`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `releephProjectID` (`releephProjectID`,`symbolicName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_branch`
--

LOCK TABLES `releeph_branch` WRITE;
/*!40000 ALTER TABLE `releeph_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_branchtransaction`
--

DROP TABLE IF EXISTS `releeph_branchtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_branchtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_branchtransaction`
--

LOCK TABLES `releeph_branchtransaction` WRITE;
/*!40000 ALTER TABLE `releeph_branchtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_branchtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_producttransaction`
--

DROP TABLE IF EXISTS `releeph_producttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_producttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_producttransaction`
--

LOCK TABLES `releeph_producttransaction` WRITE;
/*!40000 ALTER TABLE `releeph_producttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_producttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_project`
--

DROP TABLE IF EXISTS `releeph_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_project` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `trunkBranch` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `repositoryPHID` varbinary(64) NOT NULL,
  `createdByUserPHID` varbinary(64) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projectName` (`name`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_project`
--

LOCK TABLES `releeph_project` WRITE;
/*!40000 ALTER TABLE `releeph_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_request`
--

DROP TABLE IF EXISTS `releeph_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `phid` varbinary(64) NOT NULL,
  `branchID` int(10) unsigned NOT NULL,
  `requestUserPHID` varbinary(64) NOT NULL,
  `requestCommitPHID` varbinary(64) DEFAULT NULL,
  `commitIdentifier` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `commitPHID` varbinary(64) DEFAULT NULL,
  `pickStatus` int(10) unsigned DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_bin NOT NULL,
  `userIntents` longtext COLLATE utf8mb4_bin,
  `inBranch` tinyint(1) NOT NULL DEFAULT '0',
  `mailKey` binary(20) NOT NULL,
  `requestedObjectPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `requestIdentifierBranch` (`requestCommitPHID`,`branchID`),
  KEY `branchID` (`branchID`),
  KEY `key_requestedObject` (`requestedObjectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_request`
--

LOCK TABLES `releeph_request` WRITE;
/*!40000 ALTER TABLE `releeph_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_requesttransaction`
--

DROP TABLE IF EXISTS `releeph_requesttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_requesttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_requesttransaction`
--

LOCK TABLES `releeph_requesttransaction` WRITE;
/*!40000 ALTER TABLE `releeph_requesttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_requesttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releeph_requesttransaction_comment`
--

DROP TABLE IF EXISTS `releeph_requesttransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releeph_requesttransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releeph_requesttransaction_comment`
--

LOCK TABLES `releeph_requesttransaction_comment` WRITE;
/*!40000 ALTER TABLE `releeph_requesttransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `releeph_requesttransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phlux`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phlux` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phlux`;

--
-- Table structure for table `phlux_transaction`
--

DROP TABLE IF EXISTS `phlux_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phlux_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phlux_transaction`
--

LOCK TABLES `phlux_transaction` WRITE;
/*!40000 ALTER TABLE `phlux_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phlux_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phlux_variable`
--

DROP TABLE IF EXISTS `phlux_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phlux_variable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `variableKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `variableValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_key` (`variableKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phlux_variable`
--

LOCK TABLES `phlux_variable` WRITE;
/*!40000 ALTER TABLE `phlux_variable` DISABLE KEYS */;
/*!40000 ALTER TABLE `phlux_variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phortune`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phortune` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phortune`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_account`
--

DROP TABLE IF EXISTS `phortune_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_account`
--

LOCK TABLES `phortune_account` WRITE;
/*!40000 ALTER TABLE `phortune_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_accounttransaction`
--

DROP TABLE IF EXISTS `phortune_accounttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_accounttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_accounttransaction`
--

LOCK TABLES `phortune_accounttransaction` WRITE;
/*!40000 ALTER TABLE `phortune_accounttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_accounttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_cart`
--

DROP TABLE IF EXISTS `phortune_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_cart` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `accountPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `cartClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `merchantPHID` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `subscriptionPHID` varbinary(64) DEFAULT NULL,
  `isInvoice` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_account` (`accountPHID`),
  KEY `key_merchant` (`merchantPHID`),
  KEY `key_subscription` (`subscriptionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_cart`
--

LOCK TABLES `phortune_cart` WRITE;
/*!40000 ALTER TABLE `phortune_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_carttransaction`
--

DROP TABLE IF EXISTS `phortune_carttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_carttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_carttransaction`
--

LOCK TABLES `phortune_carttransaction` WRITE;
/*!40000 ALTER TABLE `phortune_carttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_carttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_charge`
--

DROP TABLE IF EXISTS `phortune_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_charge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `accountPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `cartPHID` varbinary(64) NOT NULL,
  `paymentMethodPHID` varbinary(64) DEFAULT NULL,
  `amountAsCurrency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `merchantPHID` varbinary(64) NOT NULL,
  `providerPHID` varbinary(64) NOT NULL,
  `amountRefundedAsCurrency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `refundingPHID` varbinary(64) DEFAULT NULL,
  `refundedChargePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_cart` (`cartPHID`),
  KEY `key_account` (`accountPHID`),
  KEY `key_merchant` (`merchantPHID`),
  KEY `key_provider` (`providerPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_charge`
--

LOCK TABLES `phortune_charge` WRITE;
/*!40000 ALTER TABLE `phortune_charge` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_charge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_merchant`
--

DROP TABLE IF EXISTS `phortune_merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_merchant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `contactInfo` longtext COLLATE utf8mb4_bin NOT NULL,
  `profileImagePHID` varbinary(64) DEFAULT NULL,
  `invoiceEmail` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `invoiceFooter` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_merchant`
--

LOCK TABLES `phortune_merchant` WRITE;
/*!40000 ALTER TABLE `phortune_merchant` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_merchant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_merchanttransaction`
--

DROP TABLE IF EXISTS `phortune_merchanttransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_merchanttransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_merchanttransaction`
--

LOCK TABLES `phortune_merchanttransaction` WRITE;
/*!40000 ALTER TABLE `phortune_merchanttransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_merchanttransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_paymentmethod`
--

DROP TABLE IF EXISTS `phortune_paymentmethod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_paymentmethod` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `accountPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `brand` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `expires` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `lastFourDigits` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `merchantPHID` varbinary(64) NOT NULL,
  `providerPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_account` (`accountPHID`,`status`),
  KEY `key_merchant` (`merchantPHID`,`accountPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_paymentmethod`
--

LOCK TABLES `phortune_paymentmethod` WRITE;
/*!40000 ALTER TABLE `phortune_paymentmethod` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_paymentmethod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_paymentproviderconfig`
--

DROP TABLE IF EXISTS `phortune_paymentproviderconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_paymentproviderconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `merchantPHID` varbinary(64) NOT NULL,
  `providerClassKey` binary(12) NOT NULL,
  `providerClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isEnabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_merchant` (`merchantPHID`,`providerClassKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_paymentproviderconfig`
--

LOCK TABLES `phortune_paymentproviderconfig` WRITE;
/*!40000 ALTER TABLE `phortune_paymentproviderconfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_paymentproviderconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_paymentproviderconfigtransaction`
--

DROP TABLE IF EXISTS `phortune_paymentproviderconfigtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_paymentproviderconfigtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_paymentproviderconfigtransaction`
--

LOCK TABLES `phortune_paymentproviderconfigtransaction` WRITE;
/*!40000 ALTER TABLE `phortune_paymentproviderconfigtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_paymentproviderconfigtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_product`
--

DROP TABLE IF EXISTS `phortune_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `productClassKey` binary(12) NOT NULL,
  `productClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `productRefKey` binary(12) NOT NULL,
  `productRef` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_product` (`productClassKey`,`productRefKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_product`
--

LOCK TABLES `phortune_product` WRITE;
/*!40000 ALTER TABLE `phortune_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_purchase`
--

DROP TABLE IF EXISTS `phortune_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_purchase` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `productPHID` varbinary(64) NOT NULL,
  `accountPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `cartPHID` varbinary(64) DEFAULT NULL,
  `basePriceAsCurrency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_cart` (`cartPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_purchase`
--

LOCK TABLES `phortune_purchase` WRITE;
/*!40000 ALTER TABLE `phortune_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phortune_subscription`
--

DROP TABLE IF EXISTS `phortune_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phortune_subscription` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `accountPHID` varbinary(64) NOT NULL,
  `merchantPHID` varbinary(64) NOT NULL,
  `triggerPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `subscriptionClassKey` binary(12) NOT NULL,
  `subscriptionClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `subscriptionRefKey` binary(12) NOT NULL,
  `subscriptionRef` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `defaultPaymentMethodPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_subscription` (`subscriptionClassKey`,`subscriptionRefKey`),
  KEY `key_account` (`accountPHID`),
  KEY `key_merchant` (`merchantPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phortune_subscription`
--

LOCK TABLES `phortune_subscription` WRITE;
/*!40000 ALTER TABLE `phortune_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `phortune_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phrequent`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phrequent` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phrequent`;

--
-- Table structure for table `phrequent_usertime`
--

DROP TABLE IF EXISTS `phrequent_usertime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phrequent_usertime` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) DEFAULT NULL,
  `note` longtext COLLATE utf8mb4_bin,
  `dateStarted` int(10) unsigned NOT NULL,
  `dateEnded` int(10) unsigned DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phrequent_usertime`
--

LOCK TABLES `phrequent_usertime` WRITE;
/*!40000 ALTER TABLE `phrequent_usertime` DISABLE KEYS */;
/*!40000 ALTER TABLE `phrequent_usertime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_diviner`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_diviner` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_diviner`;

--
-- Table structure for table `diviner_liveatom`
--

DROP TABLE IF EXISTS `diviner_liveatom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diviner_liveatom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `symbolPHID` varbinary(64) NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `atomData` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbolPHID` (`symbolPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diviner_liveatom`
--

LOCK TABLES `diviner_liveatom` WRITE;
/*!40000 ALTER TABLE `diviner_liveatom` DISABLE KEYS */;
/*!40000 ALTER TABLE `diviner_liveatom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diviner_livebook`
--

DROP TABLE IF EXISTS `diviner_livebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diviner_livebook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `repositoryPHID` varbinary(64) DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `configurationData` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diviner_livebook`
--

LOCK TABLES `diviner_livebook` WRITE;
/*!40000 ALTER TABLE `diviner_livebook` DISABLE KEYS */;
/*!40000 ALTER TABLE `diviner_livebook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diviner_livebooktransaction`
--

DROP TABLE IF EXISTS `diviner_livebooktransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diviner_livebooktransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diviner_livebooktransaction`
--

LOCK TABLES `diviner_livebooktransaction` WRITE;
/*!40000 ALTER TABLE `diviner_livebooktransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `diviner_livebooktransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diviner_livesymbol`
--

DROP TABLE IF EXISTS `diviner_livesymbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diviner_livesymbol` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `bookPHID` varbinary(64) NOT NULL,
  `repositoryPHID` varbinary(64) DEFAULT NULL,
  `context` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `atomIndex` int(10) unsigned NOT NULL,
  `identityHash` binary(12) NOT NULL,
  `graphHash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `title` longtext COLLATE utf8mb4_bin,
  `titleSlugHash` binary(12) DEFAULT NULL,
  `groupName` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `summary` longtext COLLATE utf8mb4_bin,
  `isDocumentable` tinyint(1) NOT NULL,
  `nodeHash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identityHash` (`identityHash`),
  UNIQUE KEY `phid` (`phid`),
  UNIQUE KEY `graphHash` (`graphHash`),
  UNIQUE KEY `nodeHash` (`nodeHash`),
  KEY `key_slug` (`titleSlugHash`),
  KEY `bookPHID` (`bookPHID`,`type`,`name`(64),`context`(64),`atomIndex`),
  KEY `name` (`name`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diviner_livesymbol`
--

LOCK TABLES `diviner_livesymbol` WRITE;
/*!40000 ALTER TABLE `diviner_livesymbol` DISABLE KEYS */;
/*!40000 ALTER TABLE `diviner_livesymbol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_auth`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_auth` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_auth`;

--
-- Table structure for table `auth_factorconfig`
--

DROP TABLE IF EXISTS `auth_factorconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_factorconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `userPHID` varbinary(64) NOT NULL,
  `factorKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `factorName` longtext COLLATE utf8mb4_bin NOT NULL,
  `factorSecret` longtext COLLATE utf8mb4_bin NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_user` (`userPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_factorconfig`
--

LOCK TABLES `auth_factorconfig` WRITE;
/*!40000 ALTER TABLE `auth_factorconfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_factorconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_hmackey`
--

DROP TABLE IF EXISTS `auth_hmackey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_hmackey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyName` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `keyValue` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`keyName`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_hmackey`
--

LOCK TABLES `auth_hmackey` WRITE;
/*!40000 ALTER TABLE `auth_hmackey` DISABLE KEYS */;
INSERT INTO `auth_hmackey` VALUES (1,'file.integrity','af3ef2c4e1827c2a0c6a198b1bd5686ecca4aa71b41f461ab7875c8c1f35e1596efd7354cb9d758759f33e6642cbf9b2dddd1bcb92dd45d9691df44994827c1a',1494270894,1494270894);
/*!40000 ALTER TABLE `auth_hmackey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_providerconfig`
--

DROP TABLE IF EXISTS `auth_providerconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_providerconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `providerClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `providerType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `providerDomain` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `isEnabled` tinyint(1) NOT NULL,
  `shouldAllowLogin` tinyint(1) NOT NULL,
  `shouldAllowRegistration` tinyint(1) NOT NULL,
  `shouldAllowLink` tinyint(1) NOT NULL,
  `shouldAllowUnlink` tinyint(1) NOT NULL,
  `shouldTrustEmails` tinyint(1) NOT NULL DEFAULT '0',
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `shouldAutoLogin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_provider` (`providerType`,`providerDomain`),
  KEY `key_class` (`providerClass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_providerconfig`
--

LOCK TABLES `auth_providerconfig` WRITE;
/*!40000 ALTER TABLE `auth_providerconfig` DISABLE KEYS */;
INSERT INTO `auth_providerconfig` VALUES (1,0x504849442D415554482D796F7474637A6F6E6835723463716A6A6F657975,'PhabricatorPasswordAuthProvider','password','self',1,1,1,1,1,0,'[]',1494272240,1494272240,0);
/*!40000 ALTER TABLE `auth_providerconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_providerconfigtransaction`
--

DROP TABLE IF EXISTS `auth_providerconfigtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_providerconfigtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_providerconfigtransaction`
--

LOCK TABLES `auth_providerconfigtransaction` WRITE;
/*!40000 ALTER TABLE `auth_providerconfigtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_providerconfigtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_sshkey`
--

DROP TABLE IF EXISTS `auth_sshkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_sshkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `keyType` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `keyBody` longtext COLLATE utf8mb4_bin NOT NULL,
  `keyComment` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `keyIndex` binary(12) NOT NULL,
  `isTrusted` tinyint(1) NOT NULL,
  `isActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_activeunique` (`keyIndex`,`isActive`),
  KEY `key_object` (`objectPHID`),
  KEY `key_active` (`isActive`,`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_sshkey`
--

LOCK TABLES `auth_sshkey` WRITE;
/*!40000 ALTER TABLE `auth_sshkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_sshkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_sshkeytransaction`
--

DROP TABLE IF EXISTS `auth_sshkeytransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_sshkeytransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_sshkeytransaction`
--

LOCK TABLES `auth_sshkeytransaction` WRITE;
/*!40000 ALTER TABLE `auth_sshkeytransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_sshkeytransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_temporarytoken`
--

DROP TABLE IF EXISTS `auth_temporarytoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_temporarytoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tokenResource` varbinary(64) NOT NULL,
  `tokenType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `tokenExpires` int(10) unsigned NOT NULL,
  `tokenCode` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `userPHID` varbinary(64) DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_token` (`tokenResource`,`tokenType`,`tokenCode`),
  KEY `key_expires` (`tokenExpires`),
  KEY `key_user` (`userPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_temporarytoken`
--

LOCK TABLES `auth_temporarytoken` WRITE;
/*!40000 ALTER TABLE `auth_temporarytoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_temporarytoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_doorkeeper`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_doorkeeper` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_doorkeeper`;

--
-- Table structure for table `doorkeeper_externalobject`
--

DROP TABLE IF EXISTS `doorkeeper_externalobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkeeper_externalobject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `objectKey` binary(12) NOT NULL,
  `applicationType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `applicationDomain` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `objectType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `objectID` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `objectURI` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `importerPHID` varbinary(64) DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_object` (`objectKey`),
  KEY `key_full` (`applicationType`,`applicationDomain`,`objectType`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doorkeeper_externalobject`
--

LOCK TABLES `doorkeeper_externalobject` WRITE;
/*!40000 ALTER TABLE `doorkeeper_externalobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `doorkeeper_externalobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_legalpad`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_legalpad` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_legalpad`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalpad_document`
--

DROP TABLE IF EXISTS `legalpad_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legalpad_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `contributorCount` int(10) unsigned NOT NULL DEFAULT '0',
  `recentContributorPHIDs` longtext COLLATE utf8mb4_bin NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `versions` int(10) unsigned NOT NULL DEFAULT '0',
  `documentBodyPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `signatureType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `preamble` longtext COLLATE utf8mb4_bin NOT NULL,
  `requireSignature` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_creator` (`creatorPHID`,`dateModified`),
  KEY `key_required` (`requireSignature`,`dateModified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalpad_document`
--

LOCK TABLES `legalpad_document` WRITE;
/*!40000 ALTER TABLE `legalpad_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `legalpad_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalpad_documentbody`
--

DROP TABLE IF EXISTS `legalpad_documentbody`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legalpad_documentbody` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `documentPHID` varbinary(64) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `text` longtext COLLATE utf8mb4_bin,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_document` (`documentPHID`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalpad_documentbody`
--

LOCK TABLES `legalpad_documentbody` WRITE;
/*!40000 ALTER TABLE `legalpad_documentbody` DISABLE KEYS */;
/*!40000 ALTER TABLE `legalpad_documentbody` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalpad_documentsignature`
--

DROP TABLE IF EXISTS `legalpad_documentsignature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legalpad_documentsignature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `documentPHID` varbinary(64) NOT NULL,
  `documentVersion` int(10) unsigned NOT NULL DEFAULT '0',
  `signatureType` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `signerPHID` varbinary(64) DEFAULT NULL,
  `signerName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `signerEmail` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `signatureData` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `secretKey` binary(20) NOT NULL,
  `verified` tinyint(1) DEFAULT '0',
  `isExemption` tinyint(1) NOT NULL DEFAULT '0',
  `exemptionPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `key_signer` (`signerPHID`,`dateModified`),
  KEY `secretKey` (`secretKey`),
  KEY `key_document` (`documentPHID`,`signerPHID`,`documentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalpad_documentsignature`
--

LOCK TABLES `legalpad_documentsignature` WRITE;
/*!40000 ALTER TABLE `legalpad_documentsignature` DISABLE KEYS */;
/*!40000 ALTER TABLE `legalpad_documentsignature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalpad_transaction`
--

DROP TABLE IF EXISTS `legalpad_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legalpad_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalpad_transaction`
--

LOCK TABLES `legalpad_transaction` WRITE;
/*!40000 ALTER TABLE `legalpad_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `legalpad_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalpad_transaction_comment`
--

DROP TABLE IF EXISTS `legalpad_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legalpad_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `documentID` int(10) unsigned DEFAULT NULL,
  `lineNumber` int(10) unsigned NOT NULL,
  `lineLength` int(10) unsigned NOT NULL,
  `fixedState` varchar(12) COLLATE utf8mb4_bin DEFAULT NULL,
  `hasReplies` tinyint(1) NOT NULL,
  `replyToCommentPHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`),
  UNIQUE KEY `key_draft` (`authorPHID`,`documentID`,`transactionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalpad_transaction_comment`
--

LOCK TABLES `legalpad_transaction_comment` WRITE;
/*!40000 ALTER TABLE `legalpad_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `legalpad_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_policy`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_policy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_policy`;

--
-- Table structure for table `policy`
--

DROP TABLE IF EXISTS `policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `policy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `rules` longtext COLLATE utf8mb4_bin NOT NULL,
  `defaultAction` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policy`
--

LOCK TABLES `policy` WRITE;
/*!40000 ALTER TABLE `policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_nuance`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_nuance` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_nuance`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_importcursordata`
--

DROP TABLE IF EXISTS `nuance_importcursordata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_importcursordata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `sourcePHID` varbinary(64) NOT NULL,
  `cursorKey` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `cursorType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_source` (`sourcePHID`,`cursorKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_importcursordata`
--

LOCK TABLES `nuance_importcursordata` WRITE;
/*!40000 ALTER TABLE `nuance_importcursordata` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_importcursordata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_item`
--

DROP TABLE IF EXISTS `nuance_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `ownerPHID` varbinary(64) DEFAULT NULL,
  `requestorPHID` varbinary(64) DEFAULT NULL,
  `sourcePHID` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `queuePHID` varbinary(64) DEFAULT NULL,
  `itemType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `itemKey` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `itemContainerKey` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_item` (`sourcePHID`,`itemKey`),
  KEY `key_source` (`sourcePHID`,`status`),
  KEY `key_owner` (`ownerPHID`,`status`),
  KEY `key_requestor` (`requestorPHID`,`status`),
  KEY `key_queue` (`queuePHID`,`status`),
  KEY `key_container` (`sourcePHID`,`itemContainerKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_item`
--

LOCK TABLES `nuance_item` WRITE;
/*!40000 ALTER TABLE `nuance_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_itemcommand`
--

DROP TABLE IF EXISTS `nuance_itemcommand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_itemcommand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemPHID` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `command` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `parameters` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_item` (`itemPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_itemcommand`
--

LOCK TABLES `nuance_itemcommand` WRITE;
/*!40000 ALTER TABLE `nuance_itemcommand` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_itemcommand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_itemtransaction`
--

DROP TABLE IF EXISTS `nuance_itemtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_itemtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_itemtransaction`
--

LOCK TABLES `nuance_itemtransaction` WRITE;
/*!40000 ALTER TABLE `nuance_itemtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_itemtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_itemtransaction_comment`
--

DROP TABLE IF EXISTS `nuance_itemtransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_itemtransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_itemtransaction_comment`
--

LOCK TABLES `nuance_itemtransaction_comment` WRITE;
/*!40000 ALTER TABLE `nuance_itemtransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_itemtransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_queue`
--

DROP TABLE IF EXISTS `nuance_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_queue`
--

LOCK TABLES `nuance_queue` WRITE;
/*!40000 ALTER TABLE `nuance_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_queuetransaction`
--

DROP TABLE IF EXISTS `nuance_queuetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_queuetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_queuetransaction`
--

LOCK TABLES `nuance_queuetransaction` WRITE;
/*!40000 ALTER TABLE `nuance_queuetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_queuetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_queuetransaction_comment`
--

DROP TABLE IF EXISTS `nuance_queuetransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_queuetransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_queuetransaction_comment`
--

LOCK TABLES `nuance_queuetransaction_comment` WRITE;
/*!40000 ALTER TABLE `nuance_queuetransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_queuetransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_source`
--

DROP TABLE IF EXISTS `nuance_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_source` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `defaultQueuePHID` varbinary(64) NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_type` (`type`,`dateModified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_source`
--

LOCK TABLES `nuance_source` WRITE;
/*!40000 ALTER TABLE `nuance_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_sourcename_ngrams`
--

DROP TABLE IF EXISTS `nuance_sourcename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_sourcename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_sourcename_ngrams`
--

LOCK TABLES `nuance_sourcename_ngrams` WRITE;
/*!40000 ALTER TABLE `nuance_sourcename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_sourcename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_sourcetransaction`
--

DROP TABLE IF EXISTS `nuance_sourcetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_sourcetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_sourcetransaction`
--

LOCK TABLES `nuance_sourcetransaction` WRITE;
/*!40000 ALTER TABLE `nuance_sourcetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_sourcetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nuance_sourcetransaction_comment`
--

DROP TABLE IF EXISTS `nuance_sourcetransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nuance_sourcetransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nuance_sourcetransaction_comment`
--

LOCK TABLES `nuance_sourcetransaction_comment` WRITE;
/*!40000 ALTER TABLE `nuance_sourcetransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `nuance_sourcetransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_passphrase`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_passphrase` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_passphrase`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passphrase_credential`
--

DROP TABLE IF EXISTS `passphrase_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passphrase_credential` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `credentialType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `providesType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `secretID` int(10) unsigned DEFAULT NULL,
  `isDestroyed` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isLocked` tinyint(1) NOT NULL,
  `allowConduit` tinyint(1) NOT NULL DEFAULT '0',
  `authorPHID` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_secret` (`secretID`),
  KEY `key_type` (`credentialType`),
  KEY `key_provides` (`providesType`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passphrase_credential`
--

LOCK TABLES `passphrase_credential` WRITE;
/*!40000 ALTER TABLE `passphrase_credential` DISABLE KEYS */;
/*!40000 ALTER TABLE `passphrase_credential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passphrase_credentialtransaction`
--

DROP TABLE IF EXISTS `passphrase_credentialtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passphrase_credentialtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passphrase_credentialtransaction`
--

LOCK TABLES `passphrase_credentialtransaction` WRITE;
/*!40000 ALTER TABLE `passphrase_credentialtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `passphrase_credentialtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passphrase_secret`
--

DROP TABLE IF EXISTS `passphrase_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passphrase_secret` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `secretData` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passphrase_secret`
--

LOCK TABLES `passphrase_secret` WRITE;
/*!40000 ALTER TABLE `passphrase_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `passphrase_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phragment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phragment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phragment`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phragment_fragment`
--

DROP TABLE IF EXISTS `phragment_fragment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phragment_fragment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `path` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `latestVersionPHID` varbinary(64) DEFAULT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phragment_fragment`
--

LOCK TABLES `phragment_fragment` WRITE;
/*!40000 ALTER TABLE `phragment_fragment` DISABLE KEYS */;
/*!40000 ALTER TABLE `phragment_fragment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phragment_fragmentversion`
--

DROP TABLE IF EXISTS `phragment_fragmentversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phragment_fragmentversion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  `fragmentPHID` varbinary(64) NOT NULL,
  `filePHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_version` (`fragmentPHID`,`sequence`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phragment_fragmentversion`
--

LOCK TABLES `phragment_fragmentversion` WRITE;
/*!40000 ALTER TABLE `phragment_fragmentversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `phragment_fragmentversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phragment_snapshot`
--

DROP TABLE IF EXISTS `phragment_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phragment_snapshot` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `primaryFragmentPHID` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_name` (`primaryFragmentPHID`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phragment_snapshot`
--

LOCK TABLES `phragment_snapshot` WRITE;
/*!40000 ALTER TABLE `phragment_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `phragment_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phragment_snapshotchild`
--

DROP TABLE IF EXISTS `phragment_snapshotchild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phragment_snapshotchild` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `snapshotPHID` varbinary(64) NOT NULL,
  `fragmentPHID` varbinary(64) NOT NULL,
  `fragmentVersionPHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_child` (`snapshotPHID`,`fragmentPHID`,`fragmentVersionPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phragment_snapshotchild`
--

LOCK TABLES `phragment_snapshotchild` WRITE;
/*!40000 ALTER TABLE `phragment_snapshotchild` DISABLE KEYS */;
/*!40000 ALTER TABLE `phragment_snapshotchild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_dashboard`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_dashboard` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_dashboard`;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `layoutConfig` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `icon` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_dashboard_ngrams`
--

DROP TABLE IF EXISTS `dashboard_dashboard_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_dashboard_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_dashboard_ngrams`
--

LOCK TABLES `dashboard_dashboard_ngrams` WRITE;
/*!40000 ALTER TABLE `dashboard_dashboard_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_dashboard_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_dashboardpanel_ngrams`
--

DROP TABLE IF EXISTS `dashboard_dashboardpanel_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_dashboardpanel_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_dashboardpanel_ngrams`
--

LOCK TABLES `dashboard_dashboardpanel_ngrams` WRITE;
/*!40000 ALTER TABLE `dashboard_dashboardpanel_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_dashboardpanel_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_install`
--

DROP TABLE IF EXISTS `dashboard_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_install` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `installerPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `applicationClass` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `dashboardPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`applicationClass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_install`
--

LOCK TABLES `dashboard_install` WRITE;
/*!40000 ALTER TABLE `dashboard_install` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_panel`
--

DROP TABLE IF EXISTS `dashboard_panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_panel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `panelType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_panel`
--

LOCK TABLES `dashboard_panel` WRITE;
/*!40000 ALTER TABLE `dashboard_panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_paneltransaction`
--

DROP TABLE IF EXISTS `dashboard_paneltransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_paneltransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_paneltransaction`
--

LOCK TABLES `dashboard_paneltransaction` WRITE;
/*!40000 ALTER TABLE `dashboard_paneltransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_paneltransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_transaction`
--

DROP TABLE IF EXISTS `dashboard_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_transaction`
--

LOCK TABLES `dashboard_transaction` WRITE;
/*!40000 ALTER TABLE `dashboard_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_system`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_system`;

--
-- Table structure for table `system_actionlog`
--

DROP TABLE IF EXISTS `system_actionlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_actionlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actorHash` binary(12) NOT NULL,
  `actorIdentity` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `action` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `score` double NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_epoch` (`epoch`),
  KEY `key_action` (`actorHash`,`action`,`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_actionlog`
--

LOCK TABLES `system_actionlog` WRITE;
/*!40000 ALTER TABLE `system_actionlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_actionlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_destructionlog`
--

DROP TABLE IF EXISTS `system_destructionlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_destructionlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectClass` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `rootLogID` int(10) unsigned DEFAULT NULL,
  `objectPHID` varbinary(64) DEFAULT NULL,
  `objectMonogram` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `epoch` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_epoch` (`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_destructionlog`
--

LOCK TABLES `system_destructionlog` WRITE;
/*!40000 ALTER TABLE `system_destructionlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_destructionlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_fund`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_fund` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_fund`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_backer`
--

DROP TABLE IF EXISTS `fund_backer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_backer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `initiativePHID` varbinary(64) NOT NULL,
  `backerPHID` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `amountAsCurrency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `properties` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_initiative` (`initiativePHID`),
  KEY `key_backer` (`backerPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_backer`
--

LOCK TABLES `fund_backer` WRITE;
/*!40000 ALTER TABLE `fund_backer` DISABLE KEYS */;
/*!40000 ALTER TABLE `fund_backer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_backertransaction`
--

DROP TABLE IF EXISTS `fund_backertransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_backertransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_backertransaction`
--

LOCK TABLES `fund_backertransaction` WRITE;
/*!40000 ALTER TABLE `fund_backertransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `fund_backertransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_initiative`
--

DROP TABLE IF EXISTS `fund_initiative`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_initiative` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `ownerPHID` varbinary(64) NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `merchantPHID` varbinary(64) DEFAULT NULL,
  `risks` longtext COLLATE utf8mb4_bin NOT NULL,
  `totalAsCurrency` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_status` (`status`),
  KEY `key_owner` (`ownerPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_initiative`
--

LOCK TABLES `fund_initiative` WRITE;
/*!40000 ALTER TABLE `fund_initiative` DISABLE KEYS */;
/*!40000 ALTER TABLE `fund_initiative` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_initiativetransaction`
--

DROP TABLE IF EXISTS `fund_initiativetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_initiativetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_initiativetransaction`
--

LOCK TABLES `fund_initiativetransaction` WRITE;
/*!40000 ALTER TABLE `fund_initiativetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `fund_initiativetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_initiativetransaction_comment`
--

DROP TABLE IF EXISTS `fund_initiativetransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_initiativetransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_initiativetransaction_comment`
--

LOCK TABLES `fund_initiativetransaction_comment` WRITE;
/*!40000 ALTER TABLE `fund_initiativetransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `fund_initiativetransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_almanac`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_almanac` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_almanac`;

--
-- Table structure for table `almanac_binding`
--

DROP TABLE IF EXISTS `almanac_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_binding` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `servicePHID` varbinary(64) NOT NULL,
  `devicePHID` varbinary(64) NOT NULL,
  `interfacePHID` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `isDisabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_service` (`servicePHID`,`interfacePHID`),
  KEY `key_device` (`devicePHID`),
  KEY `key_interface` (`interfacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_binding`
--

LOCK TABLES `almanac_binding` WRITE;
/*!40000 ALTER TABLE `almanac_binding` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_bindingtransaction`
--

DROP TABLE IF EXISTS `almanac_bindingtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_bindingtransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_bindingtransaction`
--

LOCK TABLES `almanac_bindingtransaction` WRITE;
/*!40000 ALTER TABLE `almanac_bindingtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_bindingtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_device`
--

DROP TABLE IF EXISTS `almanac_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_device` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `nameIndex` binary(12) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `isBoundToClusterService` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_name` (`nameIndex`),
  KEY `key_nametext` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_device`
--

LOCK TABLES `almanac_device` WRITE;
/*!40000 ALTER TABLE `almanac_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_devicename_ngrams`
--

DROP TABLE IF EXISTS `almanac_devicename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_devicename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_devicename_ngrams`
--

LOCK TABLES `almanac_devicename_ngrams` WRITE;
/*!40000 ALTER TABLE `almanac_devicename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_devicename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_devicetransaction`
--

DROP TABLE IF EXISTS `almanac_devicetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_devicetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_devicetransaction`
--

LOCK TABLES `almanac_devicetransaction` WRITE;
/*!40000 ALTER TABLE `almanac_devicetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_devicetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_interface`
--

DROP TABLE IF EXISTS `almanac_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_interface` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `devicePHID` varbinary(64) NOT NULL,
  `networkPHID` varbinary(64) NOT NULL,
  `address` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `port` int(10) unsigned NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_location` (`networkPHID`,`address`,`port`),
  KEY `key_device` (`devicePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_interface`
--

LOCK TABLES `almanac_interface` WRITE;
/*!40000 ALTER TABLE `almanac_interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_namespace`
--

DROP TABLE IF EXISTS `almanac_namespace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_namespace` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `nameIndex` binary(12) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_nameindex` (`nameIndex`),
  KEY `key_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_namespace`
--

LOCK TABLES `almanac_namespace` WRITE;
/*!40000 ALTER TABLE `almanac_namespace` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_namespace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_namespacename_ngrams`
--

DROP TABLE IF EXISTS `almanac_namespacename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_namespacename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_namespacename_ngrams`
--

LOCK TABLES `almanac_namespacename_ngrams` WRITE;
/*!40000 ALTER TABLE `almanac_namespacename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_namespacename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_namespacetransaction`
--

DROP TABLE IF EXISTS `almanac_namespacetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_namespacetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_namespacetransaction`
--

LOCK TABLES `almanac_namespacetransaction` WRITE;
/*!40000 ALTER TABLE `almanac_namespacetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_namespacetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_network`
--

DROP TABLE IF EXISTS `almanac_network`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_network` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_network`
--

LOCK TABLES `almanac_network` WRITE;
/*!40000 ALTER TABLE `almanac_network` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_network` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_networkname_ngrams`
--

DROP TABLE IF EXISTS `almanac_networkname_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_networkname_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_networkname_ngrams`
--

LOCK TABLES `almanac_networkname_ngrams` WRITE;
/*!40000 ALTER TABLE `almanac_networkname_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_networkname_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_networktransaction`
--

DROP TABLE IF EXISTS `almanac_networktransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_networktransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_networktransaction`
--

LOCK TABLES `almanac_networktransaction` WRITE;
/*!40000 ALTER TABLE `almanac_networktransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_networktransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_property`
--

DROP TABLE IF EXISTS `almanac_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_property` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectPHID` varbinary(64) NOT NULL,
  `fieldIndex` binary(12) NOT NULL,
  `fieldName` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `fieldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `objectPHID` (`objectPHID`,`fieldIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_property`
--

LOCK TABLES `almanac_property` WRITE;
/*!40000 ALTER TABLE `almanac_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_service`
--

DROP TABLE IF EXISTS `almanac_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `nameIndex` binary(12) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `serviceType` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_name` (`nameIndex`),
  KEY `key_nametext` (`name`),
  KEY `key_servicetype` (`serviceType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_service`
--

LOCK TABLES `almanac_service` WRITE;
/*!40000 ALTER TABLE `almanac_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_servicename_ngrams`
--

DROP TABLE IF EXISTS `almanac_servicename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_servicename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_servicename_ngrams`
--

LOCK TABLES `almanac_servicename_ngrams` WRITE;
/*!40000 ALTER TABLE `almanac_servicename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_servicename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almanac_servicetransaction`
--

DROP TABLE IF EXISTS `almanac_servicetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almanac_servicetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almanac_servicetransaction`
--

LOCK TABLES `almanac_servicetransaction` WRITE;
/*!40000 ALTER TABLE `almanac_servicetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `almanac_servicetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_multimeter`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_multimeter` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_multimeter`;

--
-- Table structure for table `multimeter_context`
--

DROP TABLE IF EXISTS `multimeter_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimeter_context` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `nameHash` binary(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`nameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimeter_context`
--

LOCK TABLES `multimeter_context` WRITE;
/*!40000 ALTER TABLE `multimeter_context` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimeter_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimeter_event`
--

DROP TABLE IF EXISTS `multimeter_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimeter_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `eventType` int(10) unsigned NOT NULL,
  `eventLabelID` int(10) unsigned NOT NULL,
  `resourceCost` bigint(20) NOT NULL,
  `sampleRate` int(10) unsigned NOT NULL,
  `eventContextID` int(10) unsigned NOT NULL,
  `eventHostID` int(10) unsigned NOT NULL,
  `eventViewerID` int(10) unsigned NOT NULL,
  `epoch` int(10) unsigned NOT NULL,
  `requestKey` binary(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_request` (`requestKey`),
  KEY `key_type` (`eventType`,`epoch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimeter_event`
--

LOCK TABLES `multimeter_event` WRITE;
/*!40000 ALTER TABLE `multimeter_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimeter_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimeter_host`
--

DROP TABLE IF EXISTS `multimeter_host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimeter_host` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `nameHash` binary(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`nameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimeter_host`
--

LOCK TABLES `multimeter_host` WRITE;
/*!40000 ALTER TABLE `multimeter_host` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimeter_host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimeter_label`
--

DROP TABLE IF EXISTS `multimeter_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimeter_label` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `nameHash` binary(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`nameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimeter_label`
--

LOCK TABLES `multimeter_label` WRITE;
/*!40000 ALTER TABLE `multimeter_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimeter_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimeter_viewer`
--

DROP TABLE IF EXISTS `multimeter_viewer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimeter_viewer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `nameHash` binary(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`nameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimeter_viewer`
--

LOCK TABLES `multimeter_viewer` WRITE;
/*!40000 ALTER TABLE `multimeter_viewer` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimeter_viewer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_spaces`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_spaces` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_spaces`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spaces_namespace`
--

DROP TABLE IF EXISTS `spaces_namespace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spaces_namespace` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `namespaceName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `isDefaultNamespace` tinyint(1) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `isArchived` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_default` (`isDefaultNamespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spaces_namespace`
--

LOCK TABLES `spaces_namespace` WRITE;
/*!40000 ALTER TABLE `spaces_namespace` DISABLE KEYS */;
/*!40000 ALTER TABLE `spaces_namespace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spaces_namespacetransaction`
--

DROP TABLE IF EXISTS `spaces_namespacetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spaces_namespacetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spaces_namespacetransaction`
--

LOCK TABLES `spaces_namespacetransaction` WRITE;
/*!40000 ALTER TABLE `spaces_namespacetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `spaces_namespacetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_phurl`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_phurl` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_phurl`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phurl_phurlname_ngrams`
--

DROP TABLE IF EXISTS `phurl_phurlname_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phurl_phurlname_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phurl_phurlname_ngrams`
--

LOCK TABLES `phurl_phurlname_ngrams` WRITE;
/*!40000 ALTER TABLE `phurl_phurlname_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `phurl_phurlname_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phurl_url`
--

DROP TABLE IF EXISTS `phurl_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phurl_url` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` longtext COLLATE utf8mb4_bin NOT NULL,
  `longURL` longtext COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `spacePHID` varbinary(64) DEFAULT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `alias` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_instance` (`alias`),
  KEY `key_author` (`authorPHID`),
  KEY `key_space` (`spacePHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phurl_url`
--

LOCK TABLES `phurl_url` WRITE;
/*!40000 ALTER TABLE `phurl_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `phurl_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phurl_urltransaction`
--

DROP TABLE IF EXISTS `phurl_urltransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phurl_urltransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phurl_urltransaction`
--

LOCK TABLES `phurl_urltransaction` WRITE;
/*!40000 ALTER TABLE `phurl_urltransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `phurl_urltransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phurl_urltransaction_comment`
--

DROP TABLE IF EXISTS `phurl_urltransaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phurl_urltransaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phurl_urltransaction_comment`
--

LOCK TABLES `phurl_urltransaction_comment` WRITE;
/*!40000 ALTER TABLE `phurl_urltransaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `phurl_urltransaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_badges`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_badges` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_badges`;

--
-- Table structure for table `badges_award`
--

DROP TABLE IF EXISTS `badges_award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_award` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `badgePHID` varbinary(64) NOT NULL,
  `recipientPHID` varbinary(64) NOT NULL,
  `awarderPHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_badge` (`badgePHID`,`recipientPHID`),
  KEY `key_recipient` (`recipientPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_award`
--

LOCK TABLES `badges_award` WRITE;
/*!40000 ALTER TABLE `badges_award` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_badge`
--

DROP TABLE IF EXISTS `badges_badge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_badge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `flavor` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `description` longtext COLLATE utf8mb4_bin NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `quality` int(10) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `creatorPHID` varbinary(64) NOT NULL,
  `mailKey` binary(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_creator` (`creatorPHID`,`dateModified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_badge`
--

LOCK TABLES `badges_badge` WRITE;
/*!40000 ALTER TABLE `badges_badge` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_badge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_badgename_ngrams`
--

DROP TABLE IF EXISTS `badges_badgename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_badgename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_badgename_ngrams`
--

LOCK TABLES `badges_badgename_ngrams` WRITE;
/*!40000 ALTER TABLE `badges_badgename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_badgename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_transaction`
--

DROP TABLE IF EXISTS `badges_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_transaction`
--

LOCK TABLES `badges_transaction` WRITE;
/*!40000 ALTER TABLE `badges_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_transaction_comment`
--

DROP TABLE IF EXISTS `badges_transaction_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_transaction_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `transactionPHID` varbinary(64) DEFAULT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_version` (`transactionPHID`,`commentVersion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_transaction_comment`
--

LOCK TABLES `badges_transaction_comment` WRITE;
/*!40000 ALTER TABLE `badges_transaction_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_transaction_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `phabricator_packages`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phabricator_packages` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;

USE `phabricator_packages`;

--
-- Table structure for table `edge`
--

DROP TABLE IF EXISTS `edge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge` (
  `src` varbinary(64) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `dst` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `seq` int(10) unsigned NOT NULL,
  `dataID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`src`,`type`,`dst`),
  UNIQUE KEY `key_dst` (`dst`,`type`,`src`),
  KEY `src` (`src`,`type`,`dateCreated`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edge`
--

LOCK TABLES `edge` WRITE;
/*!40000 ALTER TABLE `edge` DISABLE KEYS */;
/*!40000 ALTER TABLE `edge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edgedata`
--

DROP TABLE IF EXISTS `edgedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edgedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edgedata`
--

LOCK TABLES `edgedata` WRITE;
/*!40000 ALTER TABLE `edgedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `edgedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_package`
--

DROP TABLE IF EXISTS `packages_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_package` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisherPHID` varbinary(64) NOT NULL,
  `packageKey` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_package` (`publisherPHID`,`packageKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_package`
--

LOCK TABLES `packages_package` WRITE;
/*!40000 ALTER TABLE `packages_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_packagename_ngrams`
--

DROP TABLE IF EXISTS `packages_packagename_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_packagename_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_packagename_ngrams`
--

LOCK TABLES `packages_packagename_ngrams` WRITE;
/*!40000 ALTER TABLE `packages_packagename_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_packagename_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_packagetransaction`
--

DROP TABLE IF EXISTS `packages_packagetransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_packagetransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_packagetransaction`
--

LOCK TABLES `packages_packagetransaction` WRITE;
/*!40000 ALTER TABLE `packages_packagetransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_packagetransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_publisher`
--

DROP TABLE IF EXISTS `packages_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_publisher` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisherKey` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_publisher` (`publisherKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_publisher`
--

LOCK TABLES `packages_publisher` WRITE;
/*!40000 ALTER TABLE `packages_publisher` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_publishername_ngrams`
--

DROP TABLE IF EXISTS `packages_publishername_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_publishername_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_publishername_ngrams`
--

LOCK TABLES `packages_publishername_ngrams` WRITE;
/*!40000 ALTER TABLE `packages_publishername_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_publishername_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_publishertransaction`
--

DROP TABLE IF EXISTS `packages_publishertransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_publishertransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_publishertransaction`
--

LOCK TABLES `packages_publishertransaction` WRITE;
/*!40000 ALTER TABLE `packages_publishertransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_publishertransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_version`
--

DROP TABLE IF EXISTS `packages_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `packagePHID` varbinary(64) NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  UNIQUE KEY `key_package` (`packagePHID`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_version`
--

LOCK TABLES `packages_version` WRITE;
/*!40000 ALTER TABLE `packages_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_versionname_ngrams`
--

DROP TABLE IF EXISTS `packages_versionname_ngrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_versionname_ngrams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int(10) unsigned NOT NULL,
  `ngram` char(3) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key_object` (`objectID`),
  KEY `key_ngram` (`ngram`,`objectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_versionname_ngrams`
--

LOCK TABLES `packages_versionname_ngrams` WRITE;
/*!40000 ALTER TABLE `packages_versionname_ngrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_versionname_ngrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_versiontransaction`
--

DROP TABLE IF EXISTS `packages_versiontransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_versiontransaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phid` varbinary(64) NOT NULL,
  `authorPHID` varbinary(64) NOT NULL,
  `objectPHID` varbinary(64) NOT NULL,
  `viewPolicy` varbinary(64) NOT NULL,
  `editPolicy` varbinary(64) NOT NULL,
  `commentPHID` varbinary(64) DEFAULT NULL,
  `commentVersion` int(10) unsigned NOT NULL,
  `transactionType` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `oldValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `newValue` longtext COLLATE utf8mb4_bin NOT NULL,
  `contentSource` longtext COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext COLLATE utf8mb4_bin NOT NULL,
  `dateCreated` int(10) unsigned NOT NULL,
  `dateModified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_phid` (`phid`),
  KEY `key_object` (`objectPHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_versiontransaction`
--

LOCK TABLES `packages_versiontransaction` WRITE;
/*!40000 ALTER TABLE `packages_versiontransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_versiontransaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-10 17:19:44
